#include <common/types.h>

class Speaker_Class {
    public:
        void tone(gathrillo::common::uint16_t frequency);
        void noTone();
        void beep();
};

extern Speaker_Class Speaker;