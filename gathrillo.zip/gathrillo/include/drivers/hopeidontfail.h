#ifndef __GATHRILLO__DRIVERS__HOPEIDONTFAIL_H
#define __GATHRILLO__DRIVERS__HOPEIDONTFAIL_H

#include <common/types.h>
#include <hardwarecommunication/interrupts.h>
#include <drivers/driver.h>
#include <hardwarecommunication/port.h>



namespace gathrillo
{

    namespace drivers
    {




class sqrtfun 
{
    
   
   
public:
   
     sqrtfun( double sqrt);
     static double sqrt1;
     
    ~sqrtfun();

  
};

        
        

class sin 
{
    
   
   
public:
     sin();
     
     
    ~sin();

   
};

        
class cos 
{
    
   
   
public:
     cos(common::uint8_t number);
     
     
    ~cos();

   
};

        
        
        
        
    }
}

#endif
