#ifndef __GATHRILLO__DRIVERS__KEYBOARD_H
#define __GATHRILLO__DRIVERS__KEYBOARD_H

#include <common/types.h>
#include <hardwarecommunication/interrupts.h>
#include <drivers/driver.h>
#include <hardwarecommunication/port.h>



namespace gathrillo
{

    namespace drivers
    {



class GameEventHandler
{
    
public:  
    GameEventHandler();
  
   virtual void OnGameKeyDown(char);
   virtual void OnGameKeyUp(char);
    
};

class GameDriver : public gathrillo::hardwarecommunication::InterruptHandler, public Driver
{
    gathrillo::hardwarecommunication::Port8Bit dataport;
    gathrillo::hardwarecommunication::Port8Bit commandport;
   
   GameEventHandler* handler;
public:
    char* s1;
    char* save[8];
     char* it1;
     char* it2;
     char* it3;
     char* it4;
     char* it5;
     char* it6;
     char* it7;
     char* it8;
   
    
    
    GameDriver(gathrillo::hardwarecommunication::InterruptManager* manager, GameEventHandler *handler);
    ~GameDriver();
    virtual gathrillo::common::uint32_t HandleInterrupt(gathrillo::common::uint32_t esp);
    virtual void Activate();
    
    sfx(bool MO, common::uint8_t mus);
    static bool pci;
    

    
};

    }
}

#endif
