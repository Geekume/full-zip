// #ifndef __GATHRILLO__DRIVERS__CONTROLLER_H
// #define __GATHRILLO__DRIVERS__CONTROLLER_H
// #include <common/types.h>
// #include <hardwarecommunication/interrupts.h>
// #include <hardwarecommunication/port.h>
// 
// namespace gathrillo
// {
// 
//     namespace drivers
//     {
// 
// class ControllerEventHandler
// {
// public:  
//     ControllerEventHandler();
//    virtual void OnControllerActivate();
//    virtual void OnControllerDown(gathrillo::common::uint8_t button);
//    virtual void OnControllerUp(gathrillo::common::uint8_t button);
//    virtual void OnControllerMove(int x, int y);
//     
// };
//         
// class ControllerDriver : public gathrillo::hardwarecommunication::InterruptHandler, public Driver
// {
//    
//    gathrillo::hardwarecommunication::Port8Bit dataport;
//    gathrillo::hardwarecommunication::Port8Bit commandport;
// public:
//      ControllerDriver(gathrillo::hardwarecommunication::InterruptManager* manager);
//     ~ControllerDriver();
//     virtual gathrillo::common::uint32_t HandleInterrupt(gathrillo::common::uint32_t esp);
//     
//    
// };
// 
//     }
// }
// 
// #endif