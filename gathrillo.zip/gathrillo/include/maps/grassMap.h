
#ifndef __GATHRILLO__MAPS__GRASSMAP_H
#define __GATHRILLO__MAPS__GRASSMAP_H




#include <gui/widget.h>
#include <drivers/mouse.h>
#include <gui/window.h>
#include <gui/desktop.h>
#include <models/models.h>





namespace gathrillo
{

    namespace grassMap
    {
    
        

        class GrassMap : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                GrassMap  (/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
           
                

                
        };
       
     
        
        
 
 
    }
}


#endif

