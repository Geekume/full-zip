#ifndef __GATHRILLO__MODELS__GRASS_MAP_H
#define __GATHRILLO__MODELS__GRASS_MAP_H




#include <gui/widget.h>
#include <drivers/mouse.h>
#include <gui/window.h>
#include <gui/desktop.h>
#include <models/models.h>






namespace gathrillo
{

    namespace grass_map
    {
    
         class CollGrassMap : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Terrain (/*Widget* parent,*/ common::uint8_t rot, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
               
                
                
        };
        
        
    }
}


#endif
