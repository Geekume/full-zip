#ifndef  __GATHRILLO__WIDGET__GRAPHICCONTEXT_H
#define __GATHRILLO__WIDGET__GRAPHICCONTEXT_H

#include <drivers/vga.h>
 
namespace gathrillo
{

namespace common
{


    typedef gathrillo::drivers::VideoGraphicsArray GraphicsContext;


}


}



#endif