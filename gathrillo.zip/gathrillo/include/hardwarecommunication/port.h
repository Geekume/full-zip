#ifndef __GATHRILLO__HARDWARECOMMUNICATION__PORT_H
#define __GATHRILLO__HARDWARECOMMUNICATION__PORT_H
#include <common/types.h>



namespace gathrillo
{

    namespace hardwarecommunication
    {
    
  
      inline static unsigned char inportb (unsigned short _port)
        {
            unsigned char rv;
            __asm__ __volatile__ ("inb %1, %0" : "=a" (rv) : "dN" (_port));
            return rv;
        }

        inline static void outportb (unsigned short _port, unsigned char _data)
            {
                __asm__ __volatile__ ("outb %1, %0" : : "dN" (_port), "a" (_data));
            }

        inline static unsigned short inportw(unsigned short _port)
            {
                unsigned short rv;
                __asm__ __volatile__ ("inw %1, %0" : "=a" (rv) : "dN" (_port));
                return rv;
            }

        inline static void outportw(unsigned short _port, unsigned short _data)
            {
                __asm__ __volatile__ ("outw %1, %0" : : "dN" (_port), "a" (_data));
            }
        inline static unsigned int inportl(unsigned short _port)
        {
            unsigned int val;
            __asm__ __volatile__ ("inl %%dx, %%eax" : "=a" (val) : "d" (_port));
            return( val );
        }
        inline static void outportl(unsigned short _port, unsigned int _data)
        {
            __asm__ __volatile__ ("outl %%eax, %%dx" : : "d" (_port), "a" (_data));
        }       
        
        
        
        
        
        
class Port 
{
    
protected:
     Port(gathrillo::common::uint16_t portnumber);
    // FIXME: Must be virtual (currently isnt because the kernel has no memory management yet)
    ~Port();
     gathrillo::common::uint16_t portnumber;


};

class Port8Bit : public Port
{
    
public:
    Port8Bit(gathrillo::common::uint16_t portnumber);
    ~Port8Bit();
    virtual gathrillo::common::uint8_t Read();
    virtual void Write(gathrillo::common::uint8_t data);
    
protected:
    static inline gathrillo::common::uint8_t Read8(gathrillo::common::uint16_t port)
    {
    gathrillo::common::uint8_t result;
    __asm__ volatile("inb %1, %0" : "=a" (result) : "Nd" (port));
    return result;
    }
    
    static inline void Write8(gathrillo::common::uint16_t port, gathrillo::common::uint8_t data)
    {
     __asm__ volatile("outb %0, %1" : : "a" (data), "Nd" (port));
    }
};
        
        

class Port8BitSlow : public Port8Bit 
{
    
public:
    Port8BitSlow(gathrillo::common::uint16_t portnumber);
    ~Port8BitSlow();
    virtual void Write(gathrillo::common::uint8_t data);
protected:

static inline void Write8Slow(gathrillo::common::uint16_t port, gathrillo::common::uint8_t data)
    {
      __asm__ volatile("outb %0, %1\njmp 1f\n1: jmp 1f\n1:" : : "a" (data), "Nd" (port));
      }
};


class Port16Bit : public Port
{
    
public:
  Port16Bit(gathrillo::common::uint16_t portnumber);
    ~Port16Bit();
    virtual void Write(gathrillo::common::uint16_t data);
    virtual gathrillo::common::uint16_t Read();
    
 protected:
    static inline gathrillo::common::uint8_t Read16(gathrillo::common::uint16_t port)
    {
    gathrillo::common::uint16_t result;
    __asm__ volatile("inb %1, %0" : "=a" (result) : "Nd" (port));
    return result;
    }
    
    static inline void Write16(gathrillo::common::uint16_t port, gathrillo::common::uint16_t data)
    {
    __asm__ volatile("outb %0, %1" : : "a" (data), "Nd" (port));

    }
};


class Port32Bit : public Port
{
    
public:
    Port32Bit(gathrillo::common::uint16_t (portnumber));
    ~Port32Bit();
     virtual void Write(gathrillo::common::uint32_t data);
     virtual gathrillo::common::uint32_t Read();
     
protected:
    static inline gathrillo::common::uint8_t Read32(gathrillo::common::uint16_t port)
    {
    gathrillo::common::uint32_t result;
    __asm__ volatile("inb %1, %0" : "=a" (result) : "Nd" (port));
    return result;
    }
    
    static inline void Write32(gathrillo::common::uint16_t port, gathrillo::common::uint32_t data)
    {
    __asm__ volatile("outb %0, %1" : : "a" (data), "Nd" (port));
    }
};



    }
}







#endif