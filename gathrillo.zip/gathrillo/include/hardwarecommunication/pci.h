#ifndef __GATHRILLO__HARDWARECOMMUNICATION__PCI_H
#define __GATHRILLO__HARDWARECOMMUNICATION__PCI_H

#include <hardwarecommunication/port.h>
#include <drivers/driver.h>
#include <common/types.h>
#include <gdt.h>
#include <hardwarecommunication/interrupts.h>
#include <drivers/game.h>
#include <memorymanagement.h>



namespace gathrillo
{

    namespace hardwarecommunication
    {
  
    
        
        enum BaseAddressRegisterType
        {
            MemoryMapping = 0,
            InputOutput = 1
        
        };
        
        class BaseAddressRegister
        {
        public:
            bool prefetchable;
            gathrillo::common::uint8_t* address;
            BaseAddressRegisterType type;
        };
 
class PeripheralComponentInterconnectDeviceDescriptor
{
public:
    gathrillo::common::uint32_t portBase;
    gathrillo::common::uint32_t interrupt;
    
    gathrillo::common::uint16_t bus;
    gathrillo::common::uint16_t device;
    gathrillo::common::uint16_t function;
    
    gathrillo::common::uint16_t vendor_id;
    gathrillo::common::uint16_t device_id;
    
    gathrillo::common::uint8_t class_id;
    gathrillo::common::uint8_t subclass_id;
    gathrillo::common::uint8_t interface_id;
    
    gathrillo::common::uint8_t revision;
    
    gathrillo::common::var pci;
    

    

    PeripheralComponentInterconnectDeviceDescriptor();
    ~PeripheralComponentInterconnectDeviceDescriptor();
};

class PeripheralComponentInterconnectController 

{    

Port32Bit dataPort;
Port32Bit commandPort;

public:
PeripheralComponentInterconnectController();
~PeripheralComponentInterconnectController();

gathrillo::common::uint32_t Read(gathrillo::common::uint16_t bus, gathrillo::common::uint16_t device, gathrillo::common::uint16_t function, gathrillo::common::uint32_t registeroffset);
void Write(gathrillo::common::uint16_t bus, gathrillo::common::uint16_t device, gathrillo::common::uint16_t function, gathrillo::common::uint32_t registeroffset, gathrillo::common::uint32_t value); 
bool DeviceHasFunctions(gathrillo::common::uint16_t bus, gathrillo::common::uint16_t device);
void SelectDrivers(gathrillo::drivers::DriverManager* driverManager, gathrillo::hardwarecommunication::InterruptManager* interrupts);
PeripheralComponentInterconnectDeviceDescriptor GetDeviceDescriptor(gathrillo::common::uint16_t bus, gathrillo::common::uint16_t device, gathrillo::common::uint16_t function);


gathrillo::drivers::Driver* GetDriver(PeripheralComponentInterconnectDeviceDescriptor dev, gathrillo::hardwarecommunication::InterruptManager* interrupts);
BaseAddressRegister GetBaseAddressRegister(gathrillo::common::uint16_t bus, gathrillo::common::uint16_t device, gathrillo::common::uint16_t function, gathrillo::common::uint16_t bar);

};
    }
}
#endif

