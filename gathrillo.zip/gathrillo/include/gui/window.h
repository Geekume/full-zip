#ifndef __GATHRILLO__GUI__WINDOW_H
#define __GATHRILLO__GUI__WINDOW_H
#include <gui/widget.h>
#include <drivers/mouse.h>


namespace gathrillo
{

    namespace gui
    {
        class Window : public CompositeWidget
        {
            protected: 
                bool screen;
                
            public: 
                Window (Widget* parent, common::uint8_t ang,
                    common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h,
                    common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t size);
                ~Window();
                void OnMouseDown(common::int32_t x, common::int32_t y, common::uint8_t button);
                void OnMouseUp(common::int32_t x, common::int32_t y, common::uint8_t button);
                void OnMouseMove(common::int32_t oldx, common::int32_t oldy, common::int32_t newx, common::int32_t newy);
            
        };
        
        
         class Polygon : public CompositeWidget
        {
            protected: 
                bool screen;
                int pix;
               // pix = 0;
                
            public: 
                Polygon (/*Widget* parent,*/ common::uint8_t AnglePos, common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~Polygon();
                void OnMouseDown(common::int32_t x, common::int32_t y, common::uint8_t button);
                void OnMouseUp(common::int32_t x, common::int32_t y, common::uint8_t button);
                void OnMouseMove(common::int32_t oldx, common::int32_t oldy, common::int32_t newx, common::int32_t newy);

                
        };
        
        
        
       
        
        
        
        
         class Tetrahedron : public CompositeWidget
        {
            protected: 
               
            public: 
                Tetrahedron (/*Widget* parent,*/ common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                
                
                ~Tetrahedron();
                
                
        };
        
        
        
         class Dline : public CompositeWidget
        {
            protected: 
               
          public: 
                Dline (/*Widget* parent,*/ common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                
                
                ~Dline();
                
                
        };
        
        
        
        
          class Tetrahedron_m : public CompositeWidget
        {
            protected: 
               
            public: 
                Tetrahedron_m (/*Widget* parent,*/common::uint8_t AnglePos,  common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                
                
                ~Tetrahedron_m();
                
                
        };
        
           class Cube : public CompositeWidget
        {
            protected: 
               
            public: 
                Cube (common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);  
                
                ~Cube();
                
                
        };
        
              class Cube_m : public CompositeWidget
        {
            protected: 
               
            public: 
                Cube_m (common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);  
                
                ~Cube_m();
                
                
        };
        
        
        
        
         class Skelekton : public CompositeWidget
        {
            protected: 
               
            public: 
                Skelekton (common::uint8_t arm_rot, common::uint8_t forearm_rot1,
                common::uint8_t forearm_rot2,
                common::uint8_t leg_rot, common::uint8_t quad_rot1,
                common::uint8_t quad_rot2, common::uint8_t spine1_rot, common::uint8_t spine2_rot, common::uint8_t head_rot, common::uint8_t head_size, common::uint8_t spine_size, common::uint8_t arm_size, common::uint8_t forearm_size1,
                common::uint8_t forearm_size2,
                common::uint8_t spine2_size, common::uint8_t leg_size, common::uint8_t quad_size1, 
                common::uint8_t quad_size2, 
                common::uint8_t foot_size, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                
                
                ~Skelekton();
                
                
        };
        
             class Animation : public CompositeWidget
        {
            protected: 
               
            public: 
            
            
                
                  Animation (common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b); 
            
            
                 
                 
                  
                
                ~Animation();
                
                
        };
        
        
         class Run : public CompositeWidget
        {
        
         protected: 
               
            public: 
            
         
                
                  Run (common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b); 
        
        
          ~Run();
        };
        
        
        class Jump : public CompositeWidget
        {
        
         protected: 
               
            public: 
            
         
                
                  Jump (common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b); 
        
        
          ~Jump();
        };
        
        class Punch : public CompositeWidget
        {
        
         protected: 
               
            public: 
            
       
                 
                  Punch (common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b); 
                  
        
          ~Punch();
        };
        
        class Kick : public CompositeWidget
        {
        
         protected: 
               
            public: 
            
        
                   Kick (common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b); 
        
        
          ~Kick();
        };
        
        
       class vertex : public CompositeWidget
        {
            protected: 
               
            public: 
                vertex (common::uint8_t AnglePos, common::int32_t x, common::int32_t y,common::int32_t z, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);  
                
                ~vertex();
                
                
        };
        
        
        class face : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                face (/*Widget* parent,*/common::uint8_t att, common::uint8_t angle, common::uint8_t x, common::int32_t y,common::uint8_t w, common::int32_t h,
                common::uint8_t fv1x, common::int32_t fv2x, common::int32_t fv3x,
                common::uint8_t fv1y, common::int32_t fv2y, common::int32_t fv3y,
                common::uint8_t fv1z, common::int32_t fv2z, common::int32_t fv3z,
                common::int32_t sacle, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id);
                ~face();
                

                
        };
        
          class ui : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                ui ();
                ~ui();
                

                
        };
       
        
    }
}
    
#endif
