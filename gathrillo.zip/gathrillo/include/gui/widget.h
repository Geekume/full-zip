#ifndef __GATHRILLO__WIDGET__VGA_H
#define __GATHRILLO__WIDGET__VGA_H


#include <common/types.h>
#include <common/graphicsContext.h>
#include <drivers/game.h>
#include <drivers/mouse.h>

 


namespace gathrillo
{

    namespace gui
    { 
    class Widget : public gathrillo::drivers::GameEventHandler {
    protected:
        Widget* parent;
        common::int32_t x;
        common::int32_t y;
        common::int32_t w;
        common::int32_t h;
    
    
        common::uint8_t r;
        common::uint8_t g;
        common::uint8_t b;
        common::uint8_t size;
        common::uint8_t tri;
        common::uint8_t ang;
        common::uint8_t Angle;
        common::uint8_t z1;
        common::uint8_t z2;
        common::uint8_t z3;
        common::uint8_t z4;

        
       
        
        bool Focussable;
        
    public:
         static int dia;
        Widget(Widget* parent, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t size, common::uint8_t tri);

        ~Widget();

        virtual void GetFocus(Widget* widget);
        virtual void ModelToScreen(common::int32_t &x, common::int32_t& y);
        virtual bool ContainsCoordinate(common::int32_t x, common::int32_t y);  
        
        virtual void Draw(common::GraphicsContext* gc);
        virtual void OnMouseDown(common::int32_t x, common::int32_t y, common::uint8_t button);
        virtual void OnMouseUp(common::int32_t x, common::int32_t y, common::uint8_t button);
        virtual void OnMouseMove(common::int32_t oldx, common::int32_t oldy, common::int32_t newx, common::int32_t newy);
   
   
        
        };
        
        class CompositeWidget : public Widget
        {
        private:
        Widget* children[100];
        int numChildren;
        Widget* focussedChild;
        
        
        public: 
      CompositeWidget(Widget* parent,  common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h,
                    common::uint8_t r, common::uint8_t g, common::uint8_t b);
        ~CompositeWidget();
        virtual void GetFocus(Widget* widget);
        virtual bool AddChild(Widget* child);    
            
        virtual void Draw(common::GraphicsContext* gc);
        virtual void OnMouseDown(common::int32_t x, common::int32_t y, common::uint8_t button);
        virtual void OnMouseUp(common::int32_t x, common::int32_t y, common::uint8_t button);
        virtual void OnMouseMove(common::int32_t oldx, common::int32_t oldy, common::int32_t newx, common::int32_t newy);
        
        virtual void OnGameKeyDown(char);
        virtual void OnGameKeyUp(char);
        
        
        };
        
          class Camera : public CompositeWidget, public gathrillo::drivers::MouseEventHandler
        {
        protected:
           
            //common::uint32_t camera;
           // common::uint32_t MouseX;
           // common::uint32_t MouseY;
            
        public: 
           
           Camera(common::uint8_t ang, common::uint8_t x, common::uint8_t y, common::uint8_t z, common::uint8_t rotx, common::uint8_t roty, common::uint8_t rotz);
            ~Camera();
            void Draw(common::GraphicsContext* gc);
            
           
    
        };
        
        
    }
}

#endif
