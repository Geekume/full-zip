/*#ifndef __GATHRILLO__GUI__3D_ENVIROMENT_H
#define __GATHRILLO__GUI__3D_ENVIROMENT_H

#include <gui/widget.h>
#include <drivers/mouse.h>


namespace gathrillo
{

    namespace gui
    {
        class Camera : public CompositeWidget, public gathrillo::drivers::MouseEventHandler
        {
        protected:
           // common::uint32_t angle;
            //common::uint32_t camera;
           // common::uint32_t MouseX;
           // common::uint32_t MouseY;
            
        public: 
           
           Camera(common::uint8_t view, common::uint8_t x, common::uint8_t y, common::uint8_t z, common::uint8_t rotx, common::uint8_t roty, common::uint8_t rotz);
            ~Camera();
            void Draw(common::GraphicsContext* gc);
            
            void OnMouseDown(gathrillo::common::uint8_t button);
            void OnMouseUp(gathrillo::common::uint8_t button);
            void OnMouseMove(int x, int y);
    
        };
    }
}
    








#endif*/