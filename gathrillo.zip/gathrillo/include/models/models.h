#ifndef __GATHRILLO__MODELS__MODELS_H
#define __GATHRILLO__MODELS__MODELS_H




#include <gui/widget.h>
#include <drivers/mouse.h>
#include <gui/window.h>
#include <gui/desktop.h>





namespace gathrillo
{

    namespace models
    {
    
        

        class Spaceship : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Spaceship (/*Widget* parent,*/  common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~Spaceship();
                

                
        };
       
        
        class Gardenbed : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Gardenbed (/*Widget* parent,*/  common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~Gardenbed();
                

                
        };
        
        
         class FreezingFire : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                FreezingFire (/*Widget* parent,*/  common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~FreezingFire();
                

                
        };
        
       
        
         class Enemy : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Enemy (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame,common::uint8_t w,common::uint8_t h);
                ~Enemy();
                

                
        };
        
        
        class Menu : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Menu (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::int32_t menu_highlight);
                ~Menu();
                

                
        };
        
        
        
        
         class Letter : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Letter (common::int32_t x, common::int32_t y, char c, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~Letter();
                

                
        };
        
        
        
         class Char : public gathrillo::gui::CompositeWidget 
         {
        
            protected: 
             
            public: 
                Char (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame,common::uint8_t run1,common::uint8_t run2);
                ~Char();
                

                
          };
        
          class BoxerDavieBody : public gathrillo::gui::CompositeWidget 
          {
        
            protected: 
             
            public: 
                BoxerDavieBody (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieBody();
                

                
           };
        
        
        class BoxerDavieArm : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieArm (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieArm();
                

                
        };
        
        
         class BoxerDavieArm4 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieArm4 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieArm4();
                

                
        };
        
        
        
        
        class BoxerDavieBlock : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieBlock (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieBlock();
                

                
        };
        
        
        
        class BoxerDavieBlockAnim : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieBlockAnim (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieBlockAnim();
                

                
        };
        
        
        class BoxerUpper : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerUpper (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerUpper();
                

                
          };
        
        
        
           class BoxerDavieArmAct1 : public gathrillo::gui::CompositeWidget 
           {
        
            protected: 
             
            public: 
                 BoxerDavieArmAct1 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieArmAct1();
                

                
           };
        
        
        
           class BoxerDavieArmAct2 : public gathrillo::gui::CompositeWidget 
           {
        
            protected: 
             
            public: 
                 BoxerDavieArmAct2 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieArmAct2();
                

                
            };
        
        
           class BoxerDavieArmAct3 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieArmAct3 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieArmAct3();
                

                
        };
        
        
          class BoxerDavieArmAct4 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieArmAct4 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t act);
                ~BoxerDavieArmAct4();
                

                
        };
        
        
         class BoxerDavieSprite1 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieSprite1 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieSprite1();
                

                
        };
        
           class BoxerDavieSprite2 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieSprite2 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieSprite2();
                

                
        };
        
        
        
        
        
        
          class BoxerDavieCrouchPunchSprite : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieCrouchPunchSprite (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieCrouchPunchSprite();
                

                
        };
        
        
         class BoxerPunchAnim : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerPunchAnim (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerPunchAnim();
                

                
        };
        
        
         class BoxerCrouchAnim : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerCrouchAnim (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, bool repeat);
                ~BoxerCrouchAnim();
                

                
        }; 
        
        
         
         class BoxerJumpAnim : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerJumpAnim (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, bool repeat);
                ~BoxerJumpAnim();
                

                
        }; 
        
        
        
            class BoxerWalkSprite1 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerWalkSprite1 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerWalkSprite1();
                

                
        }; 
        
            class BoxerWalkAnim : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerWalkAnim (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerWalkAnim();
                

                
        }; 
        
        
         class P1h : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 P1h (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~P1h();
                

                
        }; 
        
        
         class P2h : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 P2h (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~P2h();
                

                
        }; 
        
        
         class Shoes2 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 Shoes2 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~Shoes2();
                

                
        };
        
        
        
        
          class BoxerDavieCrouchSprite : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieCrouchSprite (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieCrouchSprite();
                

                
        };
        
          class BoxerDavieCrouch : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieCrouch (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieCrouch();
                

                
        };
        
        
        
        
        
         class BoxerDavieSprite3 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieSprite3 (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieSprite3();
                

                
        };
         class BoxerDavieShoes : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavieShoes (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~BoxerDavieShoes();
                

                
        };
        
        
        
        class BoxerDavie : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                 BoxerDavie (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t oof);
                ~BoxerDavie();
                

                
        };
        
        
         class CharJump : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                CharJump (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame,common::uint8_t run1,common::uint8_t run2);
                ~CharJump();
                

                
        };
       
        
        
         class CharRun : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                CharRun (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame,common::uint8_t run1,common::uint8_t run2);
                ~CharRun();
                

                
        }; 
        
        
          class CharAttack : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                CharAttack (/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame,common::uint8_t run1,common::uint8_t run2);
                ~CharAttack();
                

                
        }; 
        
        
      
        
         class Ground_3d_model : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Ground_3d_model (/*Widget* parent,*/ common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b);
                ~Ground_3d_model();
                

                
        };
        
        
             
    class Lv2 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Lv2::Lv2(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame);

                ~Lv2();
                

                
        };
        
        
          
    class Lv1 : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Lv1::Lv1( common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame);

                ~Lv1();
                
 
                
        };
        
        
        class OBJReaderInit : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                OBJReaderInit (/*Widget* parent,*/ common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id);
                ~OBJReaderInit();
                
           
           
        };
            class OBJReader : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                OBJReader (/*Widget* parent,*/ common::uint8_t trans, common::uint8_t att, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
                ~OBJReader();
                int trans;
                
                
        };
        
        
         class Model : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Model (/*Widget* parent,*/ common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
               
                
                
        };
        
         class Terrain : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                Terrain (/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
               
                
                
        };
        
        
        
         class SkyBox : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                SkyBox (/*Widget* parent,*/ common::uint8_t rot, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
               
                
                
        };
        
        
        
        
         class GrassMap : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                GrassMap (/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
               
                
                
        };
        
        
          class SwingModel : public gathrillo::gui::CompositeWidget 
        {
        
            protected: 
             
            public: 
                SwingModel (/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer);
               
                
                
        };
        
 
    }
}


#endif
