#include <models/models.h>
#include <drivers/pit.h>
#include <hardwarecommunication/interrupts.h>
#include <gdt.h>



using namespace gathrillo;
using namespace gathrillo::common;
using namespace gathrillo::models;





Spaceship::Spaceship(/*Widget* parent,*/ common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{

    

    
    if(gathrillo::gui::Widget::Angle == 270) {
    
              
  gathrillo::gui::Cube_m whynot(gathrillo::gui::Widget::Angle, 1, x + 39, y-8, 5*scale, 5, 0xFE, 0xFE, 0xFE);

  gathrillo::gui::Tetrahedron_m ok(gathrillo::gui::Widget::Angle, 1, x, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
  
  gathrillo::gui::Tetrahedron_m boring(gathrillo::gui::Widget::Angle, 1, x + 20, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
     


    }
      
if(gathrillo::gui::Widget::Angle == 0 || gathrillo::gui::Widget::Angle == 180) {
    
                 

  gathrillo::gui::Tetrahedron_m ok(gathrillo::gui::Widget::Angle, 1, x+15, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
  
//  gathrillo::gui::Tetrahedron_m boring( 1, x + 20, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
     
    
    
    
}
          
if(gathrillo::gui::Widget::Angle == 45 || gathrillo::gui::Widget::Angle == 225) {
    
     
  gathrillo::gui::Tetrahedron_m boring(gathrillo::gui::Widget::Angle, 1, x + 20, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
     
  
                 

   gathrillo::gui::Cube_m whynot(gathrillo::gui::Widget::Angle, 1, x + 44, y-8, 5*scale, 5, 0xFE, 0xFE, 0xFE);

  gathrillo::gui::Tetrahedron_m ok(gathrillo::gui::Widget::Angle, 1, x+8, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
 
    
}
  
    
    
if(gathrillo::gui::Widget::Angle == 135) {
    
     
     
  
   gathrillo::gui::Tetrahedron_m ok( gathrillo::gui::Widget::Angle, 1, x+8, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
         

   gathrillo::gui::Cube_m whynot(gathrillo::gui::Widget::Angle, 1, x + 44, y-8, 5*scale, 5, 0xFE, 0xFE, 0xFE);

 
   gathrillo::gui::Tetrahedron_m boring(gathrillo::gui::Widget::Angle, 1, x + 20, y, 10*scale, 4, 0xFE, 0xFE, 0xFE);
    
    
    

}    
    

  

      
      
      
   
    
}

  Spaceship::~Spaceship()
 {
     
 }
  



Lv1::Lv1(common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0xAF); 
    
    
gathrillo::gui::Window back(&desktop5, 90, 30, 175, 50, 32, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back);
    
    

gathrillo::gui::Window back2(&desktop5, 90, 0, 145, 30, 62, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back2);
    

gathrillo::gui::Window back3(&desktop5, 90, 80, 175, 30, 32, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&back3);
    
    
    
    
    
gathrillo::gui::Window back4(&desktop5, 90, 110, 175, 50, 32, 0xAF, 0xA8, 0xA8, 4);
    desktop5.AddChild(&back4);
        
    
gathrillo::gui::Window back5(&desktop5, 90, 140, 105, 50, 12, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back5);
        
    
    
gathrillo::gui::Window back6(&desktop5, 90, 160, 175, 50, 32, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back6);
        
    
    
    
    

gathrillo::gui::Window back7(&desktop5, 90, 210, 175, 30, 32, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&back7);
    
    

gathrillo::gui::Window back8(&desktop5, 90, 240, 175, 30, 32, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&back8);
        
    
    

    
gathrillo::gui::Window back9(&desktop5, 90, 280, 175, 50, 32, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back9);
    
    desktop5.Draw(&vga5);

    
    
}
Lv1::~Lv1()
 {
     
 }


Lv2::Lv2(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0xAF); 
    
    
gathrillo::gui::Window back(&desktop5, 90, 30, 105, 50, 32, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back);
    
    

gathrillo::gui::Window back2(&desktop5, 90, 0, 145, 30, 62, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back2);
    

gathrillo::gui::Window back3(&desktop5, 90, 80, 95, 30, 32, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&back3);
    
    
    
    
    
gathrillo::gui::Window back4(&desktop5, 90, 110, 175, 50, 32, 0xAF, 0xA8, 0xA8, 4);
    desktop5.AddChild(&back4);
        
    
gathrillo::gui::Window back5(&desktop5, 90, 140, 105, 50, 12, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back5);
        
    
    
gathrillo::gui::Window back6(&desktop5, 90, 160, 175, 50, 32, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back6);
        
    
    
    
    

gathrillo::gui::Window back7(&desktop5, 90, 210, 105, 30, 32, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&back7);
    
    

gathrillo::gui::Window back8(&desktop5, 90, 240, 105, 30, 32, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&back8);
        
    
    

    
gathrillo::gui::Window back9(&desktop5, 90, 280, 175, 50, 32, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&back9);
    
    desktop5.Draw(&vga5);

    
    
}
Lv2::~Lv2()
 {
     
 }







Enemy::Enemy(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame, common::uint8_t w,common::uint8_t h)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
        
gathrillo::gui::Window back9(&desktop5, 90, x, y, w, h, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&back9); 
    
    
    desktop5.Draw(&vga5);

    
    
};

  Enemy::~Enemy()
 {
     
 }







Menu::Menu(/*Widget* parent,*/ common::int32_t x, common::int32_t y,common::int32_t menu_highlight)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(0,0,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 
  
 
if(menu_highlight < 4) {    
    

gathrillo::models::Letter(50, 20,'u', 0x00,0xA8,0x00);
gathrillo::models::Letter(60, 20,'l', 0x00,0xA8,0x00);
gathrillo::models::Letter(65, 19,'t', 0x00,0xA8,0x00);
gathrillo::models::Letter(76, 20,'i', 0x00,0xA8,0x00);
gathrillo::models::Letter(84, 20,'m', 0x00,0xA8,0x00);
gathrillo::models::Letter(97, 22,'a', 0x00,0xA8,0x00);
gathrillo::models::Letter(105, 19,'t', 0x00,0xA8,0x00);
gathrillo::models::Letter(118, 20,'e', 0x00,0xA8,0x00);

    
    
gathrillo::models::Letter(150, 20,'f', 0x00,0xA8,0x00);
gathrillo::models::Letter(160, 20,'i', 0x00,0xA8,0x00);
gathrillo::models::Letter(170, 21,'g', 0x00,0xA8,0x00);
gathrillo::models::Letter(180, 19,'h', 0x00,0xA8,0x00);
gathrillo::models::Letter(190, 18,'t', 0x00,0xA8,0x00);

gathrillo::models::Letter(213, 21,'o', 0x00,0xA8,0x00);
gathrillo::models::Letter(220, 21,'c', 0x00,0xA8,0x00);
gathrillo::models::Letter(230, 20,'e', 0x00,0xA8,0x00);    
gathrillo::models::Letter(240, 22,'a', 0x00,0xA8,0x00);
gathrillo::models::Letter(250, 20,'n', 0x00,0xA8,0x00);    

    
    
}
    
    
if(menu_highlight == 0) {    

gathrillo::models::Letter(137,121,'s', 0xA8,0x00,0x00);
gathrillo::models::Letter(145,120,'t', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,122,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(165,120,'r', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(175,120,'y', 0xA8, 0x00, 0x00);

    
    
gathrillo::models::Letter(137,140,'l', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(145,140,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,140,'c', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(165,141,'a', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(175,140,'l', 0xA8, 0x00, 0x00);
    
    
gathrillo::models::Letter(137,160,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(145,160,'n', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,160,'l', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(162,159,'i', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(172,160,'n', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(182,160,'e', 0xA8, 0x00, 0x00);

}

    
    
   
if(menu_highlight == 1) {    

gathrillo::models::Letter(137,121,'s', 0xFF,0xFF,0xFF);
gathrillo::models::Letter(145,120,'t', 0xFF,0xFF,0xFF);
gathrillo::models::Letter(155,122,'o', 0xFF,0xFF,0xFF);
gathrillo::models::Letter(165,120,'r', 0xFF,0xFF,0xFF);
gathrillo::models::Letter(175,120,'y', 0xFF,0xFF,0xFF);

    
    
gathrillo::models::Letter(137,140,'l', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(145,140,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,140,'c', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(165,141,'a', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(175,140,'l', 0xA8, 0x00, 0x00);
    
    
gathrillo::models::Letter(137,160,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(145,160,'n', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,160,'l', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(162,159,'i', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(172,160,'n', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(182,160,'e', 0xA8, 0x00, 0x00);

}

    

  
if(menu_highlight == 2) {    

gathrillo::models::Letter(137,121,'s', 0xA8,0x00,0x00);
gathrillo::models::Letter(145,120,'t', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,122,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(165,120,'r', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(175,120,'y', 0xA8, 0x00, 0x00);

    
    
gathrillo::models::Letter(137,140,'l', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(145,140,'o', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(155,140,'c', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(165,141,'a', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(175,140,'l', 0xFF, 0xFF, 0xFF);
    
    
gathrillo::models::Letter(137,160,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(145,160,'n', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,160,'l', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(162,159,'i', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(172,160,'n', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(182,160,'e', 0xA8, 0x00, 0x00);

}

 
    
 
if(menu_highlight == 3) {    

gathrillo::models::Letter(137,121,'s', 0xA8,0x00,0x00);
gathrillo::models::Letter(145,120,'t', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,122,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(165,120,'r', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(175,120,'y', 0xA8, 0x00, 0x00);

    
    
gathrillo::models::Letter(137,140,'l', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(145,140,'o', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(155,140,'c', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(165,141,'a', 0xA8, 0x00, 0x00);
gathrillo::models::Letter(175,140,'l', 0xA8, 0x00, 0x00);
    
    
gathrillo::models::Letter(137,160,'o', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(145,160,'n', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(155,160,'l', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(162,159,'i', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(172,159,'n', 0xFF, 0xFF, 0xFF);
gathrillo::models::Letter(182,160,'e', 0xFF, 0xFF, 0xFF);

}

    
if(menu_highlight == 40) {    
    
    
    
gathrillo::models::BoxerDavieSprite1(x,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
        
    
    
    
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);     
        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
    
/*    
    
gathrillo::gui::Window pix9(&desktop5, 90, 330, 100, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix9);     
        
            
    
   */ 
    
desktop5.Draw(&vga5);

    }
    
    
    
    
 
if(menu_highlight == 41) {    
    
gathrillo::gui::Window aa1(&desktop5, 9, 0+ 30, 120+ 0 , 10, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop5, 9, 0+ 40, 120+ 1 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop5, 9, 0+ 29, 120+ 1 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop5, 9, 0+ 41, 120+ 2 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop5, 9, 0+ 29, 120+ 2 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop5, 9, 0+ 42, 120+ 3 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop5, 9, 0+ 28, 120+ 3 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop5, 9, 0+ 28, 120+ 4 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop5, 9, 0+ 42, 120+ 4 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop5, 9, 0+ 27, 120+ 5 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop5, 9, 0+ 42, 120+ 5 , 1, 4, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop5, 9, 0+ 27, 120+ 5 , 1, 14, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa12); 
    
    
    
     
gathrillo::gui::Window aa13(&desktop5, 9, 0+ 28, 120+ 19 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop5, 9, 0+ 29, 120+ 20 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop5, 9, 0+ 30, 120+ 21 , 1, 5, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop5, 9, 0+ 42, 120+ 9 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop5, 9, 0+ 43, 120+ 10 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop5, 9, 0+ 43, 120+ 11 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop5, 9, 0+ 42, 120+ 12 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop5, 9, 0+ 42, 120+ 13 , 1, 6, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop5, 9, 0+ 41, 120+ 19 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop5, 9, 0+ 40, 120+ 20 , 1, 1, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop5, 9, 0+ 39, 120+ 21 , 1, 5, 0x00 , 0x00, 0xA8, 4); 
desktop5.AddChild(&aa24);   
       
    
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
    
     
if(menu_highlight == 42) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
    
    
     
     
if(menu_highlight == 43) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFF, 0xFE, 0xFF, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
    
    
     
     
if(menu_highlight == 44) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
        
     
if(menu_highlight == 45) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
    
    
    
    
if(menu_highlight == 46) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFF, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
if(menu_highlight == 47) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
if(menu_highlight == 48) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
     
if(menu_highlight == 49) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
if(menu_highlight == 50) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
if(menu_highlight == 51) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
if(menu_highlight == 52) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
if(menu_highlight == 53) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
if(menu_highlight == 54) {    
 
    
      
gathrillo::gui::Window pix1(&desktop5, 90, 20, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix1);  
    
    

    

        
gathrillo::gui::Window pix2(&desktop5, 90, 60, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix2);     
        
gathrillo::gui::Window pix3(&desktop5, 90, 100, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix3);     
        
gathrillo::gui::Window pix4(&desktop5, 90, 140, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix4);     
        
gathrillo::gui::Window pix5(&desktop5, 90, 180, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix5);     
        
    
gathrillo::gui::Window pix6(&desktop5, 90, 220, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix6);  
    
    
gathrillo::gui::Window pix7(&desktop5, 90, 255, 120, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix7);      

    
    
    

gathrillo::gui::Window pix11(&desktop5, 90, 20, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix11);     
        
gathrillo::gui::Window pix12(&desktop5, 90, 60, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix12);     
        
gathrillo::gui::Window pix13(&desktop5, 90, 100, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix13);     
        
gathrillo::gui::Window pix14(&desktop5, 90, 140, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix14);     
        
gathrillo::gui::Window pix15(&desktop5, 90, 180, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix15);     
        
    
gathrillo::gui::Window pix16(&desktop5, 90, 220, 160, 30, 30, 0xFE, 0xFE, 0xFE, 4);
desktop5.AddChild(&pix16);  
    
    
gathrillo::gui::Window pix17(&desktop5, 90, 255, 160, 30, 30, 0xFF, 0xFF, 0xFF, 4);
desktop5.AddChild(&pix17);      
    
 
    
desktop5.Draw(&vga5);

    }
       
    
    
    
};

  Menu::~Menu()
 {
     
 }






Letter::Letter(common::int32_t x, common::int32_t y, char c, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
    
   if(c == 'a') {
        
   gathrillo::gui::Window pix1(&desktop5, 90, x, y, 1, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    gathrillo::gui::Window pix2(&desktop5, 90, x-1, y+1, 1, 1, r, g, b, 4);
     desktop5.AddChild(&pix2); 
    
    
    gathrillo::gui::Window pix3(&desktop5, 90, x+1, y+1, 1, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    desktop5.Draw(&vga5);

    }

    
    
   if(c == 'u') {
        
   gathrillo::gui::Window pix1(&desktop5, 90, x, y+7, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    desktop5.Draw(&vga5);
    }
    
     if(c == 'o') {
        
     gathrillo::gui::Window pix1(&desktop5, 90, x, y+7, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+1, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    desktop5.Draw(&vga5);
    }
    
    
   if(c == 'p') {
        
   gathrillo::gui::Window pix1(&desktop5, 90, x, y+4, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 2, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    desktop5.Draw(&vga5);
    }
    
    
    if(c == 'r') {
        
     gathrillo::gui::Window pix1(&desktop5, 90, x, y+6, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    gathrillo::gui::Dline can2(90, 1, x+2, y+6, 1, 3, r,  g,  b);

    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 6, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 8, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    desktop5.Draw(&vga5);
    }
    
    
    


   if(c == 's') {
        
   gathrillo::gui::Window pix1(&desktop5, 90, x, y+2, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+6, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    
    
      gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+6, 1, 5, r, g, b, 4);
      desktop5.AddChild(&pix6); 
    
    
    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x, y+10, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
    if(c == 'e') {
        
    gathrillo::gui::Window pix1(&desktop5, 90, x, y+5, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    // gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
    // desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 7, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
      //desktop5.AddChild(&pix6); 
    
    
    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x, y+8, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
    
    if(c == 'f') {
        
    gathrillo::gui::Window pix1(&desktop5, 90, x, y+4, 4, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 4, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    // gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
    // desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 7, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
      //desktop5.AddChild(&pix6); 
    
    
    
    
    //gathrillo::gui::Window pix7(&desktop5, 90, x, y+6, 2, 1, r, g, b, 4);
     //desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
    
    if(c == 'h') {
        
    gathrillo::gui::Window pix1(&desktop5, 90, x, y+6, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    //gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 2, 1, r, g, b, 4);
     //desktop5.AddChild(&pix3); 
    
    
    
    
     gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 8, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    
    
      gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 5, r, g, b, 4);
      desktop5.AddChild(&pix6); 
    
    
    
    
    //gathrillo::gui::Window pix7(&desktop5, 90, x, y+6, 2, 1, r, g, b, 4);
     //desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
     if(c == 'i') {
        
     gathrillo::gui::Window pix1(&desktop5, 90, x, y+3, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x-2, y+2, 5, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    //gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     //desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x-2, y+8, 5, 1, r, g, b, 4);
    desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
    
    
    if(c == 'c') {
        
    // gathrillo::gui::Window pix1(&desktop5, 90, x, y+3, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 4, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x, y+2, 1, 5, r, g, b, 4);
    desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x, y+6, 4, 1, r, g, b, 4);
    desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    

     if(c == 'd') {
        
     gathrillo::gui::Window pix1(&desktop5, 90, x+4, y+3, 1, 3, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 4, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x, y+2, 1, 5, r, g, b, 4);
    desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x, y+6, 4, 1, r, g, b, 4);
    desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    

    
    
    
     if(c == 'j') {
        
     gathrillo::gui::Window pix1(&desktop5, 90, x+3, y+3, 1, 7, r, g, b, 4);
    desktop5.AddChild(&pix1); 
    
    
    
    
         
     //gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 3, 1, r, g, b, 4);
     //desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    //gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
    //desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x, y+3, 6, 1, r, g, b, 4);
    desktop5.AddChild(&pix7); 
    
    gathrillo::gui::Window pix8(&desktop5, 90, x-1, y+10, 4, 1, r, g, b, 4);
    desktop5.AddChild(&pix8); 
    
    
    
    
    
    desktop5.Draw(&vga5);
    }
    

      if(c == 'l') {
        
     //gathrillo::gui::Window pix1(&desktop5, 90, x, y+4, 2, 1, r, g, b, 4);
     //desktop5.AddChild(&pix1); 
    
    
    
    
         
     //gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 2, 1, r, g, b, 4);
     //desktop5.AddChild(&pix3); 
    
    
    
    
    // gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
    // desktop5.AddChild(&pix4); 
    
    
    
     
     gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 6, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
      //desktop5.AddChild(&pix6); 
    
    
    
    
     gathrillo::gui::Window pix7(&desktop5, 90, x, y+7, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix7); 
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
    
     if(c == 't') {
        
     gathrillo::gui::Window pix1(&desktop5, 90, x+3, y+3, 1, 7, r, g, b, 4);
    desktop5.AddChild(&pix1); 
    
    
    
    
         
     //gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 3, 1, r, g, b, 4);
     //desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    //gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
    //desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x, y+3, 6, 1, r, g, b, 4);
    desktop5.AddChild(&pix7); 
    
    //gathrillo::gui::Window pix8(&desktop5, 90, x-1, y+10, 4, 1, r, g, b, 4);
    //desktop5.AddChild(&pix8); 
    
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
    
    
    if(c == 'k') {
        
    gathrillo::gui::Window pix1(&desktop5, 90, x+3, y+3, 1, 8, r, g, b, 4);
    desktop5.AddChild(&pix1); 
    
    gathrillo::gui::Dline can(90, 3, x+7, y+4, 1, 5, r,  g,  b);
    gathrillo::gui::Dline can2(90, 1, x+5, y+8, 1, 3, r,  g,  b);

    
         
     //gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 3, 1, r, g, b, 4);
     //desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    //gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
    //desktop5.AddChild(&pix5);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
   // gathrillo::gui::Window pix7(&desktop5, 90, x, y+3, 6, 1, r, g, b, 4);
    //desktop5.AddChild(&pix7); 
    
    //gathrillo::gui::Window pix8(&desktop5, 90, x-1, y+10, 4, 1, r, g, b, 4);
    //desktop5.AddChild(&pix8); 
    
    
    
    
    
    desktop5.Draw(&vga5);
    }
   
    
    
    
   if(c == 'n') {
        
   // gathrillo::gui::Window pix1(&desktop5, 90, x+3, y+3, 1, 8, r, g, b, 4);
    //desktop5.AddChild(&pix1); 
    
    //gathrillo::gui::Dline can(90, 3, x+10, y+4, 1, 5, r,  g,  b);
   gathrillo::gui::Dline can2(90, 1, x, y+2, 1, 5, r,  g,  b);

    
         
     //gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 3, 1, r, g, b, 4);
     //desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 6, r, g, b, 4);
    desktop5.AddChild(&pix5);
         
     
     
    gathrillo::gui::Window pix9(&desktop5, 90, x+5, y+2, 1, 6, r, g, b, 4);
    desktop5.AddChild(&pix9);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
   // gathrillo::gui::Window pix7(&desktop5, 90, x, y+3, 6, 1, r, g, b, 4);
    //desktop5.AddChild(&pix7); 
    
    //gathrillo::gui::Window pix8(&desktop5, 90, x-1, y+10, 4, 1, r, g, b, 4);
    //desktop5.AddChild(&pix8); 
    
    
    
    
    
    desktop5.Draw(&vga5);
    }
    
    
    
    
   if(c == 'm') {
        
   // gathrillo::gui::Window pix1(&desktop5, 90, x+3, y+3, 1, 8, r, g, b, 4);
    //desktop5.AddChild(&pix1); 
    
    gathrillo::gui::Dline can(90, 3, x+5, y+2, 1, 3, r,  g,  b);
    gathrillo::gui::Dline can2(90, 1, x, y+2, 1, 3, r,  g,  b);

    
         
     //gathrillo::gui::Window pix3(&desktop5, 90, x, y+2, 3, 1, r, g, b, 4);
     //desktop5.AddChild(&pix3); 
    
    
    
    
     //gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 3, r, g, b, 4);
     //desktop5.AddChild(&pix4); 
    
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 6, r, g, b, 4);
    desktop5.AddChild(&pix5);
         
     
     
    gathrillo::gui::Window pix9(&desktop5, 90, x+6, y+2, 1, 6, r, g, b, 4);
    desktop5.AddChild(&pix9);
    
    
    
    
      //gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     //desktop5.AddChild(&pix6); 
    
    
    
    
   // gathrillo::gui::Window pix7(&desktop5, 90, x, y+3, 6, 1, r, g, b, 4);
    //desktop5.AddChild(&pix7); 
    
    //gathrillo::gui::Window pix8(&desktop5, 90, x-1, y+10, 4, 1, r, g, b, 4);
    //desktop5.AddChild(&pix8); 
    
    
    
    
    
    desktop5.Draw(&vga5);
    }
        
    
     if(c == 'q') {
        
   gathrillo::gui::Window pix1(&desktop5, 90, x, y+7, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+1, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
     gathrillo::gui::Dline can2(90, 1, x, y+6, 1, 3, r,  g,  b);
     
         
         
         
    desktop5.Draw(&vga5);
    }
    
    
    
       
    
    
    if(c == 'g') {
        
     gathrillo::gui::Window pix1(&desktop5, 90, x, y+7, 2, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
         
    gathrillo::gui::Window pix3(&desktop5, 90, x, y+1, 3, 1, r, g, b, 4);
     desktop5.AddChild(&pix3); 
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+2, y+5, 1, 2, r, g, b, 4);
     desktop5.AddChild(&pix4);
        
        
    
    gathrillo::gui::Window pix6(&desktop5, 90, x+1, y+4, 3, 1, r, g, b, 4);
     desktop5.AddChild(&pix6);     
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    desktop5.Draw(&vga5);
    }
  
     if(c == 'v') {
        
   gathrillo::gui::Window pix1(&desktop5, 90, x, y+7, 1, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    desktop5.Draw(&vga5);
    }
    
    if(c == 'w') {
        
   gathrillo::gui::Window pix1(&desktop5, 90, x, y+7, 1, 1, r, g, b, 4);
     desktop5.AddChild(&pix1); 
    
    
    
    
    
    
    
    
    gathrillo::gui::Window pix4(&desktop5, 90, x+1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix4); 
    
    
     
    gathrillo::gui::Window pix5(&desktop5, 90, x-1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix5);
    
    
    
        
        
     gathrillo::gui::Window pix6(&desktop5, 90, x+2, y+7, 1, 1, r, g, b, 4);
     desktop5.AddChild(&pix6); 
    

    
    
    gathrillo::gui::Window pix7(&desktop5, 90, x+3, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix7); 
    
    
     
    gathrillo::gui::Window pix8(&desktop5, 90, x+1, y+2, 1, 5, r, g, b, 4);
     desktop5.AddChild(&pix8);
    
    
    desktop5.Draw(&vga5);
    }
    
   
    if(c == 'x') {
        
    gathrillo::gui::Dline can(90, 3, x+5, y+2, 1, 6, r,  g,  b);
    gathrillo::gui::Dline can2(90, 1, x, y+2, 1, 6, r,  g,  b);

    
    
    desktop5.Draw(&vga5);
    }
    
    
    
    if(c == 'y') {
        
    gathrillo::gui::Dline can(90, 3, x+6, y+1, 1, 8, r,  g,  b);
    gathrillo::gui::Dline can2(90, 1, x-1, y+1, 1, 4, r,  g,  b);

    
    
    desktop5.Draw(&vga5);
    }
    
    if(c == 'z') {
        
    gathrillo::gui::Dline can(90, 3, x+5, y+2, 1, 6, r,  g,  b);

    gathrillo::gui::Window pix7(&desktop5, 90, x, y+2, 6, 1, r, g, b, 4);
    desktop5.AddChild(&pix7); 
        
    gathrillo::gui::Window pix8(&desktop5, 90, x, y+8, 6, 1, r, g, b, 4);
    desktop5.AddChild(&pix8); 
    
    desktop5.Draw(&vga5);
    }
    
    
};

  Letter::~Letter()
 {
     
 }















P1h::P1h(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
        
gathrillo::gui::Window back9(&desktop5, 90, 30, 5, w, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&back9); 
    
      
gathrillo::gui::Window back10(&desktop5, 90, 30, 5, 100, 10, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&back10);
    
    
    desktop5.Draw(&vga5);

    
    
};

  P1h::~P1h()
 {
     
 }


P2h::P2h(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
        
gathrillo::gui::Window back9(&desktop5, 90, 185+(100-w), 5, w, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&back9); 
    
      
gathrillo::gui::Window back10(&desktop5, 90, 185, 5, 100, 10, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&back10);
    
    desktop5.Draw(&vga5);

    
    
};

  P2h::~P2h()
 {
     
 }















BoxerPunchAnim::BoxerPunchAnim(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
int sprite = 0;
    
    
 //TaskManager taskManager; 
  
 GlobalDescriptorTable gdt;
  
 ////gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);  
     
// gathrillo::drivers::PIT pit(&interrupts);    

        
    
 for(int i = 1; i <= 3; i++)  
 {
     
     
     
gathrillo::gui::Window back1(&desktop5, 90, x, y, 70, 100, 0xFF, 0xFF, 0xFF, 4);
     
 
if(sprite < 1) {
     
desktop5.AddChild(&back1); 
    
 }
     
if(sprite == 0) 
    
{
     
gathrillo::models::BoxerDavieSprite1(x,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
    
//pit.Sleep(100);
    
  
}
    
     
if(sprite == 1) 
    
{
    

    
    

gathrillo::models::BoxerDavieSprite2(x,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
 
//pit.Beep(650, 500);
    

//pit.Sleep(50);

    
    
}

if(sprite == 2) {  
    
    
    

    
gathrillo::models::BoxerDavieSprite3(x,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
      
//pit.Sleep(2050);
  
    
}
    
     
if(sprite == 3) 
    
{
    

    
    

gathrillo::models::BoxerDavieSprite2(x,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
      
    
}     
     

     
  
       
   // Pit.music1();     
    desktop5.Draw(&vga5);

    sprite++;
}

  

    
    

gathrillo::models::BoxerDavieSprite1(x,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
      
 
    
 
    
    
};

  BoxerPunchAnim::~BoxerPunchAnim()
 {
     
 }




BoxerWalkSprite1::BoxerWalkSprite1(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
  
    
 
    
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
      
    
    
 //arm   
  
gathrillo::gui::Window ad1(&desktop6, 9,  2+30+x, 30+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad1);   
        
gathrillo::gui::Window bd1(&desktop6, 9,  2+29+x, 31+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd1);  
        
        
gathrillo::gui::Window bd2(&desktop6, 9,  2+29+x, 31+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd2);  
        
        
gathrillo::gui::Window bd3(&desktop6, 9,  2+28+x, 33+y  -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd3);  
        
        
gathrillo::gui::Window bd4(&desktop6, 9,  2+29+x, 36+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd4);
   
gathrillo::gui::Window bd5(&desktop6, 9,  2+30+x, 38+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd5);  
        

gathrillo::gui::Window ad2(&desktop6, 9,  2+35+x, 39+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad2);    
        
gathrillo::gui::Window cd1(&desktop6, 9,  2+35+x, 30+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cd1);   
        
gathrillo::gui::Window d1(&desktop6, 9,  2+36+x, 31+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d1);  
        
        
gathrillo::gui::Window dd2(&desktop6, 9,  2+36+x, 31+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd2);  
        
        
gathrillo::gui::Window dd3(&desktop6, 9,  2+37+x, 33+y  -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd3);  
              
gathrillo::gui::Window dd4(&desktop6, 9,  2+36+x, 36+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd4);
              
gathrillo::gui::Window dd5(&desktop6, 9,  2+35+x, 38+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd5);  
        
gathrillo::gui::Window ed1(&desktop6, 9,  2+30+x, 40+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed1);   
        
gathrillo::gui::Window fd1(&desktop6, 9,  2+29+x, 41+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd1);  
              
gathrillo::gui::Window fd2(&desktop6, 9,  2+29+x, 41+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd2);       
        
gathrillo::gui::Window fd3(&desktop6, 9,  2+28+x, 43+y  -3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd3);       
        
gathrillo::gui::Window fd4(&desktop6, 9,  2+29+x, 48+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd4);   
        
gathrillo::gui::Window fd5(&desktop6, 9,  2+30+x, 50+y  -3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd5);  
    
gathrillo::gui::Window ed2(&desktop6, 9,  2+35+x, 51+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed2);  
        
gathrillo::gui::Window gd0(&desktop6, 9,  2+35+x, 40+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd0);   
        
gathrillo::gui::Window gd1(&desktop6, 9,  2+36+x, 41+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd1);  
        
        
gathrillo::gui::Window gd2(&desktop6, 9,  2+36+x, 41+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd2);  
        
        
gathrillo::gui::Window gd3(&desktop6, 9,  2+37+x, 43+y  -3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd3);  
        
        
gathrillo::gui::Window gd4(&desktop6, 9,  2+36+x, 48+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd4);
        
        
        
gathrillo::gui::Window gd5(&desktop6, 9,  2+35+x, 50+y  -3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd5);  
  

gathrillo::gui::Window ad5(&desktop6, 9,  2+30+x, 52+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad5); 

        
gathrillo::gui::Window ad6(&desktop6, 9,  2+30+x, 54+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad6); 
 
gathrillo::gui::Window ad7(&desktop6, 9,  2+29+x, 55+y -3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad7); 
        
gathrillo::gui::Window ad8(&desktop6, 9,  2+36+x, 55+y -3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop6, 9,  2+28+x, 57+y -3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9,  2+28+x, 57+y -3, 9,  2+8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9,  2+30+x, 65+y -3, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9,  2+30+x, 56+y -3, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9,  2+37+x, 57+y -3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop6, 9,  2+29+x, 65+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop6, 9,  2+36+x, 65+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop6, 9,  2+30+x, 66+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a13);
    
      
    
    
    
    
    
    
    
    
  //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    

// legs            
gathrillo::gui::Window ab1(&desktop6, 9, 29+x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zb1(&desktop6, 9, 28+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 28+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 42+x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 43+x, 53+y, 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
    
gathrillo::gui::Window zb5(&desktop6, 9, 44+x, 56+y, 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb5);    

gathrillo::gui::Window zb6(&desktop6, 9, 45+x, 59+y, 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb6);    
    
gathrillo::gui::Window zb7(&desktop6, 9, 46+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb7);          
//        
   
    
    
    
gathrillo::gui::Window ab3(&desktop6, 9, 29+x, 64+y , 9, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop6, 9, 36+x, 56+y, 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 29+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 28+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        

    
    
  
    
   /////////////////////// 
    
  gathrillo::gui::Window gb7(&desktop6, 9, 36+x, 64+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gb7);
        
gathrillo::gui::Window gb8(&desktop6, 9, 35+x, 70+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gb8);
        
gathrillo::gui::Window gb9(&desktop6, 9, 34+x, 76+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gb9);
          
  ///////////  
    
    
    
    
    
   
    
    
gathrillo::gui::Window ab7(&desktop6, 9, 27+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop6, 9, 27+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop6, 9, 26+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
 


        
gathrillo::gui::Window bb1(&desktop6, 9, 35+x +5, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb1);
        
gathrillo::gui::Window bb2(&desktop6, 9, 36+x +3, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop6, 9, 36+x +3, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop6, 9, 36+x +3, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop6, 9, 35+x +5, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop6, 9, 40+x +5, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop6, 9, 41+x +5, 67+y, 1, 16, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop6, 9, 41+x +5, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop6, 9, 41+x +5, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop6, 9, 40+x +5, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb5);
      
        
  
desktop6.Draw(&vga6);
     
    
};

  BoxerWalkSprite1::~BoxerWalkSprite1()
 {
     
 }




BoxerWalkAnim::BoxerWalkAnim(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
int sprite = 0;
    
    
 //TaskManager taskManager; 
  
 GlobalDescriptorTable gdt;
  
 ////gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);  
     
// gathrillo::drivers::PIT pit(&interrupts);    

        
    
 for(int i = 1; i <= 2; i++)  
 {
     
     
     
gathrillo::gui::Window back1(&desktop5, 90, x, y, 70, 100, 0xFF, 0xFF, 0xFF, 4);
     
 
if(sprite < 1) {
     
desktop5.AddChild(&back1); 
    
 }
     
if(sprite == 0) 
    
{
     
gathrillo::models::BoxerDavieSprite1(x,105,0,0,0x00,0x00,0x00);

    
 


gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
    
//pit.Sleep(2);
    
  
}
    
     
if(sprite == 1) 
    
{
    

    
    

gathrillo::models::BoxerWalkSprite1(x,105,0,0,0x00,0x00,0x00);

gathrillo::models::Shoes2(x-2,105,0,0,0x00,0x00,0x00);

gathrillo::models::Shoes2(x+11,105,0,0,0x00,0x00,0x00);
        
   

//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  

//pit.Sleep(1000);
    
    
}
 
       
   // Pit.music1();     
    desktop5.Draw(&vga5);

    sprite++;
}

  

    
    

gathrillo::models::BoxerDavieSprite1(x,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
      
 
    
 
    
    
};

  BoxerWalkAnim::~BoxerWalkAnim()
 {
     
 }
 


BoxerCrouchAnim::BoxerCrouchAnim(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, bool repeat)
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
int sprite = 0;
    
    
 //TaskManager taskManager; 
  
 //GlobalDescriptorTable gdt;
  
 //gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);  
     
 //gathrillo::drivers::PIT pit(&interrupts);    

        
    
 for(int i = 1; i <= 3; i++)  
 {
     
    gathrillo::gui::Window back1(&desktop5, 90, x, y, 70, 100, 0xFF, 0xFF, 0xFF, 4);

     
if(sprite < 1) {
     
desktop5.AddChild(&back1); 
    
 }
     
if(sprite == 0) 
    
{
     
    

 //Body  
    
    
////gathrillo::models::BoxerDavieArm(x,125,0,0,0x00,0x00,0x00,0);
  

  
gathrillo::models::BoxerDavieCrouchSprite(x,125,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
    
//pit.Sleep(2000);
    
  
}
    
     
if(sprite == 1) 
    
{
    


    

//gathrillo::models::BoxerDavieCrouchSprite(x,125,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  
 //Body  
    
gathrillo::gui::Window back2(&desktop5, 90, x, y, 70, 100, 0xFF, 0xFF, 0xFF, 4);

desktop5.AddChild(&back2); 

    
//pit.Sleep(50);
    
 
}
 
       
   // Pit.music1();    
     
    
      
     
    desktop5.Draw(&vga5);

    sprite++;
     
      
}

   
    
 
 


    
    
  
    
gathrillo::gui::Window ad1(&desktop5, 9, 30+x+2, 30+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ad1);   
        
gathrillo::gui::Window bd1(&desktop5, 9, 29+x+2, 31+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd1);  
        
        
gathrillo::gui::Window bd2(&desktop5, 9, 29+x+2, 31+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd2);  
        
        
gathrillo::gui::Window bd3(&desktop5, 9, 28+x+2, 33+y-3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd3);  
        
        
gathrillo::gui::Window bd4(&desktop5, 9, 29+x+2, 36+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd4);
   
gathrillo::gui::Window bd5(&desktop5, 9, 30+x+2, 38+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd5);  
        

gathrillo::gui::Window ad2(&desktop5, 9, 35+x+2, 39+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ad2);    
        
gathrillo::gui::Window cd1(&desktop5, 9, 35+x+2, 30+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cd1);   
        
gathrillo::gui::Window d1(&desktop5, 9, 36+x+2, 31+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&d1);  
        
        
gathrillo::gui::Window dd2(&desktop5, 9, 36+x+2, 31+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd2);  
        
        
gathrillo::gui::Window dd3(&desktop5, 9, 37+x+2, 33+y-3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd3);  
              
gathrillo::gui::Window dd4(&desktop5, 9, 36+x+2, 36+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd4);
              
gathrillo::gui::Window dd5(&desktop5, 9, 35+x+2, 38+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd5);  
        
gathrillo::gui::Window ed1(&desktop5, 9, 30+x+2, 40+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ed1);   
        
gathrillo::gui::Window fd1(&desktop5, 9, 29+x+2, 41+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd1);  
              
gathrillo::gui::Window fd2(&desktop5, 9, 29+x+2, 41+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd2);       
        
gathrillo::gui::Window fd3(&desktop5, 9, 28+x+2, 43+y-3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd3);       
        
gathrillo::gui::Window fd4(&desktop5, 9, 29+x+2, 48+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd4);   
        
gathrillo::gui::Window fd5(&desktop5, 9, 30+x+2, 50+y-3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd5);  
    
gathrillo::gui::Window ed2(&desktop5, 9, 35+x+2, 51+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ed2);  
        
gathrillo::gui::Window gd0(&desktop5, 9, 35+x+2, 40+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd0);   
        
gathrillo::gui::Window gd1(&desktop5, 9, 36+x+2, 41+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd1);  
        
        
gathrillo::gui::Window gd2(&desktop5, 9, 36+x+2, 41+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd2);  
        
        
gathrillo::gui::Window gd3(&desktop5, 9, 37+x+2, 43+y-3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd3);  
        
        
gathrillo::gui::Window gd4(&desktop5, 9, 36+x+2, 48+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd4);
        
        
        
gathrillo::gui::Window gd5(&desktop5, 9, 35+x+2, 50+y-3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd5);  
  

gathrillo::gui::Window ad5(&desktop5, 9, 30+x+2, 52+y-3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad5); 

        
gathrillo::gui::Window ad6(&desktop5, 9, 30+x+2, 54+y-3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad6); 
 
gathrillo::gui::Window ad7(&desktop5, 9, 29+x+2, 55+y-3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad7); 
        
gathrillo::gui::Window ad8(&desktop5, 9, 36+x+2, 55+y-3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop5, 9, 28+x+2, 57+y-3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop5, 9, 28+x+2, 57+y-3, 9, 8, 0x00 , 0x00, 0xAF, 4);
//desktop5.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop5, 9, 30+x+2, 65+y-3, 6, 1, 0x00 , 0x00, 0xAF, 4);
//desktop5.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop5, 9, 30+x+2, 56+y-3, 6, 1, 0x00 , 0x00, 0xAF, 4);
//desktop5.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop5, 9, 37+x+2, 57+y-3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop5, 9, 29+x+2, 65+y-3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop5, 9, 36+x+2, 65+y-3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop5, 9, 30+x+2, 66+y-3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a13);  
    

//Body  
    
      
gathrillo::gui::Window aa1(&desktop5, 9, x+ 30, y+0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop5, 9, x+ 40, y+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop5, 9, x+ 29, y+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop5, 9, x+ 41, y+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop5, 9, x+ 29, y+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop5, 9, x+ 42, y+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop5, 9, x+ 28, y+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop5, 9, x+ 28, y+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop5, 9, x+ 42, y+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop5, 9, x+ 27, y+5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop5, 9, x+ 42, y+5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop5, 9, x+ 27, y+5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop5, 9, x+ 28, y+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop5, 9, x+ 29, y+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop5, 9, x+ 30, y+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop5, 9, x+ 42, y+9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop5, 9, x+ 43, y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop5, 9, x+ 43, y+11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop5, 9, x+ 42, y+12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop5, 9, x+ 42, y+13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop5, 9, x+ 41, y+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop5, 9, x+ 40, y+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop5, 9, x+ 39, y+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop5, 9, x+ 40, y+26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop5, 9, x+ 41, y+27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop5, 9, x+ 40, y+50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop5, 9, x+ 29, y+26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop5, 9, x+ 30, y+34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop5, 9, x+ 29, y+42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop5, 9, x+ 30, y + 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa31);   

       
    
     
    
    

// legs            
gathrillo::gui::Window ab1(&desktop5, 9, 29 +x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab1);  
        
        
gathrillo::gui::Window zbbbb1(&desktop5, 9, 28 +x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zbbbb1);  
        
gathrillo::gui::Window zb2(&desktop5, 9, 28 +x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop5, 9, 41 +x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop5, 9, 41 +x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop5, 9, 41 +x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop5, 9, 29 +x, 64+y , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop5, 9, 36 +x, 56+y, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop5, 9, 29 +x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop5, 9, 28 +x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop5, 9, 28 +x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop5, 9, 28 +x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop5, 9, 29 +x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop5, 9, 35 +x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop5, 9, 36 +x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop5, 9, 36 +x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop5, 9, 36 +x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop5, 9, 35 +x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop5, 9, 40 +x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop5, 9, 41 +x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop5, 9, 41 +x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop5, 9, 41 +x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop5, 9, 40 +x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb5);

    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop5, 9, 29 +x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop5, 9, 36 +x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop5, 9, 29 +x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop5, 9, 36 +x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop5, 9, 40 +x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop5, 9, 29 +x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop5, 9, 29 +x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop5, 9, 39 +x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop5, 9, 41 +x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop5, 9, 40 +x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop5, 9, 45 +x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop5.AddChild(&azzc11);   
    
    
  desktop5.Draw(&vga5);
 
     


//gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
      
 
    
 
    
    
};

  BoxerCrouchAnim::~BoxerCrouchAnim()
 {
     
 }
 



BoxerJumpAnim::BoxerJumpAnim(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, bool repeat)
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
int sprite = 0;
    
    
 //TaskManager taskManager; 
  
 GlobalDescriptorTable gdt;
  
 ////gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);  
     
//gathrillo::drivers::PIT pit(&interrupts);    

        
    
 for(int i = 1; i <= 5; i++)  
 {
     
    gathrillo::gui::Window back1(&desktop5, 90, x, y-85, 70, 185, 0xFF, 0xFF, 0xFF, 4);

     
if(sprite < 1) {
     
desktop5.AddChild(&back1); 
    
 }
     
if(sprite == 0) 
    
{     

gathrillo::models::BoxerWalkSprite1(x,100,0,0,0x00,0x00,0x00);

gathrillo::models::Shoes2(x-2,100,0,0,0x00,0x00,0x00);

gathrillo::models::Shoes2(x+11,100,0,0,0x00,0x00,0x00);
  
//pit.Sleep(1000);
    
    
}
    
    
if(sprite == 1) 
    
{
     
    

 //Body  
    
    
////gathrillo::models::BoxerDavieArm(x,125,0,0,0x00,0x00,0x00,0);
  

  
gathrillo::models::BoxerDavieCrouchSprite(x,120,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
    
//pit.Sleep(1000);
    
  
}
   

if(sprite == 2) 
    
{
    


    

//gathrillo::models::BoxerDavieCrouchSprite(x,125,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  
 //Body  
    
gathrillo::models::BoxerDavieCrouchSprite(x,20,0,0,0x00,0x00,0x00);

    
//pit.Sleep(1000);
    
 
}
   
     
     

if(sprite == 3) 
    
{
    


    

//gathrillo::models::BoxerDavieCrouchSprite(x,125,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  
 //Body  
    
gathrillo::models::BoxerDavieCrouchSprite(x,60,0,0,0x00,0x00,0x00);

    
//pit.Sleep(250);
    
 
}
     
     

     
     
   // Pit.music1();    
     
    
      
     
    desktop5.Draw(&vga5);

    sprite++;
     
      
}

   
    
 
 


    
    
  
    
gathrillo::gui::Window ad1(&desktop5, 9, 30+x+2, 30+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ad1);   
        
gathrillo::gui::Window bd1(&desktop5, 9, 29+x+2, 31+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd1);  
        
        
gathrillo::gui::Window bd2(&desktop5, 9, 29+x+2, 31+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd2);  
        
        
gathrillo::gui::Window bd3(&desktop5, 9, 28+x+2, 33+y-3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd3);  
        
        
gathrillo::gui::Window bd4(&desktop5, 9, 29+x+2, 36+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd4);
   
gathrillo::gui::Window bd5(&desktop5, 9, 30+x+2, 38+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bd5);  
        

gathrillo::gui::Window ad2(&desktop5, 9, 35+x+2, 39+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ad2);    
        
gathrillo::gui::Window cd1(&desktop5, 9, 35+x+2, 30+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cd1);   
        
gathrillo::gui::Window d1(&desktop5, 9, 36+x+2, 31+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&d1);  
        
        
gathrillo::gui::Window dd2(&desktop5, 9, 36+x+2, 31+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd2);  
        
        
gathrillo::gui::Window dd3(&desktop5, 9, 37+x+2, 33+y-3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd3);  
              
gathrillo::gui::Window dd4(&desktop5, 9, 36+x+2, 36+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd4);
              
gathrillo::gui::Window dd5(&desktop5, 9, 35+x+2, 38+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&dd5);  
        
gathrillo::gui::Window ed1(&desktop5, 9, 30+x+2, 40+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ed1);   
        
gathrillo::gui::Window fd1(&desktop5, 9, 29+x+2, 41+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd1);  
              
gathrillo::gui::Window fd2(&desktop5, 9, 29+x+2, 41+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd2);       
        
gathrillo::gui::Window fd3(&desktop5, 9, 28+x+2, 43+y-3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd3);       
        
gathrillo::gui::Window fd4(&desktop5, 9, 29+x+2, 48+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd4);   
        
gathrillo::gui::Window fd5(&desktop5, 9, 30+x+2, 50+y-3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
//desktop5.AddChild(&fd5);  
    
gathrillo::gui::Window ed2(&desktop5, 9, 35+x+2, 51+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ed2);  
        
gathrillo::gui::Window gd0(&desktop5, 9, 35+x+2, 40+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd0);   
        
gathrillo::gui::Window gd1(&desktop5, 9, 36+x+2, 41+y-3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd1);  
        
        
gathrillo::gui::Window gd2(&desktop5, 9, 36+x+2, 41+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd2);  
        
        
gathrillo::gui::Window gd3(&desktop5, 9, 37+x+2, 43+y-3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd3);  
        
        
gathrillo::gui::Window gd4(&desktop5, 9, 36+x+2, 48+y-3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd4);
        
        
        
gathrillo::gui::Window gd5(&desktop5, 9, 35+x+2, 50+y-3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&gd5);  
  

gathrillo::gui::Window ad5(&desktop5, 9, 30+x+2, 52+y-3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad5); 

        
gathrillo::gui::Window ad6(&desktop5, 9, 30+x+2, 54+y-3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad6); 
 
gathrillo::gui::Window ad7(&desktop5, 9, 29+x+2, 55+y-3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad7); 
        
gathrillo::gui::Window ad8(&desktop5, 9, 36+x+2, 55+y-3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&ad8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop5, 9, 28+x+2, 57+y-3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop5, 9, 28+x+2, 57+y-3, 9, 8, 0x00 , 0x00, 0xAF, 4);
//desktop5.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop5, 9, 30+x+2, 65+y-3, 6, 1, 0x00 , 0x00, 0xAF, 4);
//desktop5.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop5, 9, 30+x+2, 56+y-3, 6, 1, 0x00 , 0x00, 0xAF, 4);
//desktop5.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop5, 9, 37+x+2, 57+y-3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop5, 9, 29+x+2, 65+y-3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop5, 9, 36+x+2, 65+y-3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop5, 9, 30+x+2, 66+y-3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&a13);  
    

//Body  
    
      
gathrillo::gui::Window aa1(&desktop5, 9, x+ 30, y+0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop5, 9, x+ 40, y+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop5, 9, x+ 29, y+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop5, 9, x+ 41, y+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop5, 9, x+ 29, y+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop5, 9, x+ 42, y+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop5, 9, x+ 28, y+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop5, 9, x+ 28, y+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop5, 9, x+ 42, y+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop5, 9, x+ 27, y+5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop5, 9, x+ 42, y+5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop5, 9, x+ 27, y+5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop5, 9, x+ 28, y+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop5, 9, x+ 29, y+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop5, 9, x+ 30, y+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop5, 9, x+ 42, y+9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop5, 9, x+ 43, y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop5, 9, x+ 43, y+11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop5, 9, x+ 42, y+12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop5, 9, x+ 42, y+13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop5, 9, x+ 41, y+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop5, 9, x+ 40, y+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop5, 9, x+ 39, y+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop5, 9, x+ 40, y+26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop5, 9, x+ 41, y+27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop5, 9, x+ 40, y+50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop5, 9, x+ 29, y+26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop5, 9, x+ 30, y+34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop5, 9, x+ 29, y+42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop5, 9, x+ 30, y + 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa31);   

       
    
     
    
    

// legs            
gathrillo::gui::Window ab1(&desktop5, 9, 29 +x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab1);  
        
        
gathrillo::gui::Window zbbbb1(&desktop5, 9, 28 +x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zbbbb1);  
        
gathrillo::gui::Window zb2(&desktop5, 9, 28 +x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop5, 9, 41 +x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop5, 9, 41 +x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop5, 9, 41 +x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop5, 9, 29 +x, 64+y , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop5, 9, 36 +x, 56+y, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop5, 9, 29 +x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop5, 9, 28 +x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop5, 9, 28 +x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop5, 9, 28 +x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop5, 9, 29 +x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop5, 9, 35 +x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop5, 9, 36 +x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop5, 9, 36 +x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop5, 9, 36 +x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop5, 9, 35 +x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop5, 9, 40 +x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop5, 9, 41 +x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop5, 9, 41 +x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop5, 9, 41 +x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop5, 9, 40 +x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb5);

    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop5, 9, 29 +x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop5, 9, 36 +x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop5, 9, 29 +x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop5, 9, 36 +x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop5, 9, 40 +x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop5, 9, 29 +x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop5, 9, 29 +x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop5, 9, 39 +x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop5, 9, 41 +x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop5, 9, 40 +x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop5, 9, 45 +x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop5.AddChild(&azzc11);   
    
    
  desktop5.Draw(&vga5);
 
     


//gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
      
 
    
 
    
    
};

  BoxerJumpAnim::~BoxerJumpAnim()
 {
     
 }


BoxerDavieArm::BoxerDavieArm(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t act)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    


gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  
    
    
gathrillo::gui::Window ad1(&desktop6, 9, 30+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad1);   
        
gathrillo::gui::Window bd1(&desktop6, 9, 29+x, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd1);  
        
        
gathrillo::gui::Window bd2(&desktop6, 9, 29+x, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd2);  
        
        
gathrillo::gui::Window bd3(&desktop6, 9, 28+x, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd3);  
        
        
gathrillo::gui::Window bd4(&desktop6, 9, 29+x, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd4);
   
gathrillo::gui::Window bd5(&desktop6, 9, 30+x, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd5);  
        

gathrillo::gui::Window ad2(&desktop6, 9, 35+x, 39+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad2);    
        
gathrillo::gui::Window cd1(&desktop6, 9, 35+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cd1);   
        
gathrillo::gui::Window d1(&desktop6, 9, 36+x, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d1);  
        
        
gathrillo::gui::Window dd2(&desktop6, 9, 36+x, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd2);  
        
        
gathrillo::gui::Window dd3(&desktop6, 9, 37+x, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd3);  
              
gathrillo::gui::Window dd4(&desktop6, 9, 36+x, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd4);
              
gathrillo::gui::Window dd5(&desktop6, 9, 35+x, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd5);  
        
gathrillo::gui::Window ed1(&desktop6, 9, 30+x, 40+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed1);   
        
gathrillo::gui::Window fd1(&desktop6, 9, 29+x, 41+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd1);  
              
gathrillo::gui::Window fd2(&desktop6, 9, 29+x, 41+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd2);       
        
gathrillo::gui::Window fd3(&desktop6, 9, 28+x, 43+y , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd3);       
        
gathrillo::gui::Window fd4(&desktop6, 9, 29+x, 48+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd4);   
        
gathrillo::gui::Window fd5(&desktop6, 9, 30+x, 50+y , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd5);  
    
gathrillo::gui::Window ed2(&desktop6, 9, 35+x, 51+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed2);  
        
gathrillo::gui::Window gd0(&desktop6, 9, 35+x, 40+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd0);   
        
gathrillo::gui::Window gd1(&desktop6, 9, 36+x, 41+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd1);  
        
        
gathrillo::gui::Window gd2(&desktop6, 9, 36+x, 41+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd2);  
        
        
gathrillo::gui::Window gd3(&desktop6, 9, 37+x, 43+y , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd3);  
        
        
gathrillo::gui::Window gd4(&desktop6, 9, 36+x, 48+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd4);
        
        
        
gathrillo::gui::Window gd5(&desktop6, 9, 35+x, 50+y , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd5);  
  

gathrillo::gui::Window ad5(&desktop6, 9, 30+x, 52+y, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad5); 

        
gathrillo::gui::Window ad6(&desktop6, 9, 30+x, 54+y, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad6); 
 
gathrillo::gui::Window ad7(&desktop6, 9, 29+x, 55+y, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad7); 
        
gathrillo::gui::Window ad8(&desktop6, 9, 36+x, 55+y, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop6, 9, 28+x, 57+y, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9, 28+x, 57+y, 9, 8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9, 30+x, 65+y, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9, 30+x, 56+y, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9, 37+x, 57+y, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop6, 9, 29+x, 65+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop6, 9, 36+x, 65+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop6, 9, 30+x, 66+y, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a13);
    
   
desktop6.Draw(&vga6);

        
};

  BoxerDavieArm::~BoxerDavieArm()
 {
     
 }
























BoxerDavieArmAct2::BoxerDavieArmAct2(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t act)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    


gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  
    
    
gathrillo::gui::Window a1(&desktop6, 9, 30+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a1);   
        
gathrillo::gui::Window b1(&desktop6, 9, 31+x, 29+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b1);  
        
        
gathrillo::gui::Window b2(&desktop6, 9, 31+x, 29+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b2);  
        
        
gathrillo::gui::Window b3(&desktop6, 9, 33+x, 28+y , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b3);  
        
        
gathrillo::gui::Window b4(&desktop6, 9, 36+x, 23+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b4);
   
gathrillo::gui::Window b5(&desktop6, 9, 38+x, 30+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b5);  
        

gathrillo::gui::Window a2(&desktop6, 9, 39+x, 35+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a2);    
        
gathrillo::gui::Window c1(&desktop6, 9, 30+x, 35+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&c1);   
        
gathrillo::gui::Window d1(&desktop6, 9, 31+x, 36+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d1);  
        
        
gathrillo::gui::Window d2(&desktop6, 9, 31+x, 36+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d2);  
        
        
gathrillo::gui::Window d3(&desktop6, 9, 33+x, 37+y , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d3);  
              
gathrillo::gui::Window d4(&desktop6, 9, 36+x, 36+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d4);
              
gathrillo::gui::Window d5(&desktop6, 9, 38+x, 35+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d5);  
        
gathrillo::gui::Window e1(&desktop6, 9, 40+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&e1);   
        
gathrillo::gui::Window f1(&desktop6, 9, 41+x, 29+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f1);  
              
gathrillo::gui::Window f2(&desktop6, 9, 41+x, 29+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f2);       
        
gathrillo::gui::Window f3(&desktop6, 9, 43+x, 28+y , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f3);       
        
gathrillo::gui::Window f4(&desktop6, 9, 48+x, 29+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f4);   
        
gathrillo::gui::Window f5(&desktop6, 9, 50+x, 30+y , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f5);  
    
gathrillo::gui::Window e2(&desktop6, 9, 51+x, 35+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&e2);  
        
gathrillo::gui::Window g0(&desktop6, 9, 40+x, 35+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g0);   
        
gathrillo::gui::Window g1(&desktop6, 9, 41+x, 36+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g1);  
        
        
gathrillo::gui::Window g2(&desktop6, 9, 41+x, 36+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g2);  
        
        
gathrillo::gui::Window g3(&desktop6, 9, 43+x, 37+y , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g3);  
        
        
gathrillo::gui::Window g4(&desktop6, 9, 48+x, 36+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g4);
        
        
        
gathrillo::gui::Window g5(&desktop6, 9, 50+x, 35+y , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g5);  
  

gathrillo::gui::Window a5(&desktop6, 9, 52+x, 30+y, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a5); 

        
gathrillo::gui::Window a6(&desktop6, 9, 54+x, 30+y, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a6); 
 
gathrillo::gui::Window a7(&desktop6, 9, 55+x, 29+y, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a7); 
        
gathrillo::gui::Window a8(&desktop6, 9, 55+x, 36+y, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop6, 9, 57+x, 28+y, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9, 57+x, 28+y, 8, 9, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9, 65+x, 30+y, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9, 56+x, 30+y, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9, 57+x, 37+y, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop6, 9, 65+x, 29+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop6, 9, 65+x, 36+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop6, 9, 66+x, 30+y, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a13);
    
desktop6.Draw(&vga6);

        
};

  BoxerDavieArmAct2::~BoxerDavieArmAct2()
 {
     
 }








BoxerDavieArm4::BoxerDavieArm4(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t act)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    


gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  
 
    
    
   
 //arm   
  
    
    
gathrillo::gui::Dline can(90, 3, 2+28+x +17 +5, 57+y -28 , 1, 6, 0x00, 0x00, 0x00);    
    
    
    
    
    
////////////////////////
    
gathrillo::gui::Window a9a9(&desktop6, 9,  2+28+x +10 +5, 57+y -53, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9a9); 
           
gathrillo::gui::Window a9fi(&desktop6, 9,  2+28+x +10 +5, 57+y -53, 9,  2+8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&a9fi); 
    
gathrillo::gui::Window a9fj(&desktop6, 9,  2+30+x +10 +5, 65+y -53, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&a9fj);  
    
gathrillo::gui::Window a9fk(&desktop6, 9,  2+30+x +10 +5, 56+y -53, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&a9fk);  
        
gathrillo::gui::Window a9a10(&desktop6, 9,  2+37+x +10 +5, 57+y -53, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9a10);
    
    
    
    
    
    
    
    

    
gathrillo::gui::Window a9a1(&desktop6, 9,  2+30+x +5, 30+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9a1);   
        
gathrillo::gui::Window a9b1(&desktop6, 9,  2+31+x +5, 29+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9b1);  
        
        
gathrillo::gui::Window a9b2(&desktop6, 9,  2+31+x +5, 29+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9b2);  
        
        
gathrillo::gui::Window a9bz3(&desktop6, 9,  2+33+x +5, 28+y  , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9bz3);  
        
        
gathrillo::gui::Window a9b4(&desktop6, 9,  2+36+x +5, 29+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9b4);
   
gathrillo::gui::Window a9b5(&desktop6, 9,  2+38+x +5, 30+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9b5);  
        

gathrillo::gui::Window a9a2(&desktop6, 9,  2+39+x +5, 35+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9a2);    
        
gathrillo::gui::Window a9c1(&desktop6, 9,  2+30+x +5, 35+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9c1);   
        
gathrillo::gui::Window a9d1(&desktop6, 9,  2+31+x +5, 36+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9d1);  
        
        
gathrillo::gui::Window a9d2(&desktop6, 9,  2+31+x +5, 36+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9d2);  
        
        
gathrillo::gui::Window a9d3(&desktop6, 9,  2+33+x +5, 37+y  , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9d3);  
              
gathrillo::gui::Window a9d4(&desktop6, 9,  2+36+x +5, 36+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9d4);
              
gathrillo::gui::Window a9d5(&desktop6, 9,  2+38+x +5, 35+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9d5);  
        
gathrillo::gui::Window a9e1(&desktop6, 9,  2+40+x +5, 30+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9e1);   
     

/////////////////////////////////////////////
    


     
gathrillo::gui::Window a9y1(&desktop6, 9, 30+x +12 +5, 30+y-16 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9y1);   
        
gathrillo::gui::Window a9za1(&desktop6, 9, 29+x +12 +5, 31+y-15 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9za1);  
        
        
gathrillo::gui::Window a9za2(&desktop6, 9, 28+x +12 +5, 30+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9za2);  
        
        
gathrillo::gui::Window a9za3(&desktop6, 9, 28+x +12 +5, 33+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9za3);  
        
        
gathrillo::gui::Window a9za4(&desktop6, 9, 29+x +12 +5, 36+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9za4);
   
gathrillo::gui::Window a9za5(&desktop6, 9, 30+x +12 +5, 38+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9za5);  
        

gathrillo::gui::Window a9y2(&desktop6, 9, 35+x +12 +5, 39+y-10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9y2);    
        
gathrillo::gui::Window a9zb1(&desktop6, 9, 35+x +12 +5, 30+y-16 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9zb1);   
        
gathrillo::gui::Window a9zc1(&desktop6, 9, 36+x +12 +5, 31+y-15 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9zc1);  
        
        
gathrillo::gui::Window a9zc2(&desktop6, 9, 37+x +12 +5, 30+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9zc2);  
        
        
gathrillo::gui::Window a9zc3(&desktop6, 9, 37+x +12 +5, 33+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9zc3);  
              
gathrillo::gui::Window a9zc4(&desktop6, 9, 36+x +12 +5, 36+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9zc4);
              
gathrillo::gui::Window a9zc5(&desktop6, 9, 35+x +12 +5, 38+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a9zc5);       
     
     
     
     
    
   /* 
    //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    

// legs            
gathrillo::gui::Window ab1(&desktop6, 9, 29+x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zbbbb1(&desktop6, 9, 28+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zbbbb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 28+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 41+x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 41+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop6, 9, 41+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop6, 9, 29+x, 64+y , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop6, 9, 36+x, 56+y, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 29+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 28+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop6, 9, 28+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop6, 9, 28+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop6, 9, 29+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop6, 9, 35+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop6, 9, 36+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop6, 9, 36+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop6, 9, 36+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop6, 9, 35+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop6, 9, 40+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop6, 9, 41+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop6, 9, 41+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop6, 9, 41+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop6, 9, 40+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb5);

    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 
    */
    
    
desktop6.Draw(&vga6);

        
};

  BoxerDavieArm4::~BoxerDavieArm4()
 {
     
 }





BoxerDavieBlock::BoxerDavieBlock(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t act)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    


gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  
 
    
    
   
 //arm   
  
    
    
gathrillo::gui::Dline can(90, 3, 2+28+x +17, 57+y -28 , 1, 6, 0x00, 0x00, 0x00);    
    
    
    
    
    
////////////////////////
    
gathrillo::gui::Window a9(&desktop6, 9,  2+28+x +10, 57+y -53, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9,  2+28+x +10, 57+y -53, 9,  2+8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9,  2+30+x +10, 65+y -53, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9,  2+30+x +10, 56+y -53, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9,  2+37+x +10, 57+y -53, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
    
    
    
    
    
    
    
    

    
gathrillo::gui::Window a1(&desktop6, 9,  2+30+x, 30+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a1);   
        
gathrillo::gui::Window b1(&desktop6, 9,  2+31+x, 29+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b1);  
        
        
gathrillo::gui::Window b2(&desktop6, 9,  2+31+x, 29+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b2);  
        
        
gathrillo::gui::Window bz3(&desktop6, 9,  2+33+x, 28+y  , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bz3);  
        
        
gathrillo::gui::Window b4(&desktop6, 9,  2+36+x, 29+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b4);
   
gathrillo::gui::Window b5(&desktop6, 9,  2+38+x, 30+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b5);  
        

gathrillo::gui::Window a2(&desktop6, 9,  2+39+x, 35+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a2);    
        
gathrillo::gui::Window c1(&desktop6, 9,  2+30+x, 35+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&c1);   
        
gathrillo::gui::Window d1(&desktop6, 9,  2+31+x, 36+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d1);  
        
        
gathrillo::gui::Window d2(&desktop6, 9,  2+31+x, 36+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d2);  
        
        
gathrillo::gui::Window d3(&desktop6, 9,  2+33+x, 37+y  , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d3);  
              
gathrillo::gui::Window d4(&desktop6, 9,  2+36+x, 36+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d4);
              
gathrillo::gui::Window d5(&desktop6, 9,  2+38+x, 35+y  , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d5);  
        
gathrillo::gui::Window e1(&desktop6, 9,  2+40+x, 30+y  , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&e1);   
     

/////////////////////////////////////////////
    


     
gathrillo::gui::Window y1(&desktop6, 9, 30+x +12, 30+y-16 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y1);   
        
gathrillo::gui::Window za1(&desktop6, 9, 29+x +12, 31+y-15 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za1);  
        
        
gathrillo::gui::Window za2(&desktop6, 9, 28+x +12, 30+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za2);  
        
        
gathrillo::gui::Window za3(&desktop6, 9, 28+x +12, 33+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za3);  
        
        
gathrillo::gui::Window za4(&desktop6, 9, 29+x +12, 36+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za4);
   
gathrillo::gui::Window za5(&desktop6, 9, 30+x +12, 38+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za5);  
        

gathrillo::gui::Window y2(&desktop6, 9, 35+x +12, 39+y-10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y2);    
        
gathrillo::gui::Window zb1(&desktop6, 9, 35+x +12, 30+y-16 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);   
        
gathrillo::gui::Window zc1(&desktop6, 9, 36+x +12, 31+y-15 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc1);  
        
        
gathrillo::gui::Window zc2(&desktop6, 9, 37+x +12, 30+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc2);  
        
        
gathrillo::gui::Window zc3(&desktop6, 9, 37+x +12, 33+y-10 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc3);  
              
gathrillo::gui::Window zc4(&desktop6, 9, 36+x +12, 36+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc4);
              
gathrillo::gui::Window zc5(&desktop6, 9, 35+x +12, 38+y-10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc5);       
     
     
     
     
    
    
    //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    

// legs            
gathrillo::gui::Window ab1(&desktop6, 9, 29+x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zbbbb1(&desktop6, 9, 28+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zbbbb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 28+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 41+x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 41+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop6, 9, 41+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop6, 9, 29+x, 64+y , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop6, 9, 36+x, 56+y, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 29+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 28+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop6, 9, 28+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop6, 9, 28+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop6, 9, 29+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop6, 9, 35+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop6, 9, 36+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop6, 9, 36+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop6, 9, 36+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop6, 9, 35+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop6, 9, 40+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop6, 9, 41+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop6, 9, 41+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop6, 9, 41+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop6, 9, 40+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb5);

    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 
    
    
    
desktop6.Draw(&vga6);

        
};

  BoxerDavieBlock::~BoxerDavieBlock()
 {
     
 }













BoxerDavieArmAct1::BoxerDavieArmAct1(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t act)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    


gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
   
    
    
    

     
gathrillo::gui::Window y1(&desktop6, 9, 30+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y1);   
        
gathrillo::gui::Window za1(&desktop6, 9, 29+x, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za1);  
        
        
gathrillo::gui::Window za2(&desktop6, 9, 29+x, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za2);  
        
        
gathrillo::gui::Window za3(&desktop6, 9, 28+x, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za3);  
        
        
gathrillo::gui::Window za4(&desktop6, 9, 29+x, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za4);
   
gathrillo::gui::Window za5(&desktop6, 9, 30+x, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za5);  
        

gathrillo::gui::Window y2(&desktop6, 9, 35+x, 39+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y2);    
        
gathrillo::gui::Window zb1(&desktop6, 9, 35+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);   
        
gathrillo::gui::Window zc1(&desktop6, 9, 36+x, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc1);  
        
        
gathrillo::gui::Window zc2(&desktop6, 9, 36+x, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc2);  
        
        
gathrillo::gui::Window zc3(&desktop6, 9, 37+x, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc3);  
              
gathrillo::gui::Window zc4(&desktop6, 9, 36+x, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc4);
              
gathrillo::gui::Window zc5(&desktop6, 9, 35+x, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc5);       
     
     
     
     
     ////////////////////////////////////
     
     
     
gathrillo::gui::Window i0(&desktop6, 9, 40+x-5, 30+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i0);   
        
gathrillo::gui::Window i1(&desktop6, 9, 41+x-5, 29+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i1);  
              
gathrillo::gui::Window i2(&desktop6, 9, 41+x-5, 29+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i2);       
        
gathrillo::gui::Window i3(&desktop6, 9, 43+x-5, 28+y+10 , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i3);       
        
gathrillo::gui::Window i4(&desktop6, 9, 48+x-5, 29+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i4);   
        
//     
     
gathrillo::gui::Window j5(&desktop6, 9, 50+x-5, 30+y+10 , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j5);   
    
gathrillo::gui::Window j2(&desktop6, 9, 51+x-5, 35+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j2);  
        
gathrillo::gui::Window k0(&desktop6, 9, 40+x-5, 35+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k0);   
        
gathrillo::gui::Window k1(&desktop6, 9, 41+x-5, 36+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k1);  
        
        
gathrillo::gui::Window k2(&desktop6, 9, 41+x-5, 36+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k2);  
        
        
gathrillo::gui::Window k3(&desktop6, 9, 43+x-5, 37+y+10 , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k3);  
        
        
gathrillo::gui::Window k4(&desktop6, 9, 48+x-5, 36+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k4);
        
        
        
gathrillo::gui::Window k5(&desktop6, 9, 50+x-5, 35+y+10 , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k5);  
  

gathrillo::gui::Window i5(&desktop6, 9, 52+x-5, 30+y+10, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i5); 

        
gathrillo::gui::Window i6(&desktop6, 9, 54+x-5, 30+y+10, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i6); 
 
gathrillo::gui::Window i7(&desktop6, 9, 29+x-5, 55+y+10, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i7); 
        
gathrillo::gui::Window i8(&desktop6, 9, 55+x-5, 36+y+10, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i8);
        
    
     

     
gathrillo::gui::Window x1(&desktop6, 9, 30+x, 40+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x1);
    
     
     
gathrillo::gui::Window x2(&desktop6, 9, 31+x, 41+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x2);
    

gathrillo::gui::Window x3(&desktop6, 9, 32+x, 42+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x3);
    
     
     
gathrillo::gui::Window x4(&desktop6, 9, 33+x, 43+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x4);
    
     
gathrillo::gui::Window x5(&desktop6, 9, 34+x, 44+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x5);
    
     
     
gathrillo::gui::Window x6(&desktop6, 9, 35+x, 45+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x6);

     
     
gathrillo::gui::Window x7(&desktop6, 9, 36+x, 46+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x7);
    
     
     
//    ////
    
gathrillo::gui::Window i9(&desktop6, 9, 57+x-5, 28+y+10, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i9); 
        
    
gathrillo::gui::Window li(&desktop6, 9, 57+x-5, 28+y+10, 8, 9, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&li); 
    
gathrillo::gui::Window lj(&desktop6, 9, 65+x-5, 30+y+10, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lj);  
    
gathrillo::gui::Window lk(&desktop6, 9, 56+x-5, 30+y+10, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lk);  
    
     
     
    
gathrillo::gui::Window i10(&desktop6, 9, 57+x-5, 37+y+10, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i10);
    
    
//
        
gathrillo::gui::Window i11(&desktop6, 9, 65+x-5, 29+y+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i11); 
        
gathrillo::gui::Window i12(&desktop6, 9, 65+x-5, 36+y+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i12);
        
gathrillo::gui::Window i13(&desktop6, 9, 53+x-5, 30+y+10, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i13);
     
 
desktop6.Draw(&vga6);

        
};

  BoxerDavieArmAct1::~BoxerDavieArmAct1()
 {
     
 }







BoxerDavieArmAct4::BoxerDavieArmAct4(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t act)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    


gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
   
    
    
    

     
gathrillo::gui::Window y1(&desktop6, 9, 30+y, 30+x , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y1);   
        
gathrillo::gui::Window za1(&desktop6, 9, 29+y, 31+x , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za1);  
        
        
gathrillo::gui::Window za2(&desktop6, 9, 29+y, 31+x , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za2);  
        
        
gathrillo::gui::Window za3(&desktop6, 9, 28+y, 33+x , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za3);  
        
        
gathrillo::gui::Window za4(&desktop6, 9, 29+y, 36+x , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za4);
   
gathrillo::gui::Window za5(&desktop6, 9, 30+y, 38+x , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za5);  
        

gathrillo::gui::Window y2(&desktop6, 9, 35+y, 39+x , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y2);    
        
gathrillo::gui::Window zb1(&desktop6, 9, 35+y, 30+x , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);   
        
gathrillo::gui::Window zc1(&desktop6, 9, 36+y, 31+x , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc1);  
        
        
gathrillo::gui::Window zc2(&desktop6, 9, 36+y, 31+x , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc2);  
        
        
gathrillo::gui::Window zc3(&desktop6, 9, 37+y, 33+x , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc3);  
              
gathrillo::gui::Window zc4(&desktop6, 9, 36+y, 36+x , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc4);
              
gathrillo::gui::Window zc5(&desktop6, 9, 35+y, 38+x , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc5);       
     
     
     
     
     ////////////////////////////////////
     
     
     
gathrillo::gui::Window i0(&desktop6, 9, 40+y-5, 30+x+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i0);   
        
gathrillo::gui::Window i1(&desktop6, 9, 41+y-5, 29+x+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i1);  
              
gathrillo::gui::Window i2(&desktop6, 9, 41+y-5, 29+x+10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i2);       
        
gathrillo::gui::Window i3(&desktop6, 9, 43+y-5, 28+x+10 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i3);       
        
gathrillo::gui::Window i4(&desktop6, 9, 48+y-5, 29+x+10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i4);   
        
//     
     
gathrillo::gui::Window j5(&desktop6, 9, 50+y-5, 30+x+10 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j5);   
    
gathrillo::gui::Window j2(&desktop6, 9, 51+y-5, 35+x+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j2);  
        
gathrillo::gui::Window k0(&desktop6, 9, 40+y-5, 35+x+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k0);   
        
gathrillo::gui::Window k1(&desktop6, 9, 41+y-5, 36+x+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k1);  
        
        
gathrillo::gui::Window k2(&desktop6, 9, 41+y-5, 36+x+10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k2);  
        
        
gathrillo::gui::Window k3(&desktop6, 9, 43+y-5, 37+x+10 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k3);  
        
        
gathrillo::gui::Window k4(&desktop6, 9, 48+y-5, 36+x+10 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k4);
        
        
        
gathrillo::gui::Window k5(&desktop6, 9, 50+y-5, 35+x+10 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k5);  
  

gathrillo::gui::Window i5(&desktop6, 9, 52+y-5, 30+x+10, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i5); 

        
gathrillo::gui::Window i6(&desktop6, 9, 54+y-5, 30+x+10, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i6); 
 
gathrillo::gui::Window i7(&desktop6, 9, 29+y-5, 55+x+10, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i7); 
        
gathrillo::gui::Window i8(&desktop6, 9, 55+y-5, 36+x+10, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i8);
        
    
     

     
gathrillo::gui::Window x1(&desktop6, 9, 30+y, 40+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x1);
    
     
     
gathrillo::gui::Window x2(&desktop6, 9, 31+y, 41+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x2);
    

gathrillo::gui::Window x3(&desktop6, 9, 32+y, 42+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x3);
    
     
     
gathrillo::gui::Window x4(&desktop6, 9, 33+y, 43+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x4);
    
     
gathrillo::gui::Window x5(&desktop6, 9, 34+y, 44+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x5);
    
     
     
gathrillo::gui::Window x6(&desktop6, 9, 35+y, 45+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x6);

     
     
gathrillo::gui::Window x7(&desktop6, 9, 36+y, 46+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x7);
    
     
     
//    ////
    
gathrillo::gui::Window i9(&desktop6, 9, 57+y-5, 28+x+10, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i9); 
        
    
gathrillo::gui::Window li(&desktop6, 9, 57+y-5, 28+x+10, 9, 8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&li); 
    
gathrillo::gui::Window lj(&desktop6, 9, 65+y-5, 30+x+10, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lj);  
    
gathrillo::gui::Window lk(&desktop6, 9, 56+y-5, 30+x+10, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lk);  
    
     
     
    
gathrillo::gui::Window i10(&desktop6, 9, 57+y-5, 37+x+10, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i10);
    
    
//
        
gathrillo::gui::Window i11(&desktop6, 9, 65+y-5, 29+x+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i11); 
        
gathrillo::gui::Window i12(&desktop6, 9, 65+y-5, 36+x+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i12);
        
gathrillo::gui::Window i13(&desktop6, 9, 53+y-5, 30+x+10, 1, 16, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i13);
     
 
desktop6.Draw(&vga6);

        
};

  BoxerDavieArmAct4::~BoxerDavieArmAct4()
 {
     
 }









BoxerDavieArmAct3::BoxerDavieArmAct3(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t act)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    


gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

    
    
    
    
    
gathrillo::gui::Window q1(&desktop6, 9, 30+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&q1);   
        
gathrillo::gui::Window r1(&desktop6, 9, 29+x, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&r1);  
        
        
gathrillo::gui::Window r2(&desktop6, 9, 29+x, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&r2);  
        
        
gathrillo::gui::Window r3(&desktop6, 9, 28+x, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&r3);  
        
        
gathrillo::gui::Window r4(&desktop6, 9, 29+x, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&r4);
   
gathrillo::gui::Window r5(&desktop6, 9, 30+x, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&r5);  
        

gathrillo::gui::Window q2(&desktop6, 9, 35+x, 39+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&q2);    
        
gathrillo::gui::Window s1(&desktop6, 9, 35+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&s1);   
        
gathrillo::gui::Window t1(&desktop6, 9, 36+x, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&t1);  
        
        
gathrillo::gui::Window s2(&desktop6, 9, 36+x, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&s2);  
        
        
gathrillo::gui::Window s3(&desktop6, 9, 37+x, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&s3);  
              
gathrillo::gui::Window s4(&desktop6, 9, 36+x, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&s4);
              
gathrillo::gui::Window s5(&desktop6, 9, 35+x, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&s5);  
        
gathrillo::gui::Window u1(&desktop6, 9, 30+x, 40+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&u1);   
        
gathrillo::gui::Window v1(&desktop6, 9, 29+x, 41+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&v1);  
              
gathrillo::gui::Window v2(&desktop6, 9, 29+x, 41+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&v2);       
        
gathrillo::gui::Window v3(&desktop6, 9, 28+x, 43+y , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&v3);       
        
gathrillo::gui::Window v4(&desktop6, 9, 29+x, 48+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&v4);   
        
gathrillo::gui::Window v5(&desktop6, 9, 30+x, 50+y , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&v5);  
    
gathrillo::gui::Window v6(&desktop6, 9, 35+x, 51+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&v6);  
        
gathrillo::gui::Window w0(&desktop6, 9, 35+x, 40+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&w0);   
        
gathrillo::gui::Window w1(&desktop6, 9, 36+x, 41+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&w1);  
        
        
gathrillo::gui::Window w2(&desktop6, 9, 36+x, 41+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&w2);  
        
        
gathrillo::gui::Window w3(&desktop6, 9, 37+x, 43+y , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&w3);  
        
        
gathrillo::gui::Window w4(&desktop6, 9, 36+x, 48+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&w4);
        
        
        
gathrillo::gui::Window w5(&desktop6, 9, 35+x, 50+y , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&w5);  
  

gathrillo::gui::Window q5(&desktop6, 9, 30+x, 52+y, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q5); 

        
gathrillo::gui::Window q6(&desktop6, 9, 30+x, 54+y, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q6); 
 
gathrillo::gui::Window q7(&desktop6, 9, 29+x, 55+y, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q7); 
        
gathrillo::gui::Window q8(&desktop6, 9, 36+x, 55+y, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q8);
        
    
//    
    
gathrillo::gui::Window q9(&desktop6, 9, 28+x, 57+y, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q9); 
        
    
gathrillo::gui::Window ui(&desktop6, 9, 28+x, 57+y, 9, 8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&ui); 
    
gathrillo::gui::Window uj(&desktop6, 9, 30+x, 65+y, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&uj);  
    
gathrillo::gui::Window uk(&desktop6, 9, 30+x, 56+y, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&uk);  
    
    
gathrillo::gui::Window q10(&desktop6, 9, 37+x, 57+y, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q10);
    
    
//
        
gathrillo::gui::Window q11(&desktop6, 9, 29+x, 65+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q11); 
        
gathrillo::gui::Window q12(&desktop6, 9, 36+x, 65+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q12);
        
gathrillo::gui::Window q13(&desktop6, 9, 30+x, 66+y, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&q13);

gathrillo::gui::Window m0(&desktop6, 9, 40+x, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&m0);   
        
gathrillo::gui::Window m1(&desktop6, 9, 41+x, 29+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&m1);  
              
gathrillo::gui::Window m2(&desktop6, 9, 41+x, 29+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&m2);       
        
gathrillo::gui::Window m3(&desktop6, 9, 43+x, 28+y , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&m3);       
        
gathrillo::gui::Window m4(&desktop6, 9, 48+x, 29+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&m4);   
        
//     
     
gathrillo::gui::Window n5(&desktop6, 9, 50+x, 30+y , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&n5);   
    
gathrillo::gui::Window n2(&desktop6, 9, 51+x, 35+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&n2);  
        
gathrillo::gui::Window o0(&desktop6, 9, 40+x, 35+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&o0);   
        
gathrillo::gui::Window o1(&desktop6, 9, 41+x, 36+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&o1);  
        
        
gathrillo::gui::Window o2(&desktop6, 9, 41+x, 36+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&o2);  
        
        
gathrillo::gui::Window o3(&desktop6, 9, 43+x, 37+y , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&o3);  
        
        
gathrillo::gui::Window o4(&desktop6, 9, 48+x, 36+y , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&o4);
        
        
        
gathrillo::gui::Window o5(&desktop6, 9, 50+x, 35+y , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&o5);  
  

gathrillo::gui::Window m5(&desktop6, 9, 52+x, 30+y, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m5); 

        
gathrillo::gui::Window m6(&desktop6, 9, 54+x, 30+y, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m6); 
 
gathrillo::gui::Window m7(&desktop6, 9, 29+x, 55+y, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m7); 
        
gathrillo::gui::Window m8(&desktop6, 9, 55+x, 36+y, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m8);
        
    
//    ////
    
gathrillo::gui::Window m9(&desktop6, 9, 57+x, 28+y, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m9); 
        
    
gathrillo::gui::Window pi(&desktop6, 9, 57+x, 28+y, 8, 9, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&pi); 
    
gathrillo::gui::Window pj(&desktop6, 9, 65+x, 30+y, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&pj);  
    
gathrillo::gui::Window pk(&desktop6, 9, 56+x, 30+y, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&pk);  
    
     
     
    
gathrillo::gui::Window m10(&desktop6, 9, 57+x, 37+y, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m10);
    
    
//
        
gathrillo::gui::Window m11(&desktop6, 9, 65+x, 29+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m11); 
        
gathrillo::gui::Window m12(&desktop6, 9, 65+x, 36+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m12);
        
gathrillo::gui::Window m13(&desktop6, 9, 53+x, 30+y, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&m13);
    
    

    
    
    
    
    
desktop6.Draw(&vga6);

        
};

  BoxerDavieArmAct3::~BoxerDavieArmAct3()
 {
     
 }

BoxerDavieSprite1::BoxerDavieSprite1(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{


    
    
  
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

   
    
    
    
    
    
 //arm   
  
gathrillo::gui::Window ad1(&desktop6, 9,  2+30+x, 30+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad1);   
        
gathrillo::gui::Window bd1(&desktop6, 9,  2+29+x, 31+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd1);  
        
        
gathrillo::gui::Window bd2(&desktop6, 9,  2+29+x, 31+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd2);  
        
        
gathrillo::gui::Window bd3(&desktop6, 9,  2+28+x, 33+y  -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd3);  
        
        
gathrillo::gui::Window bd4(&desktop6, 9,  2+29+x, 36+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd4);
   
gathrillo::gui::Window bd5(&desktop6, 9,  2+30+x, 38+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd5);  
        

gathrillo::gui::Window ad2(&desktop6, 9,  2+35+x, 39+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad2);    
        
gathrillo::gui::Window cd1(&desktop6, 9,  2+35+x, 30+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cd1);   
        
gathrillo::gui::Window d1(&desktop6, 9,  2+36+x, 31+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d1);  
        
        
gathrillo::gui::Window dd2(&desktop6, 9,  2+36+x, 31+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd2);  
        
        
gathrillo::gui::Window dd3(&desktop6, 9,  2+37+x, 33+y  -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd3);  
              
gathrillo::gui::Window dd4(&desktop6, 9,  2+36+x, 36+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd4);
              
gathrillo::gui::Window dd5(&desktop6, 9,  2+35+x, 38+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd5);  
        
gathrillo::gui::Window ed1(&desktop6, 9,  2+30+x, 40+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed1);   
        
gathrillo::gui::Window fd1(&desktop6, 9,  2+29+x, 41+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd1);  
              
gathrillo::gui::Window fd2(&desktop6, 9,  2+29+x, 41+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd2);       
        
gathrillo::gui::Window fd3(&desktop6, 9,  2+28+x, 43+y  -3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd3);       
        
gathrillo::gui::Window fd4(&desktop6, 9,  2+29+x, 48+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd4);   
        
gathrillo::gui::Window fd5(&desktop6, 9,  2+30+x, 50+y  -3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd5);  
    
gathrillo::gui::Window ed2(&desktop6, 9,  2+35+x, 51+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed2);  
        
gathrillo::gui::Window gd0(&desktop6, 9,  2+35+x, 40+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd0);   
        
gathrillo::gui::Window gd1(&desktop6, 9,  2+36+x, 41+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd1);  
        
        
gathrillo::gui::Window gd2(&desktop6, 9,  2+36+x, 41+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd2);  
        
        
gathrillo::gui::Window gd3(&desktop6, 9,  2+37+x, 43+y  -3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd3);  
        
        
gathrillo::gui::Window gd4(&desktop6, 9,  2+36+x, 48+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd4);
        
        
        
gathrillo::gui::Window gd5(&desktop6, 9,  2+35+x, 50+y  -3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd5);  
  

gathrillo::gui::Window ad5(&desktop6, 9,  2+30+x, 52+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad5); 

        
gathrillo::gui::Window ad6(&desktop6, 9,  2+30+x, 54+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad6); 
 
gathrillo::gui::Window ad7(&desktop6, 9,  2+29+x, 55+y -3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad7); 
        
gathrillo::gui::Window ad8(&desktop6, 9,  2+36+x, 55+y -3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop6, 9,  2+28+x, 57+y -3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9,  2+28+x, 57+y -3, 9,  2+8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9,  2+30+x, 65+y -3, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9,  2+30+x, 56+y -3, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9,  2+37+x, 57+y -3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop6, 9,  2+29+x, 65+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop6, 9,  2+36+x, 65+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop6, 9,  2+30+x, 66+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a13);
    
 
  //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    

// legs            
gathrillo::gui::Window ab1(&desktop6, 9, 29+x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zb1(&desktop6, 9, 28+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 28+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 41+x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 41+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop6, 9, 41+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop6, 9, 29+x, 64+y , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop6, 9, 36+x, 56+y, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 29+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 28+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop6, 9, 28+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop6, 9, 28+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop6, 9, 29+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop6, 9, 35+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop6, 9, 36+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop6, 9, 36+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop6, 9, 36+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop6, 9, 35+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop6, 9, 40+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop6, 9, 41+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop6, 9, 41+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop6, 9, 41+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop6, 9, 40+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb5);

    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 
    
    
    
desktop6.Draw(&vga6);
    
    

    
      
};

BoxerDavieSprite1::~BoxerDavieSprite1()
 {
     
 }







BoxerDavieSprite2::BoxerDavieSprite2(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{


    
    
  
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

   
    
    
    
    
    
 //arm   
  
    

     
gathrillo::gui::Window y1(&desktop6, 9,  2+30+x, 30+y -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y1);   
        
gathrillo::gui::Window za1(&desktop6, 9,  2+29+x, 31+y -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za1);  
        
        
gathrillo::gui::Window za2(&desktop6, 9,  2+29+x, 31+y -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za2);  
        
        
gathrillo::gui::Window za3(&desktop6, 9,  2+28+x, 33+y -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za3);  
        
        
gathrillo::gui::Window za4(&desktop6, 9,  2+29+x, 36+y -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za4);
   
gathrillo::gui::Window za5(&desktop6, 9,  2+30+x, 38+y -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za5);  
        

gathrillo::gui::Window y2(&desktop6, 9,  2+35+x, 39+y -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y2);    
        
gathrillo::gui::Window zzb1(&desktop6, 9,  2+35+x, 30+y -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb1);   
        
gathrillo::gui::Window zc1(&desktop6, 9,  2+36+x, 31+y -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc1);  
        
        
gathrillo::gui::Window zc2(&desktop6, 9,  2+36+x, 31+y -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc2);  
        
        
gathrillo::gui::Window zc3(&desktop6, 9,  2+37+x, 33+y -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc3);  
              
gathrillo::gui::Window zc4(&desktop6, 9,  2+36+x, 36+y -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc4);
              
gathrillo::gui::Window zc5(&desktop6, 9,  2+35+x, 38+y -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc5);       
     
     
     
     
     ////////////////////////////////////
     
     
     
gathrillo::gui::Window i0(&desktop6, 9,  2+40+x-5, 30+y -3+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i0);   
        
gathrillo::gui::Window i1(&desktop6, 9,  2+41+x-5, 29+y -3+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i1);  
              
gathrillo::gui::Window i2(&desktop6, 9,  2+41+x-5, 29+y -3+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i2);       
        
gathrillo::gui::Window i3(&desktop6, 9,  2+43+x-5, 28+y -3+10 , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i3);       
        
gathrillo::gui::Window i4(&desktop6, 9,  2+48+x-5, 29+y -3+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i4);   
        
//     
     
gathrillo::gui::Window j5(&desktop6, 9,  2+50+x-5, 30+y -3+10 , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j5);   
    
gathrillo::gui::Window j2(&desktop6, 9,  2+51+x-5, 35+y -3+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j2);  
        
gathrillo::gui::Window k0(&desktop6, 9,  2+40+x-5, 35+y -3+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k0);   
        
gathrillo::gui::Window k1(&desktop6, 9,  2+41+x-5, 36+y -3+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k1);  
        
        
gathrillo::gui::Window k2(&desktop6, 9,  2+41+x-5, 36+y -3+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k2);  
        
        
gathrillo::gui::Window k3(&desktop6, 9,  2+43+x-5, 37+y -3+10 , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k3);  
        
        
gathrillo::gui::Window k4(&desktop6, 9,  2+48+x-5, 36+y -3+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k4);
        
        
        
gathrillo::gui::Window k5(&desktop6, 9,  2+50+x-5, 35+y -3+10 , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k5);  
  

gathrillo::gui::Window i5(&desktop6, 9,  2+52+x-5, 30+y -3+10, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i5); 

        
gathrillo::gui::Window i6(&desktop6, 9,  2+54+x-5, 30+y -3+10, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i6); 
 
gathrillo::gui::Window i7(&desktop6, 9,  2+29+x-5, 55+y -3+10, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i7); 
        
gathrillo::gui::Window i8(&desktop6, 9,  2+55+x-5, 36+y -3+10, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i8);
        
    
     

     
gathrillo::gui::Window x1(&desktop6, 9,  2+30+x, 40+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x1);
    
     
     
gathrillo::gui::Window x2(&desktop6, 9,  2+31+x, 41+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x2);
    

gathrillo::gui::Window x3(&desktop6, 9,  2+32+x, 42+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x3);
    
     
     
gathrillo::gui::Window x4(&desktop6, 9,  2+33+x, 43+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x4);
    
     
gathrillo::gui::Window x5(&desktop6, 9,  2+34+x, 44+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x5);
    
     
     
gathrillo::gui::Window x6(&desktop6, 9,  2+35+x, 45+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x6);

     
     
gathrillo::gui::Window x7(&desktop6, 9,  2+36+x, 46+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x7);
    
     
     
//    ////
    
gathrillo::gui::Window i9(&desktop6, 9,  2+57+x-5, 28+y -3+10, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i9); 
        
    
gathrillo::gui::Window li(&desktop6, 9,  2+57+x-5, 28+y -3+10, 8, 9, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&li); 
    
gathrillo::gui::Window lj(&desktop6, 9,  2+65+x-5, 30+y -3+10, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lj);  
    
gathrillo::gui::Window lk(&desktop6, 9,  2+56+x-5, 30+y -3+10, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lk);  
    
     
     
    
gathrillo::gui::Window i10(&desktop6, 9,  2+57+x-5, 37+y -3+10, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i10);
    
    
//
        
gathrillo::gui::Window i11(&desktop6, 9,  2+65+x-5, 29+y -3+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i11); 
        
gathrillo::gui::Window i12(&desktop6, 9,  2+65+x-5, 36+y -3+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i12);
        
gathrillo::gui::Window i13(&desktop6, 9,  2+53+x-5, 30+y -3+10, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i13);
     

  //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    

// legs            
gathrillo::gui::Window ab1(&desktop6, 9, 29+x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zb1(&desktop6, 9, 28+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 28+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 41+x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 41+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop6, 9, 41+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop6, 9, 29+x, 64+y , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop6, 9, 36+x, 56+y, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 29+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 28+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop6, 9, 28+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop6, 9, 28+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop6, 9, 29+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop6, 9, 35+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop6, 9, 36+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop6, 9, 36+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop6, 9, 36+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop6, 9, 35+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop6, 9, 40+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop6, 9, 41+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop6, 9, 41+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop6, 9, 41+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop6, 9, 40+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb5);
      

 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 
    
    
    
desktop6.Draw(&vga6);
    
    

    
      
};

BoxerDavieSprite2::~BoxerDavieSprite2()
 {
     
 }



BoxerDavieSprite3::BoxerDavieSprite3(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{


    
    
  
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
   
    
 //arm   
  
    

    
gathrillo::gui::Window a1(&desktop6, 9,  2+30+x, 30+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a1);   
        
gathrillo::gui::Window b1(&desktop6, 9,  2+31+x, 29+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b1);  
        
        
gathrillo::gui::Window b2(&desktop6, 9,  2+31+x, 29+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b2);  
        
        
gathrillo::gui::Window bz3(&desktop6, 9,  2+33+x, 28+y  -3, 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bz3);  
        
        
gathrillo::gui::Window b4(&desktop6, 9,  2+36+x, 23+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b4);
   
gathrillo::gui::Window b5(&desktop6, 9,  2+38+x, 30+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b5);  
        

gathrillo::gui::Window a2(&desktop6, 9,  2+39+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a2);    
        
gathrillo::gui::Window c1(&desktop6, 9,  2+30+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&c1);   
        
gathrillo::gui::Window d1(&desktop6, 9,  2+31+x, 36+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d1);  
        
        
gathrillo::gui::Window d2(&desktop6, 9,  2+31+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d2);  
        
        
gathrillo::gui::Window d3(&desktop6, 9,  2+33+x, 37+y  -3, 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d3);  
              
gathrillo::gui::Window d4(&desktop6, 9,  2+36+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d4);
              
gathrillo::gui::Window d5(&desktop6, 9,  2+38+x, 35+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d5);  
        
gathrillo::gui::Window e1(&desktop6, 9,  2+40+x, 30+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&e1);   
        
gathrillo::gui::Window f1(&desktop6, 9,  2+41+x, 29+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f1);  
              
gathrillo::gui::Window f2(&desktop6, 9,  2+41+x, 29+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f2);       
        
gathrillo::gui::Window f3(&desktop6, 9,  2+43+x, 28+y  -3, 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f3);       
        
gathrillo::gui::Window f4(&desktop6, 9,  2+48+x, 29+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f4);   
        
gathrillo::gui::Window f5(&desktop6, 9,  2+50+x, 30+y  -3, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f5);  
    
gathrillo::gui::Window e2(&desktop6, 9,  2+51+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&e2);  
        
gathrillo::gui::Window g0(&desktop6, 9,  2+40+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g0);   
        
gathrillo::gui::Window g1(&desktop6, 9,  2+41+x, 36+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g1);  
        
        
gathrillo::gui::Window g2(&desktop6, 9,  2+41+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g2);  
        
        
gathrillo::gui::Window g3(&desktop6, 9,  2+43+x, 37+y  -3, 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g3);  
        
        
gathrillo::gui::Window g4(&desktop6, 9,  2+48+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g4);
        
        
        
gathrillo::gui::Window g5(&desktop6, 9,  2+50+x, 35+y  -3, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g5);  
  

gathrillo::gui::Window a5(&desktop6, 9,  2+52+x, 30+y -3, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a5); 

        
gathrillo::gui::Window a6(&desktop6, 9,  2+54+x, 30+y -3, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a6); 
 
gathrillo::gui::Window a7(&desktop6, 9,  2+55+x, 29+y -3, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a7); 
        
gathrillo::gui::Window a8(&desktop6, 9,  2+55+x, 36+y -3, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop6, 9,  2+57+x, 28+y -3, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9,  2+57+x, 28+y -3, 8, 9,  0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9,  2+65+x, 30+y -3, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9,  2+56+x, 30+y -3, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9,  2+57+x, 37+y -3, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop6, 9,  2+65+x, 29+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop6, 9,  2+65+x, 36+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop6, 9,  2+66+x, 30+y -3, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a13);
    

  //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    

// legs            
gathrillo::gui::Window ab1(&desktop6, 9, 29+x, 50+y  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zb1(&desktop6, 9, 28+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 28+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 41+x, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 41+x, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop6, 9, 41+x, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop6, 9, 29+x, 64+y , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop6, 9, 36+x, 56+y, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 29+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 28+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop6, 9, 28+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop6, 9, 28+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop6, 9, 29+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop6, 9, 35+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop6, 9, 36+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop6, 9, 36+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop6, 9, 36+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop6, 9, 35+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop6, 9, 40+x, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop6, 9, 41+x, 67+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop6, 9, 41+x, 71+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop6, 9, 41+x, 75+y, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop6, 9, 40+x, 79+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cb5);
      
   
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 
    
    
    
desktop6.Draw(&vga6);
    
    

    
      
};

BoxerDavieSprite3::~BoxerDavieSprite3()
 {
     
 }

/*

BoxerDavieCrouchSprite::BoxerDavieCrouchSprite( common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{


    
    
  
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

   
    
    
    
    
    
 //arm   
  
    gathrillo::gui::Window ad11(&desktop6, 9,  2+30+x, 30+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad11);   
        
gathrillo::gui::Window bd11(&desktop6, 9,  2+29+x, 31+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd11);  
        
        
gathrillo::gui::Window bd12(&desktop6, 9,  2+29+x, 31+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd12);  
        
        
gathrillo::gui::Window bd13(&desktop6, 9,  2+28+x, 33+y  -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd13);  
        
        
gathrillo::gui::Window bd14(&desktop6, 9,  2+29+x, 36+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd14);
   
gathrillo::gui::Window bd15(&desktop6, 9,  2+30+x, 38+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bd15);  
        

gathrillo::gui::Window ad2(&desktop6, 9,  2+35+x, 39+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ad2);    
        
gathrillo::gui::Window cd1(&desktop6, 9,  2+35+x, 30+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&cd1);   
        
gathrillo::gui::Window d11(&desktop6, 9,  2+36+x, 31+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d11);  
        
        
gathrillo::gui::Window dd12(&desktop6, 9,  2+36+x, 31+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd12);  
        
        
gathrillo::gui::Window dd13(&desktop6, 9,  2+37+x, 33+y  -3 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd13);  
              
gathrillo::gui::Window dd14(&desktop6, 9,  2+36+x, 36+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd14);
              
gathrillo::gui::Window dd15(&desktop6, 9,  2+35+x, 38+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&dd15);  
        
gathrillo::gui::Window ed11(&desktop6, 9,  2+30+x, 40+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed11);   
        
gathrillo::gui::Window fd11(&desktop6, 9,  2+29+x, 41+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd11);  
              
gathrillo::gui::Window fd12(&desktop6, 9,  2+29+x, 41+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd12);       
        
gathrillo::gui::Window fd13(&desktop6, 9,  2+28+x, 43+y  -3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd13);       
        
gathrillo::gui::Window fd14(&desktop6, 9,  2+29+x, 48+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd14);   
        
gathrillo::gui::Window fd15(&desktop6, 9,  2+30+x, 50+y  -3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&fd15);  
    
gathrillo::gui::Window ed12(&desktop6, 9,  2+35+x, 51+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ed12);  
        
gathrillo::gui::Window gd10(&desktop6, 9,  2+35+x, 40+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd10);   
        
gathrillo::gui::Window gd11(&desktop6, 9,  2+36+x, 41+y  -3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd11);  
        
        
gathrillo::gui::Window gd12(&desktop6, 9,  2+36+x, 41+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd12);  
        
        
gathrillo::gui::Window gd13(&desktop6, 9,  2+37+x, 43+y  -3 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd13);  
        
        
gathrillo::gui::Window gd14(&desktop6, 9,  2+36+x, 48+y  -3 , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd14);
        
        
        
gathrillo::gui::Window gd5(&desktop6, 9,  2+35+x, 50+y  -3 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&gd5);  
  

gathrillo::gui::Window ad5(&desktop6, 9,  2+30+x, 52+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad5); 

        
gathrillo::gui::Window ad6(&desktop6, 9,  2+30+x, 54+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad6); 
 
gathrillo::gui::Window ad7(&desktop6, 9,  2+29+x, 55+y -3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad7); 
        
gathrillo::gui::Window ad8(&desktop6, 9,  2+36+x, 55+y -3, 1, 2, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&ad8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop6, 9,  2+28+x, 57+y -3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9,  2+28+x, 57+y -3, 9,  2+8, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9,  2+30+x, 65+y -3, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9,  2+30+x, 56+y -3, 6, 1, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9,  2+37+x, 57+y -3, 1, 8, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop6, 9,  2+29+x, 65+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop6, 9,  2+36+x, 65+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop6, 9,  2+30+x, 66+y -3, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a13);
    

    
  //Body  
    
      
gathrillo::gui::Window aa11(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
    
    
gathrillo::gui::Window aa15(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15);   
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
    
gathrillo::gui::Window aa18(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa18);   
    
    
gathrillo::gui::Window aa19(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa19);   
    
gathrillo::gui::Window aa110(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa110);

gathrillo::gui::Window aa111(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa111);   

gathrillo::gui::Window aa112(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa113(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa114(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa115(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa116(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa117(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a119(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a119);   
    
gathrillo::gui::Window aa210(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa210);

gathrillo::gui::Window aa211(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa211);   

gathrillo::gui::Window aa212(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa212);   
    
    
gathrillo::gui::Window aa213(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa213);   
    
gathrillo::gui::Window aa214(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa214);   
    
    
gathrillo::gui::Window aa215(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa215);   
    
gathrillo::gui::Window aa216(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa216);   
    
gathrillo::gui::Window aa217(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa217);   
    
gathrillo::gui::Window aa218(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa218);    
    
gathrillo::gui::Window aa219(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa219);   
    
gathrillo::gui::Window aa310(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa310);

gathrillo::gui::Window aa311(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa311);   

     
    
    
    
    

// legs 1            
gathrillo::gui::Window ab1(&desktop6, 9, 50+x - 10, 29+y +20, 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zb1(&desktop6, 9, 53+x - 10, 28+y +20, 9, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 62+x - 10, 28+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 50+x - 10, 36+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 53+x - 10, 36+y +20, 9, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop6, 9, 62+x - 10, 36+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop6, 9, 64+x - 10, 29+y +20 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
 
    
//bend    
    
    
gathrillo::gui::Window ab4(&desktop6, 9, 56+x - 10, 36+y +20, 12, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 65+x - 10, 29+y +20, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 67+x - 10, 28+y +20, 6, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop6, 9, 73+x - 10, 28+y +20, 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);

gathrillo::gui::Window ab8(&desktop6, 9, 74+x - 10, 36+y +20, 1, 12, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
    

gathrillo::gui::Window ab9(&desktop6, 9, 73+x - 10, 40+y +28, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
        
    
    
gathrillo::gui::Window bb1(&desktop6, 9, 65+x - 10, 35+y +20, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop6, 9, 67+x - 10, 36+y +20, 1, 16, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
 
        

 //legs 2
    
    
    
        

// legs            
gathrillo::gui::Window azb1(&desktop6, 9, 29+x +2, 50+y, 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zzb1(&desktop6, 9, 28+x +2, 51+y, 1, 11, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb1);  
        
gathrillo::gui::Window zzb2(&desktop6, 9, 28+x +2, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb2);  

gathrillo::gui::Window azb2(&desktop6, 9, 36+x +2, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb2);  
  

        
gathrillo::gui::Window zzb3(&desktop6, 9, 36+x +2, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb3);  
        
gathrillo::gui::Window zzb4(&desktop6, 9, 36+x +2, 63+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb4);          
//        
        
gathrillo::gui::Window azb3(&desktop6, 9, 29+x +2, 64+y , 8, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb3);
 
    
//bend    
    
 //knee  
    
    
gathrillo::gui::Window azb4(&desktop6, 9, 36+x +2, 56+y, 1, 12, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb4);
        
gathrillo::gui::Window azb5(&desktop6, 9, 29+x +2, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb5);
        
gathrillo::gui::Window azb6(&desktop6, 9, 36+x +2, 67+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb6);
        
        
gathrillo::gui::Window azb7(&desktop6, 9, 26+x +2, 73+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb7);
    
    
    
    
///////    

gathrillo::gui::Window azb8(&desktop6, 9, 36+x -20, 74+y, 12, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb8);
        
    

gathrillo::gui::Window abz9(&desktop6, 9, 40+x -20, 73+y +28, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&abz9);
        
        
    
    
gathrillo::gui::Window bzb1(&desktop6, 9, 35+x -20, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bzb2(&desktop6, 9, 36+x -20, 67+y, 16, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bzb2);
 
    
   
    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 
    
    
    
desktop6.Draw(&vga6);
    
    

    
      
};*/
    
    
    
    
BoxerDavieCrouchSprite::BoxerDavieCrouchSprite(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{


    
    
  
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

    
    
    

     
gathrillo::gui::Window y1(&desktop6, 9, 30+x+2, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y1);   
        
gathrillo::gui::Window za1(&desktop6, 9, 29+x+2, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za1);  
        
        
gathrillo::gui::Window za2(&desktop6, 9, 29+x+2, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za2);  
        
        
gathrillo::gui::Window za3(&desktop6, 9, 28+x+2, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za3);  
        
        
gathrillo::gui::Window za4(&desktop6, 9, 29+x+2, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za4);
   
gathrillo::gui::Window za5(&desktop6, 9, 30+x+2, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&za5);  
        

gathrillo::gui::Window y2(&desktop6, 9, 35+x+2, 39+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&y2);    
        
gathrillo::gui::Window zb1(&desktop6, 9, 35+x+2, 30+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);   
        
gathrillo::gui::Window zc1(&desktop6, 9, 36+x+2, 31+y , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc1);  
        
        
gathrillo::gui::Window zc2(&desktop6, 9, 36+x+2, 31+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc2);  
        
        
gathrillo::gui::Window zc3(&desktop6, 9, 37+x+2, 33+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc3);  
              
gathrillo::gui::Window zc4(&desktop6, 9, 36+x+2, 36+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc4);
              
gathrillo::gui::Window zc5(&desktop6, 9, 35+x+2, 38+y , 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zc5);       
     
     
     
     
     ////////////////////////////////////
     
     
     
gathrillo::gui::Window i0(&desktop6, 9, 40+x+2-5, 30+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i0);   
        
gathrillo::gui::Window i1(&desktop6, 9, 41+x+2-5, 29+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i1);  
              
gathrillo::gui::Window i2(&desktop6, 9, 41+x+2-5, 29+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i2);       
        
gathrillo::gui::Window i3(&desktop6, 9, 43+x+2-5, 28+y+10 , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i3);       
        
gathrillo::gui::Window i4(&desktop6, 9, 48+x+2-5, 29+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&i4);   
        
//     
     
gathrillo::gui::Window j5(&desktop6, 9, 50+x+2-5, 30+y+10 , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j5);   
    
gathrillo::gui::Window j2(&desktop6, 9, 51+x+2-5, 35+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&j2);  
        
gathrillo::gui::Window k0(&desktop6, 9, 40+x+2-5, 35+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k0);   
        
gathrillo::gui::Window k1(&desktop6, 9, 41+x+2-5, 36+y+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k1);  
        
        
gathrillo::gui::Window k2(&desktop6, 9, 41+x+2-5, 36+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k2);  
        
        
gathrillo::gui::Window k3(&desktop6, 9, 43+x+2-5, 37+y+10 , 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k3);  
        
        
gathrillo::gui::Window k4(&desktop6, 9, 48+x+2-5, 36+y+10 , 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k4);
        
        
        
gathrillo::gui::Window k5(&desktop6, 9, 50+x+2-5, 35+y+10 , 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&k5);  
  

gathrillo::gui::Window i5(&desktop6, 9, 52+x+2-5, 30+y+10, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i5); 

        
gathrillo::gui::Window i6(&desktop6, 9, 54+x+2-5, 30+y+10, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i6); 
 
gathrillo::gui::Window i7(&desktop6, 9, 29+x+2-5, 55+y+10, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i7); 
        
gathrillo::gui::Window i8(&desktop6, 9, 55+x+2-5, 36+y+10, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i8);
        
    
     

     
gathrillo::gui::Window x1(&desktop6, 9, 30+x+2, 40+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x1);
    
     
     
gathrillo::gui::Window x2(&desktop6, 9, 31+x+2, 41+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x2);
    

gathrillo::gui::Window x3(&desktop6, 9, 32+x+2, 42+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x3);
    
     
     
gathrillo::gui::Window x4(&desktop6, 9, 33+x+2, 43+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x4);
    
     
gathrillo::gui::Window x5(&desktop6, 9, 34+x+2, 44+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x5);
    
     
     
gathrillo::gui::Window x6(&desktop6, 9, 35+x+2, 45+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x6);

     
     
gathrillo::gui::Window x7(&desktop6, 9, 36+x+2, 46+y, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&x7);
    
     
     
//    ////
    
gathrillo::gui::Window i9(&desktop6, 9, 57+x+2-5, 28+y+10, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i9); 
        
    
gathrillo::gui::Window li(&desktop6, 9, 57+x+2-5, 28+y+10, 8, 9, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&li); 
    
gathrillo::gui::Window lj(&desktop6, 9, 65+x+2-5, 30+y+10, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lj);  
    
gathrillo::gui::Window lk(&desktop6, 9, 56+x+2-5, 30+y+10, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&lk);  
    
     
     
    
gathrillo::gui::Window i10(&desktop6, 9, 57+x+2-5, 37+y+10, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i10);
    
    
//
        
gathrillo::gui::Window i11(&desktop6, 9, 65+x+2-5, 29+y+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i11); 
        
gathrillo::gui::Window i12(&desktop6, 9, 65+x+2-5, 36+y+10, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i12);
        
gathrillo::gui::Window i13(&desktop6, 9, 53+x+2-5, 30+y+10, 6, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&i13);
     
    
    //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    
    
    
    
    
    

// legs 1            
gathrillo::gui::Window ab11(&desktop6, 9, 50+x - 10, 29+y +20, 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab11);  
        
        
gathrillo::gui::Window zb11(&desktop6, 9, 53+x - 10, 28+y +20, 9, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb11);  
        
gathrillo::gui::Window zb21(&desktop6, 9, 62+x - 10, 28+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb21);  

gathrillo::gui::Window ab21(&desktop6, 9, 50+x - 10, 36+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab21);  
  

        
gathrillo::gui::Window zb31(&desktop6, 9, 53+x - 10, 36+y +20, 9, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb31);  
        
gathrillo::gui::Window zb41(&desktop6, 9, 62+x - 10, 36+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb41);          
//        
        
gathrillo::gui::Window ab31(&desktop6, 9, 64+x - 10, 29+y +20 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab31);
 
    
    
//bend    
    
    
gathrillo::gui::Window ab41(&desktop6, 9, 56+x - 10, 36+y +20, 12, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab41);
        
gathrillo::gui::Window ab51(&desktop6, 9, 65+x - 10, 29+y +20, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab51);
        
gathrillo::gui::Window ab61(&desktop6, 9, 67+x - 10, 28+y +20, 6, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab61);
        
        
gathrillo::gui::Window ab71(&desktop6, 9, 73+x - 10, 28+y +20, 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab71);

gathrillo::gui::Window ab81(&desktop6, 9, 74+x - 10, 36+y +20, 1, 12, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab81);
        
    

gathrillo::gui::Window ab91(&desktop6, 9, 73+x - 10, 40+y +28, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab91);
        
        
    
    
gathrillo::gui::Window bb11(&desktop6, 9, 65+x - 10, 35+y +20, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab51);
        
gathrillo::gui::Window bb21(&desktop6, 9, 67+x - 10, 36+y +20, 1, 16, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb21);
        
 
        

 //legs 2
    
    
    
        

// legs            
gathrillo::gui::Window azb11(&desktop6, 9, 29+x +2, 50+y, 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb11);  
        
        
gathrillo::gui::Window zzb11(&desktop6, 9, 28+x +2, 51+y, 1, 11, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb11);  
        
gathrillo::gui::Window zzb21(&desktop6, 9, 28+x +2, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb21);  

gathrillo::gui::Window azb21(&desktop6, 9, 36+x +2, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb21);  
  

        
gathrillo::gui::Window zzb31(&desktop6, 9, 36+x +2, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb31);  
        
gathrillo::gui::Window zzb41(&desktop6, 9, 15+x +2, 73+y , 22, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb41);          
//        
        
gathrillo::gui::Window azb31(&desktop6, 9, 29+x +2, 64+y , 8, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb31);
 
    
//bend    
    
 //knee  
    
    
gathrillo::gui::Window azb41(&desktop6, 9, 36+x +2, 56+y, 1, 12, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb41);
  //      
gathrillo::gui::Window azb51(&desktop6, 9, 15+x +2, 65+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb51);
        
gathrillo::gui::Window azb61(&desktop6, 9, 36+x +2, 67+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb61);
        
        
gathrillo::gui::Window azb71(&desktop6, 9, 26+x +2, 73+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb71);
    
    
    
    
///////    

gathrillo::gui::Window azb81(&desktop6, 9, 36+x -20, 74+y, 12, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb81);
        
    

gathrillo::gui::Window abz91(&desktop6, 9, 4+x -20, 73+y +28, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&abz91);
        
        
    
    
gathrillo::gui::Window bzb11(&desktop6, 9, 35+x -20, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab51);
        
gathrillo::gui::Window bzb21(&desktop6, 9, 36+x -20, 67+y, 16, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bzb21);
 
    
   /* 
    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 */
    
    
    
desktop6.Draw(&vga6);
    
    

    
      
};


BoxerDavieCrouchSprite::~BoxerDavieCrouchSprite()
 {
     
 }





BoxerDavieCrouchPunchSprite::BoxerDavieCrouchPunchSprite(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{


    
    
  
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

   
    
    
    
    
    
 //arm   
  
    

    
gathrillo::gui::Window a1(&desktop6, 9,  2+30+x, 30+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a1);   
        
gathrillo::gui::Window b1(&desktop6, 9,  2+31+x, 29+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b1);  
        
        
gathrillo::gui::Window b2(&desktop6, 9,  2+31+x, 29+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b2);  
        
        
gathrillo::gui::Window bz3(&desktop6, 9,  2+33+x, 28+y  -3, 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bz3);  
        
        
gathrillo::gui::Window b4(&desktop6, 9,  2+36+x, 23+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b4);
   
gathrillo::gui::Window b5(&desktop6, 9,  2+38+x, 30+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&b5);  
        

gathrillo::gui::Window a2(&desktop6, 9,  2+39+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a2);    
        
gathrillo::gui::Window c1(&desktop6, 9,  2+30+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&c1);   
        
gathrillo::gui::Window d1(&desktop6, 9,  2+31+x, 36+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d1);  
        
        
gathrillo::gui::Window d2(&desktop6, 9,  2+31+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d2);  
        
        
gathrillo::gui::Window d3(&desktop6, 9,  2+33+x, 37+y  -3, 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d3);  
              
gathrillo::gui::Window d4(&desktop6, 9,  2+36+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d4);
              
gathrillo::gui::Window d5(&desktop6, 9,  2+38+x, 35+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&d5);  
        
gathrillo::gui::Window e1(&desktop6, 9,  2+40+x, 30+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&e1);   
        
gathrillo::gui::Window f1(&desktop6, 9,  2+41+x, 29+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f1);  
              
gathrillo::gui::Window f2(&desktop6, 9,  2+41+x, 29+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f2);       
        
gathrillo::gui::Window f3(&desktop6, 9,  2+43+x, 28+y  -3, 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f3);       
        
gathrillo::gui::Window f4(&desktop6, 9,  2+48+x, 29+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f4);   
        
gathrillo::gui::Window f5(&desktop6, 9,  2+50+x, 30+y  -3, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&f5);  
    
gathrillo::gui::Window e2(&desktop6, 9,  2+51+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&e2);  
        
gathrillo::gui::Window g0(&desktop6, 9,  2+40+x, 35+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g0);   
        
gathrillo::gui::Window g1(&desktop6, 9,  2+41+x, 36+y  -3, 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g1);  
        
        
gathrillo::gui::Window g2(&desktop6, 9,  2+41+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g2);  
        
        
gathrillo::gui::Window g3(&desktop6, 9,  2+43+x, 37+y  -3, 5, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g3);  
        
        
gathrillo::gui::Window g4(&desktop6, 9,  2+48+x, 36+y  -3, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g4);
        
        
        
gathrillo::gui::Window g5(&desktop6, 9,  2+50+x, 35+y  -3, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&g5);  
  

gathrillo::gui::Window a5(&desktop6, 9,  2+52+x, 30+y -3, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a5); 

        
gathrillo::gui::Window a6(&desktop6, 9,  2+54+x, 30+y -3, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a6); 
 
gathrillo::gui::Window a7(&desktop6, 9,  2+55+x, 29+y -3, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a7); 
        
gathrillo::gui::Window a8(&desktop6, 9,  2+55+x, 36+y -3, 2, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a8);
        
    
//    
    
gathrillo::gui::Window a9(&desktop6, 9,  2+57+x, 28+y -3, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a9); 
           
gathrillo::gui::Window fi(&desktop6, 9,  2+57+x, 28+y -3, 8, 9,  0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fi); 
    
gathrillo::gui::Window fj(&desktop6, 9,  2+65+x, 30+y -3, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fj);  
    
gathrillo::gui::Window fk(&desktop6, 9,  2+56+x, 30+y -3, 1, 6, 0x00 , 0x00, 0xAF, 4);
desktop6.AddChild(&fk);  
        
gathrillo::gui::Window a10(&desktop6, 9,  2+57+x, 37+y -3, 8, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a10);
        
gathrillo::gui::Window a11(&desktop6, 9,  2+65+x, 29+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a11); 
        
gathrillo::gui::Window a12(&desktop6, 9,  2+65+x, 36+y -3, 1, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a12);
        
gathrillo::gui::Window a13(&desktop6, 9,  2+66+x, 30+y -3, 1, 6, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&a13);
    

  //Body  
    
      
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

     
    
    
    
    

// legs 1            
gathrillo::gui::Window ab1(&desktop6, 9, 50+x - 10, 29+y +20, 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zb1(&desktop6, 9, 53+x - 10, 28+y +20, 9, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb1);  
        
gathrillo::gui::Window zb2(&desktop6, 9, 62+x - 10, 28+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop6, 9, 50+x - 10, 36+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop6, 9, 53+x - 10, 36+y +20, 9, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop6, 9, 62+x - 10, 36+y +20 , 3, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop6, 9, 64+x - 10, 29+y +20 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab3);
 
    
//bend    
    
    
gathrillo::gui::Window ab4(&desktop6, 9, 56+x - 10, 36+y +20, 12, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop6, 9, 65+x - 10, 29+y +20, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop6, 9, 67+x - 10, 28+y +20, 6, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop6, 9, 73+x - 10, 28+y +20, 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab7);

gathrillo::gui::Window ab8(&desktop6, 9, 74+x - 10, 36+y +20, 1, 12, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab8);
        
    

gathrillo::gui::Window ab9(&desktop6, 9, 73+x - 10, 40+y +28, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab9);
        
        
    
    
gathrillo::gui::Window bb1(&desktop6, 9, 65+x - 10, 35+y +20, 2, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop6, 9, 67+x - 10, 36+y +20, 1, 16, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bb2);
        
 
        

 //legs 2
    
    
    
        

// legs            
gathrillo::gui::Window azb1(&desktop6, 9, 29+x +2, 50+y, 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab1);  
        
        
gathrillo::gui::Window zzb1(&desktop6, 9, 28+x +2, 51+y, 1, 11, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb1);  
        
gathrillo::gui::Window zzb2(&desktop6, 9, 28+x +2, 62+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb2);  

gathrillo::gui::Window azb2(&desktop6, 9, 36+x +2, 50+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb2);  
  

        
gathrillo::gui::Window zzb3(&desktop6, 9, 36+x +2, 53+y, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb3);  
        
gathrillo::gui::Window zzb4(&desktop6, 9, 36+x +2, 63+y , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&zzb4);          
//        
        
gathrillo::gui::Window azb3(&desktop6, 9, 29+x +2, 64+y , 8, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb3);
 
    
//bend    
    
 //knee  
    
    
gathrillo::gui::Window azb4(&desktop6, 9, 36+x +2, 56+y, 1, 12, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb4);
        
gathrillo::gui::Window azb5(&desktop6, 9, 29+x +2, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb5);
        
gathrillo::gui::Window azb6(&desktop6, 9, 36+x +2, 67+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb6);
        
        
gathrillo::gui::Window azb7(&desktop6, 9, 26+x +2, 73+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb7);
    
    
    
    
///////    

gathrillo::gui::Window azb8(&desktop6, 9, 36+x -20, 74+y, 12, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azb8);
        
    

gathrillo::gui::Window abz9(&desktop6, 9, 40+x -20, 73+y +28, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&abz9);
        
        
    
    
gathrillo::gui::Window bzb1(&desktop6, 9, 35+x -20, 65+y, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&ab5);
        
gathrillo::gui::Window bzb2(&desktop6, 9, 36+x -20, 67+y, 16, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&bzb2);
        
 
  
    
    
    
   /* 
    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);   
    
    
 */
    
    
    
desktop6.Draw(&vga6);
    
    

    
      
};

BoxerDavieCrouchPunchSprite::~BoxerDavieCrouchPunchSprite()
 {
     
 }







BoxerDavieCrouch::BoxerDavieCrouch(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 {
     gathrillo::models::BoxerDavieCrouchSprite(x,y+50,1,1,0x00,0x00,0x00);

 }

BoxerDavieCrouch::~BoxerDavieCrouch()
 {
     
 }






BoxerDavieShoes::BoxerDavieShoes(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
  
 
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

    
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop6, 9, 36+x, 83+y, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop6, 9, 40+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop6, 9, 39+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop6, 9, 41+x, 89+y, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop6, 9, 40+x, 93+y, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop6.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop6, 9, 45+x, 89+y, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop6.AddChild(&azzc11);

desktop6.Draw(&vga6);


};

BoxerDavieShoes::~BoxerDavieShoes()
 {
     
 }



Shoes2::Shoes2(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
  
 
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  

   
gathrillo::gui::Window azzc1(&desktop6, 9, 29+x, 83+y, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc1);
        
gathrillo::gui::Window azzc3(&desktop6, 9, 29+x, 83+y, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop6, 9, 36+x, 83+y, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&azzc4);   

       
gathrillo::gui::Window azzc6(&desktop6, 9, 29+x, 89+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop6, 9, 29+x, 93+y, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc7);
   
 
gathrillo::gui::Window azzc8(&desktop6, 9, 38+x, 90+y, 1, 3, 0x00 , 0x00, 0x00, 4); 
                
desktop6.AddChild(&azzc8);
   
        
    
    
desktop6.Draw(&vga6);


};

Shoes2::~Shoes2()
 {
     
 }




BoxerDavieBody::BoxerDavieBody(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
  
    
    
gathrillo::gui::Window aa1(&desktop6, 9, x+ 30, y+ 0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop6, 9, x+ 40, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop6, 9, x+ 29, y+ 1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop6, 9, x+ 41, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop6, 9, x+ 29, y+ 2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop6, 9, x+ 42, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop6, 9, x+ 28, y+ 3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop6, 9, x+ 28, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop6, 9, x+ 42, y+ 4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop6, 9, x+ 27, y+ 5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop6, 9, x+ 42, y+ 5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop6, 9, x+ 27, y+ 5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa12);   
    /*, TaskManager* taskManager*/
    
gathrillo::gui::Window aa13(&desktop6, 9, x+ 28, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop6, 9, x+ 29, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop6, 9, x+ 30, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop6, 9, x+ 42, y+ 9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop6, 9, x+ 43, y+ 10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop6, 9, x+ 43, y+ 11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop6, 9, x+ 42, y+ 12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop6, 9, x+ 42, y+ 13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop6, 9, x+ 41, y+ 19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop6, 9, x+ 40, y+ 20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop6, 9, x+ 39, y+ 21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop6, 9, x+ 40, y+ 26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop6, 9, x+ 41, y+ 27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop6, 9, x+ 40, y+ 50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop6, 9, x+ 29, y+ 26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop6, 9, x+ 30, y+ 34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop6, 9, x+ 29, y+ 42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop6, 9, x+ 30, y+ 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&aa31);   

    
    
    
    
    desktop6.Draw(&vga6);

    
    
};

  BoxerDavieBody::~BoxerDavieBody()
 {
     
 }




BoxerDavie::BoxerDavie(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t, common::uint8_t oof)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{






    
gathrillo::models::BoxerDavieBody(x,y,1,1,0x00,0x00,0x00);

//gathrillo::models::BoxerDavieLegs(x,y,0,0,0x00,0x00,0x00);
    
//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
gathrillo::models::BoxerDavieArm(2+x,-3+y,1,1,0x00,0x00,0x00,2);

   
//if(oof == 2) {
          
//gathrillo::models::BoxerDavieArmAct2(2+x,-3+y,1,1,0x00,0x00,0x00,2);
     
//}
//if(oof == 1) {
    

//gathrillo::models::BoxerDavieArmAct1(2+x,-3+y,1,1,0x00,0x00,0x00,0);

//}
    
    
    
//if(oof == 0) {

//gathrillo::models::BoxerDavieArm(2+x,-3+y,1,1,0x00,0x00,0x00,2);
     
//}


    
}

BoxerDavie::~BoxerDavie()
 {
     
 }





BoxerUpper::BoxerUpper(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t, common::uint8_t oof)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{





gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
int sprite = 0;
    
    
 //TaskManager taskManager; 
  
 GlobalDescriptorTable gdt;
  
 //gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);  
     
// gathrillo::drivers::PIT pit(&interrupts);    

        
    
 for(int i = 1; i <=2; i++)  
 {
     
     
     
gathrillo::gui::Window back1(&desktop5, 90, x, y, 70, 100, 0xFF, 0xFF, 0xFF, 4);
     
 //Body  
    
      
gathrillo::gui::Window aa1(&desktop5, 9, x-2+ 30, y+8+0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop5, 9, x-2+ 40, y+8+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop5, 9, x-2+ 29, y+8+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop5, 9, x-2+ 41, y+8+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop5, 9, x-2+ 29, y+8+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop5, 9, x-2+ 42, y+8+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop5, 9, x-2+ 28, y+8+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop5, 9, x-2+ 28, y+8+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop5, 9, x-2+ 42, y+8+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop5, 9, x-2+ 27, y+8+5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop5, 9, x-2+ 42, y+8+5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop5, 9, x-2+ 27, y+8+5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop5, 9, x-2+ 28, y+8+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop5, 9, x-2+ 29, y+8+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop5, 9, x-2+ 30, y+8+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop5, 9, x-2+ 42, y+8+9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop5, 9, x-2+ 43, y+8+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop5, 9, x-2+ 43, y+8+11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop5, 9, x-2+ 42, y+8+12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop5, 9, x-2+ 42, y+8+13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop5, 9, x-2+ 41, y+8+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop5, 9, x-2+ 40, y+8+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop5, 9, x-2+ 39, y+8+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop5, 9, x-2+ 40, y+8+26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop5, 9, x-2+ 41, y+8+27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop5, 9, x-2+ 40, y+8+50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop5, 9, x-2+ 29, y+8+26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop5, 9, x-2+ 30, y+8+34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop5, 9, x-2+ 29, y+8+42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop5, 9, x-2+ 30, y+6 + 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa31);   

       
    
     
    
    

// legs            
gathrillo::gui::Window ab1(&desktop5, 9, 29 +x-2, 50+y+8  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab1);  
        
        
gathrillo::gui::Window zbbbb1(&desktop5, 9, 28 +x-2, 53+y+8, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zbbbb1);  
        
gathrillo::gui::Window zb2(&desktop5, 9, 28 +x-2, 62+y+8 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop5, 9, 41 +x-2, 50+y+8 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop5, 9, 41 +x-2, 53+y+8, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop5, 9, 41 +x-2, 62+y+8 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop5, 9, 29 +x-2, 64+y+8 , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop5, 9, 36 +x-2, 56+y+8, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop5, 9, 29 +x-2, 65+y+8, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop5, 9, 28 +x-2, 67+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop5, 9, 28 +x-2, 71+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop5, 9, 28 +x-2, 75+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop5, 9, 29 +x-2, 79+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop5, 9, 35 +x-2, 65+y+8, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop5, 9, 36 +x-2, 67+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop5, 9, 36 +x-2, 71+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop5, 9, 36 +x-2, 75+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop5, 9, 35 +x-2, 79+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop5, 9, 40 +x-2, 65+y+8, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop5, 9, 41 +x-2, 67+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop5, 9, 41 +x-2, 71+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop5, 9, 41 +x-2, 75+y+8, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop5, 9, 40 +x-2, 79+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb5);

    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop5, 9, 29 +x-2, 83+y+8, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop5, 9, 36 +x-2, 83+y+8, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop5, 9, 29 +x-2, 83+y+8, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop5, 9, 36 +x-2, 83+y+8, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop5, 9, 40 +x-2, 83+y+8, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop5, 9, 29 +x-2, 89+y+8, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop5, 9, 29 +x-2, 93+y+8, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop5, 9, 39 +x-2, 89+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop5, 9, 41 +x-2, 89+y+8, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop5, 9, 40 +x-2, 93+y+8, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop5, 9, 45 +x-2, 89+y+8, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop5.AddChild(&azzc11);   
    
    
     
     
     
    
if(sprite < 1) {
     
desktop5.AddChild(&back1); 
    
 }
     
if(sprite == 0) 
    
{
     
gathrillo::models::BoxerDavieArmAct1 spr1(x,105,0,0,0x00,0x00,0x00, 0);



//gathrillo::models::BoxerDavieShoes spr1s(x,105,0,0,0x00,0x00,0x00);
    
////pit.Sleep(200);
    
  
}
    
     
if(sprite == 1) 
    
{
    

    
    

gathrillo::models::BoxerDavieArm4 arm4(x,105,0,0,0x00,0x00,0x00,0);



//gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
 
//pit.Beep(650, 500);
    

//pit.Sleep(1500);

    
    
}

   

     
  
       
   // Pit.music1();     
    desktop5.Draw(&vga5);

    sprite++;
}

  

    gathrillo::models::BoxerDavieArm arm5(x,105,0,0,0x00,0x00,0x00,0);

    

//gathrillo::models::BoxerDavieSprite1 spp(x,105,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes spps(x,105,0,0,0x00,0x00,0x00);
      
 
    
 
    
}

BoxerUpper::~BoxerUpper()
 {
     
 }




BoxerDavieBlockAnim::BoxerDavieBlockAnim(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t w,common::uint8_t h, common::uint8_t r, common::uint8_t g, common::uint8_t, common::uint8_t oof)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{





gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
int sprite = 0;
    
    
 ////TaskManager taskManager; 
  
 GlobalDescriptorTable gdt;
  
 ////gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);  
     
// gathrillo::drivers::PIT pit(&interrupts);    

        
    
 for(int i = 1; i <=2; i++)  
 {
     
     
     
gathrillo::gui::Window back1(&desktop5, 90, x, y, 70, 100, 0xFF, 0xFF, 0xFF, 4);
     
 //Body  
    
      
gathrillo::gui::Window aa1(&desktop5, 9, x-2+ 30, y+8+0 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa1);   

gathrillo::gui::Window aa2(&desktop5, 9, x-2+ 40, y+8+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa2);   
    
    
gathrillo::gui::Window aa3(&desktop5, 9, x-2+ 29, y+8+1 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa3);   
    
gathrillo::gui::Window aa4(&desktop5, 9, x-2+ 41, y+8+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa4);   
    
    
gathrillo::gui::Window aa5(&desktop5, 9, x-2+ 29, y+8+2 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa5);   
    
gathrillo::gui::Window aa6(&desktop5, 9, x-2+ 42, y+8+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa6);   
    
gathrillo::gui::Window aa7(&desktop5, 9, x-2+ 28, y+8+3 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa7);   
    
gathrillo::gui::Window aa8(&desktop5, 9, x-2+ 28, y+8+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa8);   
    
    
gathrillo::gui::Window aa9(&desktop5, 9, x-2+ 42, y+8+4 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa9);   
    
gathrillo::gui::Window aa10(&desktop5, 9, x-2+ 27, y+8+5 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa10);

gathrillo::gui::Window aa11(&desktop5, 9, x-2+ 42, y+8+5 , 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa11);   

gathrillo::gui::Window aa12(&desktop5, 9, x-2+ 27, y+8+5 , 1, 14, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa12);   
    
    
gathrillo::gui::Window aa13(&desktop5, 9, x-2+ 28, y+8+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa13);   
    
gathrillo::gui::Window aa14(&desktop5, 9, x-2+ 29, y+8+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa14);   
   
gathrillo::gui::Window aa15(&desktop5, 9, x-2+ 30, y+8+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa15); 
    
    
gathrillo::gui::Window aa16(&desktop5, 9, x-2+ 42, y+8+9 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa16);   
    
gathrillo::gui::Window aa17(&desktop5, 9, x-2+ 43, y+8+10 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa17);   
     
gathrillo::gui::Window a19(&desktop5, 9, x-2+ 43, y+8+11 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&a19);   
    
gathrillo::gui::Window aa20(&desktop5, 9, x-2+ 42, y+8+12 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa20);

gathrillo::gui::Window aa21(&desktop5, 9, x-2+ 42, y+8+13 , 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa21);   

gathrillo::gui::Window aa22(&desktop5, 9, x-2+ 41, y+8+19 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa22);   
    
    
gathrillo::gui::Window aa23(&desktop5, 9, x-2+ 40, y+8+20 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa23);   
    
gathrillo::gui::Window aa24(&desktop5, 9, x-2+ 39, y+8+21 , 1, 5, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa24);   
    
    
gathrillo::gui::Window aa25(&desktop5, 9, x-2+ 40, y+8+26 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa25);   
    
gathrillo::gui::Window aa26(&desktop5, 9, x-2+ 41, y+8+27 , 1, 23, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa26);   
    
gathrillo::gui::Window aa27(&desktop5, 9, x-2+ 40, y+8+50 , 1, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa27);   
    
gathrillo::gui::Window aa28(&desktop5, 9, x-2+ 29, y+8+26 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa28);    
    
gathrillo::gui::Window aa29(&desktop5, 9, x-2+ 30, y+8+34 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa29);   
    
gathrillo::gui::Window aa30(&desktop5, 9, x-2+ 29, y+8+42 , 1, 8, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa30);

gathrillo::gui::Window aa31(&desktop5, 9, x-2+ 30, y+6 + 50 , 10, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&aa31);   

       
    
     
    
    

// legs            
gathrillo::gui::Window ab1(&desktop5, 9, 29 +x-2, 50+y+8  , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab1);  
        
        
gathrillo::gui::Window zbbbb1(&desktop5, 9, 28 +x-2, 53+y+8, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zbbbb1);  
        
gathrillo::gui::Window zb2(&desktop5, 9, 28 +x-2, 62+y+8 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb2);  

gathrillo::gui::Window ab2(&desktop5, 9, 41 +x-2, 50+y+8 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab2);  
  

        
gathrillo::gui::Window zb3(&desktop5, 9, 41 +x-2, 53+y+8, 1, 9, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb3);  
        
gathrillo::gui::Window zb4(&desktop5, 9, 41 +x-2, 62+y+8 , 1, 3, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&zb4);          
//        
        
gathrillo::gui::Window ab3(&desktop5, 9, 29 +x-2, 64+y+8 , 13, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab3);
                
gathrillo::gui::Window ab4(&desktop5, 9, 36 +x-2, 56+y+8, 1, 15, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab4);
        
gathrillo::gui::Window ab5(&desktop5, 9, 29 +x-2, 65+y+8, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window ab6(&desktop5, 9, 28 +x-2, 67+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab6);
        
        
gathrillo::gui::Window ab7(&desktop5, 9, 28 +x-2, 71+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab7);
        
gathrillo::gui::Window ab8(&desktop5, 9, 28 +x-2, 75+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab8);
        
gathrillo::gui::Window ab9(&desktop5, 9, 29 +x-2, 79+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab9);
        
        
        
gathrillo::gui::Window bb1(&desktop5, 9, 35 +x-2, 65+y+8, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&ab5);
        
gathrillo::gui::Window bb2(&desktop5, 9, 36 +x-2, 67+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb2);
        
        
gathrillo::gui::Window b3(&desktop5, 9, 36 +x-2, 71+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&b3);
        
gathrillo::gui::Window bb4(&desktop5, 9, 36 +x-2, 75+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb4);
        
gathrillo::gui::Window bb5(&desktop5, 9, 35 +x-2, 79+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&bb5);
        
        
        
gathrillo::gui::Window cb1(&desktop5, 9, 40 +x-2, 65+y+8, 1, 2, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb1);
        
gathrillo::gui::Window cb2(&desktop5, 9, 41 +x-2, 67+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb2);
        
        
gathrillo::gui::Window cb3(&desktop5, 9, 41 +x-2, 71+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb3);
        
gathrillo::gui::Window cb4(&desktop5, 9, 41 +x-2, 75+y+8, 1, 4, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&cb4);
        
gathrillo::gui::Window cb5(&desktop5, 9, 40 +x-2, 79+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&cb5);

    
 /// Shoes

    
gathrillo::gui::Window azzc1(&desktop5, 9, 29 +x-2, 83+y+8, 7, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc1);
        
gathrillo::gui::Window azzc2(&desktop5, 9, 36 +x-2, 83+y+8, 4, 1, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc2);
   
gathrillo::gui::Window azzc3(&desktop5, 9, 29 +x-2, 83+y+8, 1, 10, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc3);

gathrillo::gui::Window azzc4(&desktop5, 9, 36 +x-2, 83+y+8, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc4);   

        
gathrillo::gui::Window azzc5(&desktop5, 9, 40 +x-2, 83+y+8, 1, 6, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&azzc5);
           
       
gathrillo::gui::Window azzc6(&desktop5, 9, 29 +x-2, 89+y+8, 10, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc6);
        
gathrillo::gui::Window azzc7(&desktop5, 9, 29 +x-2, 93+y+8, 15, 1, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc7);
        
gathrillo::gui::Window azzc8(&desktop5, 9, 39 +x-2, 89+y+8, 1, 4, 0x00 , 0x00, 0x00, 4); 
                
desktop5.AddChild(&azzc8);
        
        
gathrillo::gui::Window azzc9(&desktop5, 9, 41 +x-2, 89+y+8, 4, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc9);
        
     
gathrillo::gui::Window azzc10(&desktop5, 9, 40 +x-2, 93+y+8, 5, 1, 0x00 , 0x00, 0x00, 4);
desktop5.AddChild(&azzc10);

        
gathrillo::gui::Window azzc11(&desktop5, 9, 45 +x-2, 89+y+8, 1, 4, 0x00 , 0x00, 0x00, 4);
                
desktop5.AddChild(&azzc11);   
    
    
     
     
     
    
if(sprite < 1) {
     
desktop5.AddChild(&back1); 
    
 }
     
if(sprite == 0) 
    
{
     
gathrillo::models::BoxerDavieArmAct1 spr1(x,105,0,0,0x00,0x00,0x00, 0);



//gathrillo::models::BoxerDavieShoes spr1s(x,105,0,0,0x00,0x00,0x00);
    
////pit.Sleep(200);
    
  
}
    
     
if(sprite == 1) 
    
{
    

    
    

gathrillo::models::BoxerDavieArm4 arm4(x-5,105,0,0,0x00,0x00,0x00,0);



//gathrillo::models::BoxerDavieShoes(x,105,0,0,0x00,0x00,0x00);
 
//pit.Beep(650, 500);
    

//pit.Sleep(3500);

    
    
}

   

     
  
       
   // Pit.music1();     
    desktop5.Draw(&vga5);

    sprite++;
}

  

    gathrillo::models::BoxerDavieArm arm5(x,105,0,0,0x00,0x00,0x00,0);

    

//gathrillo::models::BoxerDavieSprite1 spp(x,105,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes spps(x,105,0,0,0x00,0x00,0x00);
      
 
    
 
    
}

BoxerDavieBlockAnim::~BoxerDavieBlockAnim()
 {
     
 }








Char::Char(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame, common::uint8_t run1,common::uint8_t run2)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
    
gathrillo::gui::Window pixel1(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
gathrillo::gui::Window pixel1b(&pixel1, 90, 0 + x, 8 +y, 5, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel1b);
    
gathrillo::gui::Window pixel1c(&pixel1, 90, 5 + x ,15 + y, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel1c);
    
gathrillo::gui::Window pixel2(&pixel1, 90, 1 +x,13 +y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
gathrillo::gui::Window pixel3(&pixel1, 90, 1 +x,14 +y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
gathrillo::gui::Window pixel4(&pixel1, 90, 1 +x,15 +y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
    
   
    
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 7 +x, 13+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 6 +x,14+y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 5 +x,15+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
    
    
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 4 +x,10+y, 1, 14, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 4+x,24+y, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 4+x,23+y, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 4+x,22+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 4+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 1+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 8+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 3+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 0+x,10+y, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    

    //legs
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 5+x,34+y, 3, 8 + run2, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 4+x,34+y, 1, 8 + run1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    //
     gathrillo::gui::Window pixel27(&pixel1, 90, 2+x,25+y, 8, 8, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 2+x,25+y, 8, 8, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
 
    

 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 5+x,20+y, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 3+x,21+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 3+x,29+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
      
    
    
    
    
    desktop5.Draw(&vga5);

    
    
}

  Char::~Char()
 {
     
 }

CharAttack::CharAttack(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame, common::uint8_t run1,common::uint8_t run2)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
    
gathrillo::gui::Window pixel1(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
gathrillo::gui::Window pixel1b(&pixel1, 90, 0 + x, 8 +y, 5, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel1b);
    
gathrillo::gui::Window pixel1c(&pixel1, 90, 5 + x ,15 + y, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel1c);
    
gathrillo::gui::Window pixel2(&pixel1, 90, 1 +x,13 +y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
gathrillo::gui::Window pixel3(&pixel1, 90, 1 +x,14 +y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
gathrillo::gui::Window pixel4(&pixel1, 90, 1 +x,15 +y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
    
   
    
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 7 +x, 13+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 6 +x,14+y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 5 +x,15+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
    
    
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 4 +x,10+y, 1, 14, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 4+x,24+y, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 4+x,23+y, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 4+x,22+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 4+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 1+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 8+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 3+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 0+x,10+y, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    

    //legs
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 5+x,34+y, 3, 8 + run2, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 4+x,34+y, 1, 8 + run1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    //
     gathrillo::gui::Window pixel27(&pixel1, 90, 2+x,25+y, 3, 8, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 2+x,25+y, 12, 3, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
 gathrillo::gui::Window gun(&pixel1, 90, 20+x,24+y, 3, 4, r, g, b, 4);
     pixel1.AddChild(&gun);
    
     gathrillo::gui::Window gun2(&pixel1, 90, 25+x,23+y, 3, 6, r, g, b, 4);
     pixel1.AddChild(&gun2);
    
     gathrillo::gui::Window gun3(&pixel1, 90, 30+x,22+y, 3, 8, r, g, b, 4);
     pixel1.AddChild(&gun3);
    
     gathrillo::gui::Window gun4(&pixel1, 90, 35+x,21+y, 3, 10, r, g, b, 4);
     pixel1.AddChild(&gun4);
    

 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 5+x,20+y, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 3+x,21+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 3+x,29+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
      
    
    
    
    
    desktop5.Draw(&vga5);

    
    
}

  CharAttack::~CharAttack()
 {
     
 }




CharRun::CharRun(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame, common::uint8_t run1,common::uint8_t run2)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
    
gathrillo::gui::Window pixel1(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
gathrillo::gui::Window pixel1b(&pixel1, 90, 0 + x, 8 +y, 5, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel1b);
    
gathrillo::gui::Window pixel1c(&pixel1, 90, 5 + x ,15 + y, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel1c);
    
gathrillo::gui::Window pixel2(&pixel1, 90, 1 +x,13 +y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
gathrillo::gui::Window pixel3(&pixel1, 90, 1 +x,14 +y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
gathrillo::gui::Window pixel4(&pixel1, 90, 1 +x,15 +y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
 
    gathrillo::gui::Window pixel10(&pixel1, 90, 7 +x, 13+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 6 +x,14+y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 5 +x,15+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
    
    
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 4 +x,10+y, 1, 14, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 4+x,24+y, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 4+x,23+y, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 4+x,22+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 4+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 1+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 8+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 3+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 0+x,10+y, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    

    //legs
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 5+x,34+y, 3, 10 , 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 4+x,34+y, 1, 8, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    //
     gathrillo::gui::Window pixel27(&pixel1, 90, 2+x,25+y, 8, 8, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 2+x,25+y, 8, 8, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
 
    

 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 5+x,20+y, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 3+x,21+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 3+x,29+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
      
    
    
    
    
    
    
gathrillo::models::Lv1 lvp1(0, -100, 0,0, 0, 1);        

gathrillo::gui::Window pixel2d(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel2d);
    
gathrillo::gui::Window pixel2b(&pixel1, 90, 0 + x, 8 +y, 5, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2b);
    
gathrillo::gui::Window pixel2c(&pixel1, 90, 5 + x ,15 + y, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel2c);
    
gathrillo::gui::Window pixel6(&pixel1, 90, 1 +x,13 +y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel6);
    
gathrillo::gui::Window pixel7(&pixel1, 90, 1 +x,14 +y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel7);
    
gathrillo::gui::Window pixel8(&pixel1, 90, 1 +x,15 +y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel8);
 
    gathrillo::gui::Window pixel50(&pixel1, 90, 7 +x, 13+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel50);

     gathrillo::gui::Window pixel51(&pixel1, 90, 6 +x,14+y, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel51);
    
     gathrillo::gui::Window pixel52(&pixel1, 90, 5 +x,15+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel52);
    
    
    
    
     gathrillo::gui::Window pixel53(&pixel1, 90, 4 +x,10+y, 1, 14, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel53);
    
    
    
     
    
    gathrillo::gui::Window pixel57(&pixel1, 90, 4+x,24+y, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel57);
    
    gathrillo::gui::Window pixel58(&pixel1, 90, 4+x,23+y, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel58);
    
     gathrillo::gui::Window pixel59(&pixel1, 90, 4+x,22+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel59);
    
    
    
    
    gathrillo::gui::Window pixel60(&pixel1, 90, 4+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel60);
    
    gathrillo::gui::Window pixel61(&pixel1, 90, 1+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel61);
    
    
    gathrillo::gui::Window pixel62(&pixel1, 90, 8+x,9+y, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel62);
    
    gathrillo::gui::Window pixel63(&pixel1, 90, 3+x,8+y, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel63);
    
     gathrillo::gui::Window pixel64(&pixel1, 90, 0+x,10+y, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel64);
    
    

    //legs
    
    gathrillo::gui::Window pixel65(&pixel1, 90, 5+x,34+y, 3, 8 + run2, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel65);
    
    gathrillo::gui::Window pixel66(&pixel1, 90, 4+x,34+y, 1, 10 + run1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel66);
    //
     gathrillo::gui::Window pixel67(&pixel1, 90, 2+x,25+y, 8, 8, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel67);

     gathrillo::gui::Window pixel68(&pixel1, 90, 2+x,25+y, 8, 8, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel68);
    
 
    

 
     
    gathrillo::gui::Window pixel71(&pixel1, 90, 5+x,20+y, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel71);
    
    gathrillo::gui::Window pixel72(&pixel1, 90, 3+x,21+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel72);
    
     gathrillo::gui::Window pixel73(&pixel1, 90, 3+x,29+y, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel73);
    
    
    
    desktop5.Draw(&vga5);

    
    
}




CharRun::~CharRun()
 {
     
 }





CharJump::CharJump(/*Widget* parent,*/ common::int32_t x, common::int32_t y, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t frame, common::uint8_t run1,common::uint8_t run2)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

{
    
gathrillo::drivers::VideoGraphicsArray vga5;
vga5.SetMode(160,120,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 
  
    
    gathrillo::models::Char ridgeystrt(x+25, y-5, 0,0, 0, 1, run1, run2);

    
  gathrillo::models::Lv1 lvp1(0, -100, 0,0, 0, 1);        

    
    
    gathrillo::models::Char ridgeyend(x+25, y, 0,0, 0, 1, run1, run2);
    
    desktop5.Draw(&vga5);

    
    
}

  CharJump::~CharJump()
 {
     
 }
  




  


Gardenbed::Gardenbed(/*Widget* parent,*/ common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{

    

    
    if(gathrillo::gui::Widget::Angle == 90 || 270) {
    
              
  gathrillo::gui::Cube_m  whynot(gathrillo::gui::Widget::Angle, 1, Gardenbed::x = 100, Gardenbed::y = 100, 20, 20, 0xFE, 0xFE, 0xFE);

  
     
  

    }
    
    if(gathrillo::gui::Widget::Angle == 270) {
    
              
  gathrillo::gui::Cube_m  whynot(gathrillo::gui::Widget::Angle, 1, Gardenbed::x = 100, Gardenbed::y = 100, 20, 20, 0xFE, 0xFE, 0xFE);

  
     
  

    }
      
if(gathrillo::gui::Widget::Angle == 0 || gathrillo::gui::Widget::Angle == 180) {
    
                
  gathrillo::gui::Cube_m whynot(gathrillo::gui::Widget::Angle, 1, Gardenbed::x = 100, Gardenbed::y = 100, 50, 20, 0xFE, 0xFE, 0xFE);

  
     
    
    
}
          
if(gathrillo::gui::Widget::Angle == 45 || gathrillo::gui::Widget::Angle == 225) {
    
              
  gathrillo::gui::Cube_m whynot(gathrillo::gui::Widget::Angle, 1, Gardenbed::x = 100, Gardenbed::y = 100, 50, 5, 0xFE, 0xFE, 0xFE);

  
     
    
}
  
    
    
if(gathrillo::gui::Widget::Angle == 135) {
    
     
                   
  gathrillo::gui::Cube_m whynot(gathrillo::gui::Widget::Angle, 1, x, y, 50, 5, 0xFE, 0xFE, 0xFE);


}    
    

    
}

  Gardenbed::~Gardenbed()
 {
     
 }






OBJReaderInit::OBJReaderInit(/*Widget* parent,*/ common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
  int c = 8; 
  double co[c][3] = {{0.0, 0.0, 0.0 },{0.0, 0.0, 1.0},{0.0, 1.0, 0.0},{0.0, 1.0, 1.0},{1.0, 0.0, 0.0},{1.0, 0.0, 1.0},{1.0, 1.0, 0.0},{1.0, 1.0, 1.0}};
    
    
   
    
int v1x;
int v2x;
int v3x;
int v4x;
int v5x;
int v6x;
int v7x;
int v8x;
    
int v1y;
int v2y;
int v3y;
int v4y;
int v5y;
int v6y;
int v7y;
int v8y;
    
int v1z;
int v2z;
int v3z;
int v4z;
int v5z;
int v6z;
int v7z;
int v8z;
    
    
v1x = co[0][0] *scale;
v2x = co[1][0] *scale;
v3x = co[2][0] *scale;
v4x = co[3][0] *scale;
v5x = co[4][0] *scale;
v6x = co[5][0] *scale;
v7x = co[6][0] *scale;
v8x = co[7][0] *scale;
    
v1y = co[0][1] *scale;
v2y = co[1][1] *scale;
v3y = co[2][1] *scale;
v4y = co[3][1] *scale;
v5y = co[4][1] *scale;
v6y = co[5][1] *scale;
v7y = co[6][1] *scale;
v8y = co[7][1] *scale;
    
v1z = co[0][2] *scale;
v2z = co[1][2] *scale;
v3z = co[2][2] *scale;
v4z = co[3][2] *scale;
v5z = co[4][2] *scale;
v6z = co[5][2] *scale;
v7z = co[6][2] *scale;
v8z = co[7][2] *scale;

    
    
gathrillo::gui::vertex v1 (ang, v1x + x, v1y + y, z,  1, 1, r, g, b);

      
    
gathrillo::gui::vertex v2 (ang, v2x + x, v2y + y, z,  1, 1, r, g, b);
      
       
    
gathrillo::gui::vertex v3 (ang, v3x + x, v1y + y, z,  1, 1, r, g, b);

      
    
gathrillo::gui::vertex v4 (ang, v4x + x, v4y + y, z,  1, 1, r, g, b);
      
gathrillo::gui::vertex v5 (ang, v5x + x, v5y + y, z,  1, 1, r, g, b);

      
    
gathrillo::gui::vertex v6 (ang, v6x + x, v6y + y, z,  1, 1, r, g, b);
      
       
    
gathrillo::gui::vertex v7 (ang, v7x + x, v7y + y, z,  1, 1, r, g, b);

      
    
gathrillo::gui::vertex v8 (ang, v8x + x, v8y + y, z,  1, 1, r, g, b);



//FRONT


gathrillo::gui::face f1 (0,ang, x, y, 4,1, v1x,  v7x, v5x,  v1y,  v7y, v5y, v1z, v7z, v5z, 1, r, g, b, id);
  
gathrillo::gui::face f2 (0,ang, x, y, 4,1, v1x, v3x, v7x,  v1y,  v3y, v7y, v1z, v3z, v7z, 1, r, g, b, id);
    

//BACK
    
gathrillo::gui::face f3 (0,ang, x, y, 4,1, v2x,  v6x, v8x,  v2y,  v6y, v8y, v2z, v6z, v8z, 1, r, g, b, id);
  
gathrillo::gui::face f4 (0,ang, x, y, 4,1, v2x, v8x, v4x, v2y,  v8y, v4y, v2z, v8z, v4z, 1, r, g, b, id);

    
}

  OBJReaderInit::~OBJReaderInit()
 {
     
 }
  



OBJReader::OBJReader(/*Widget* parent,*/ common::uint8_t trans, common::uint8_t att, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b,common::uint8_t id, common::uint8_t zbuffer)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
    
    int int1;
    int oof03;
    
    
    gathrillo::drivers::VideoGraphicsArray vga5;
    vga5.SetMode(0,0,8);
    gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 
  
 
   //if(trans = 1)
    
    gathrillo::gui::Window l(&desktop5, 0, x, y+trans , scale, 1 , r, g, b, 0); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5);
    
    
    
    
    
    
    
    
    
    if(id == 1){
        
    int1 = scale+(scale/2)+scale/4-1;
  
    }
    
    if(id == 2) {
        
     int1 = 0;
    }
    
    oof03 = 103;    
      
    if(oof03 > 103){
    
    oof03 = 103;    

    }
    
    if(id > 0){
        
      gathrillo::models::OBJReaderInit obj(ang, x, y, 0, scale, r, g, b, 1);
      
    if(scale > 15)
    scale = 15;
 

    if(id > 1){
     
        
   
      gathrillo::models::OBJReaderInit obj2(oof03, x-scale+trans, y, 0, 9, r, g, b, 2);
        
   
        
        
        
    if(id > 2){
     
   
      gathrillo::models::OBJReaderInit obj2(oof03, x-scale*2+(trans*2), y, 0, 9, r, g, b, 2);
        
        
        
        
        
        
        }
    
        
        
    }
        
        
    }
        
        
        
        
};

  OBJReader::~OBJReader()
 {
     
 }

 Model::Model(/*Widget* parent,*/ common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer)
 : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 {
    
     gathrillo::drivers::VideoGraphicsArray vga5;
     vga5.SetMode(320,200,8);
     gathrillo::gui::Desktop desktop5(0, 0, 0x00,0x00,0x00); 
    
    
 //Widget* parent, common::uint8_t ang,common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h,common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t size
  
     
    
     int rotya = 128;
     //gathrillo::models::OBJReader cube0(trans, 0, ang, x + (rotx * 14)+ attz), y, 0, scale, r, g, b, 1, 0);     

    //gathrillo::gui::Window facing0(&desktop5, ang, x + (rotx * 14)+ attz, y, scale,  scale, r, g, b, 4); 
    //desktop5.AddChild(&facing0);
    
     
    if(roty == 0)
    rotya = 0;
        
     
    if(attx > 0) {

    gathrillo::models::OBJReader cube( trans, 0, ang, (x + (scale) + (rotx*13)+ attz)-((roty*14)), y+(roty*14), 0, scale, r, g, b, 1, 0);     
   
    
   // gathrillo::gui::Window facing(&desktop5, ang, x + (rotx * 14)+ attz, y, scale*2,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing);    


    if(attx > 1) {
    gathrillo::models::OBJReader cube1( trans, 0, ang, (x + (scale * 2) + (rotx*12)+ attz)-((roty*13)), y+(roty*13), 0, scale, r, g, b, 1, 0);     
    
    //gathrillo::gui::Window facing(&desktop5, ang, (x + (scale * 2) + (rotx*12)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing);    
    
    if(attx > 2) {
    gathrillo::models::OBJReader cube2( trans, 0, ang, (x + (scale * 3) + (rotx*11)+ attz)-((roty*12)), y+(roty*12), 0, scale, r, g, b, 1, 0);     
    
        
   // gathrillo::gui::Window facing2(&desktop5, ang, (x + (scale * 3) + (rotx*11)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing2);    
        
        
    if(attx > 3) {
    gathrillo::models::OBJReader cube3(trans, 0, ang, (x + (scale * 4) + (rotx*10)+ attz)-((roty*11)), y+(roty*11), 0, scale, r, g, b, 1, 0);     
    
        
   // gathrillo::gui::Window facing3(&desktop5, ang, (x + (scale * 4) + (rotx*10)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing3);    
        
        
    if(attx > 4) {
    gathrillo::models::OBJReader cube4(trans, 0, ang, (x + (scale * 5) + (rotx*9)+ attz)-((roty*10)), y+(roty*10), 0, scale, r, g, b, 1, 0);     
    
    //gathrillo::gui::Window facing4(&desktop5, ang, (x + (scale * 5) + (rotx*9)+ attz, y, scale,  scale, r, g, b, 4); 
    //desktop5.AddChild(&facing4);    
        
        
    if(attx > 5) {
    gathrillo::models::OBJReader cube5(trans, 0, ang, (x + (scale * 6) + (rotx*8)+ attz)-((roty*9)), y+(roty*9), 0, scale, r, g, b, 1, 0);     
    
        
    //gathrillo::gui::Window facing5(&desktop5, ang, (x + (scale * 6) + (rotx*8)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing5);    
        
        
        
    if(attx > 6) {
    gathrillo::models::OBJReader cube6(trans, 0, ang, (x + (scale * 7) + (rotx*7)+ attz)-((roty*8)), y+(roty*8), 0, scale, r, g, b, 1, 0); 
    
        
        
   // gathrillo::gui::Window facing6(&desktop5, ang, (x + (scale * 7) + (rotx*7)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing6);    
        
        
        
    if(attx > 7) {

    gathrillo::models::OBJReader cube7(trans, 0, ang, (x + (scale * 8) + (rotx*6)+ attz)-((roty*7)), y+(roty*7), 0, scale, r, g, b, 1, 0);     
   
        
    //gathrillo::gui::Window facing7(&desktop5, ang, (x + (scale * 8) + (rotx*6)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing7);    
        
        
    if(attx > 8) {
    gathrillo::models::OBJReader cube8(trans, 0, ang, (x + (scale * 9) + (rotx*5)+ attz)-((roty*6)), y+(roty*6), 0, scale, r, g, b, 1, 0);     
    
    //gathrillo::gui::Window facing8(&desktop5, ang, (x + (scale * 9) + (rotx*5)+ attz, y, scale,  scale, r, g, b, 4); 
    //desktop5.AddChild(&facing8);    
        
        
    if(attx > 9) {
    gathrillo::models::OBJReader cube9(trans, 0, ang, (x + (scale * 10) + (rotx*4)+ attz)-((roty*5)), y+(roty*5), 0, scale, r, g, b, 1, 0);     
    
        
        
   // gathrillo::gui::Window facing9(&desktop5, ang, (x + (scale * 10) + (rotx*4)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing9);    
        
        
    if(attx > 10) {
    gathrillo::models::OBJReader cube10(trans, 0, ang, (x + (scale * 11) + (rotx*3)+ attz)-((roty*4)), y+(roty*4), 0, scale, r, g, b, 1, 0);     
    
        
        
   // gathrillo::gui::Window facing10(&desktop5, ang, (x + (scale * 11) + (rotx*3)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing10);    
        
        
    if(attx > 11) {
    gathrillo::models::OBJReader cube11(trans, 0, ang, (x + (scale * 12) + (rotx*2)+ attz)-((roty*3)), y+(roty*3), 0, scale, r, g, b, 1, 0);     
    
        
        
   // gathrillo::gui::Window facing11(&desktop5, ang, (x + (scale * 12) + (rotx*2)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing11);    
        
        
    if(attx > 12) {
    gathrillo::models::OBJReader cube12(trans, 0, ang, (x + (scale * 13) + (rotx*1)+ attz)-((roty*2)), y+(roty*2), 0, scale, r, g, b, 1, 0);     
    
        
   // gathrillo::gui::Window facing12(&desktop5, ang, (x + (scale * 13) + (rotx*1)+ attz, y, scale,  scale, r, g, b, 4); 
    //desktop5.AddChild(&facing12);    
        
        
    if(attx > 13) {
    gathrillo::models::OBJReader cube13(trans, 0, ang, (x + (scale * 14)+ attz)-((roty*1)), y+(roty*1), 0, scale, r, g, b, 1, 0);     
    
    
   // gathrillo::gui::Window facing13(&desktop5, ang, (x + (scale * 14)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing13);    
        
        

                            }
                        }
                    }
                }
            }
        }
    }
    }
    }
    }
    }
    }
    }
    }
     desktop5.Draw(&vga5);

 
 }





/*
 if(attx > 0) {

    gathrillo::models::OBJReader cube( trans, 0, ang, (x + (scale) + (rotx*13)+ attz)-((roty*14)), (y+(roty*14*0.25) + rotya), 0, scale, r, g, b, 1, 0);     
   
    
   // gathrillo::gui::Window facing(&desktop5, ang, x + (rotx * 14)+ attz, y, scale*2,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing);    


    if(attx > 1) {
    gathrillo::models::OBJReader cube1( trans, 0, ang, (x + (scale * 2) + (rotx*12)+ attz)-((roty*13)), (y+(roty*13*0.25) - (rotya/2)) , 0, scale, r, g, b, 1, 0);     
    
    //gathrillo::gui::Window facing(&desktop5, ang, (x + (scale * 2) + (rotx*12)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing);    
    
    if(attx > 2) {
    gathrillo::models::OBJReader cube2( trans, 0, ang, (x + (scale * 3) + (rotx*11)+ attz)-((roty*12)), (y+(roty*12*0.25)), 0, scale, r, g, b, 1, 0);     
    
        
   // gathrillo::gui::Window facing2(&desktop5, ang, (x + (scale * 3) + (rotx*11)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing2);    
        
        
    if(attx > 3) {
    gathrillo::models::OBJReader cube3(trans, 0, ang, (x + (scale * 4) + (rotx*10)+ attz)-((roty*11)), (y+(roty*11*0.25) +  (rotya/2)), 0, scale, r, g, b, 1, 0);     
    
        
   // gathrillo::gui::Window facing3(&desktop5, ang, (x + (scale * 4) + (rotx*10)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing3);    
        
        
    if(attx > 4) {
    gathrillo::models::OBJReader cube4(trans, 0, ang, (x + (scale * 5) + (rotx*9)+ attz)-((roty*10)), (y+(roty*10*0.25) + rotya), 0, scale, r, g, b, 1, 0);     
    
    //gathrillo::gui::Window facing4(&desktop5, ang, (x + (scale * 5) + (rotx*9)+ attz, y, scale,  scale, r, g, b, 4); 
    //desktop5.AddChild(&facing4);    
        
        
    if(attx > 5) {
    gathrillo::models::OBJReader cube5(trans, 0, ang, (x + (scale * 6) + (rotx*8)+ attz)-((roty*9)), (y+(roty*9*0.25) - (rotya/2)), 0, scale, r, g, b, 1, 0);     
    
        
    //gathrillo::gui::Window facing5(&desktop5, ang, (x + (scale * 6) + (rotx*8)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing5);    
        
        
        
    if(attx > 6) {
    gathrillo::models::OBJReader cube6(trans, 0, ang, (x + (scale * 7) + (rotx*7)+ attz)-((roty*8)), (y+(roty*8*0.25)), 0, scale, r, g, b, 1, 0); 
    
        
        
   // gathrillo::gui::Window facing6(&desktop5, ang, (x + (scale * 7) + (rotx*7)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing6);    
        
        
        
    if(attx > 7) {

    gathrillo::models::OBJReader cube7(trans, 0, ang, (x + (scale * 8) + (rotx*6)+ attz)-((roty*7)), (y+(roty*7*0.25) +  (rotya/2)), 0, scale, r, g, b, 1, 0);     
   
        
    //gathrillo::gui::Window facing7(&desktop5, ang, (x + (scale * 8) + (rotx*6)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing7);    
        
        
    if(attx > 8) {
    gathrillo::models::OBJReader cube8(trans, 0, ang, (x + (scale * 9) + (rotx*5)+ attz)-((roty*6)), (y+(roty*6*0.25) + (rotya)), 0, scale, r, g, b, 1, 0);     
    
    //gathrillo::gui::Window facing8(&desktop5, ang, (x + (scale * 9) + (rotx*5)+ attz, y, scale,  scale, r, g, b, 4); 
    //desktop5.AddChild(&facing8);    
        
        
    if(attx > 9) {
    gathrillo::models::OBJReader cube9(trans, 0, ang, (x + (scale * 10) + (rotx*4)+ attz)-((roty*5)), (y+(roty*5*0.25) -  (rotya/2)), 0, scale, r, g, b, 1, 0);     
    
        
        
   // gathrillo::gui::Window facing9(&desktop5, ang, (x + (scale * 10) + (rotx*4)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing9);    
        
        
    if(attx > 10) {
    gathrillo::models::OBJReader cube10(trans, 0, ang, (x + (scale * 11) + (rotx*3)+ attz)-((roty*4)), (y+(roty*4*0.25) ), 0, scale, r, g, b, 1, 0);     
    
        
        
   // gathrillo::gui::Window facing10(&desktop5, ang, (x + (scale * 11) + (rotx*3)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing10);    
        
        
    if(attx > 11) {
    gathrillo::models::OBJReader cube11(trans, 0, ang, (x + (scale * 12) + (rotx*2)+ attz)-((roty*3)), (y+(roty*3*0.25) + (rotya/2)), 0, scale, r, g, b, 1, 0);     
    
        
        
   // gathrillo::gui::Window facing11(&desktop5, ang, (x + (scale * 12) + (rotx*2)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing11);    
        
        
    if(attx > 12) {
    gathrillo::models::OBJReader cube12(trans, 0, ang, (x + (scale * 13) + (rotx*1)+ attz)-((roty*2)), (y+(roty*2*0.25) +  (rotya)), 0, scale, r, g, b, 1, 0);     
    
        
   // gathrillo::gui::Window facing12(&desktop5, ang, (x + (scale * 13) + (rotx*1)+ attz, y, scale,  scale, r, g, b, 4); 
    //desktop5.AddChild(&facing12);    
        
        
    if(attx > 13) {
    gathrillo::models::OBJReader cube13(trans, 0, ang, (x + (scale * 14)+ attz)-((roty*1)), (y+(roty*1*0.25) - (rotya/2)), 0, scale, r, g, b, 1, 0);     
    
    
   // gathrillo::gui::Window facing13(&desktop5, ang, (x + (scale * 14)+ attz, y, scale,  scale, r, g, b, 4); 
   // desktop5.AddChild(&facing13);    
        
        
*/







Terrain::Terrain(/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer)
 : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 {
    /*
     gathrillo::drivers::VideoGraphicsArray vga5;
     vga5.SetMode(320,200,8);
     gathrillo::gui::Desktop desktop5(0, 0, 0x00,0x00,0x00); 
    */  
     //for(int render = 50; render > trans; render--){

  
     
    int modoff1 = 0;
    int modoff2 = 0;
    int scaleoff0 =  0;
    int scaleoff1 = -1;
    int scaleoff2 = -3;
    int scaleoff3 = -6;
    int scaleoff4 = -7.5;
    int scaleoff5 = -9;
    int scaleoff6 = -12;
    int scaling = 1;
   
     
     
     
    if(rotatex == 0) {
    scaling = 0;   
    }
    if(rotatex == 1) {
    scaling = 0;   
    }
    if(rotatex == 2) {
    scaling = 0;   
    }
    
     
     
    
    if(rotatex == 1)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1.5 + z;
    scaleoff2 = -3 + z;
    scaleoff3 = -6 + z;
    scaleoff4 = -7.5 + z;
    scaleoff5 = -9 + z;
    scaleoff6 = -12 + z;
        
    }
    if(rotatex == 2)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1.5 + z;
    scaleoff2 = -3 + z;
    scaleoff3 = -6 + z;
    scaleoff4 = -7.5 + z;
    scaleoff5 = -9 + z;
    scaleoff6 = -12 + z;
        
    }
    if(rotatex == 3)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -2.5;
    scaleoff3 = -4.5;
    scaleoff4 = -6;
    scaleoff5 = -7.125;
    scaleoff6 = -9;
        
    }
    if(rotatex == 4)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -2.5 + z;
    scaleoff3 = -4.5 + z;
    scaleoff4 = -6 + z;
    scaleoff5 = -7.125 + z;
    scaleoff6 = -9 + z;
        
    }
    if(rotatex == 5)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -2 + z;
    scaleoff3 = -3 + z;
    scaleoff4 = -4.5 + z;
    scaleoff5 = -5.25 + z;
    scaleoff6 = -6 + z;
        
    }
    if(rotatex == 6)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -2 + z;
    scaleoff3 = -3 + z;
    scaleoff4 = -4.5 + z;
    scaleoff5 = -5.25 + z;
    scaleoff6 = -6 + z;
        
    }
    if(rotatex == 7)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -1.5 + z;
    scaleoff3 = -2 + z;
    scaleoff4 = -3.125 + z;
    scaleoff5 = -3.75 + z;
    scaleoff6 = -4.5 + z;
        
    }
    if(rotatex == 8)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -1.5 + z;
    scaleoff3 = -2 + z;
    scaleoff4 = -3.375 + z;
    scaleoff5 = -3.75 + z;
    scaleoff6 = -4.5 + z;
        
    }
    if(rotatex == 9)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -1 + z;
    scaleoff3 = -1.5 + z;
    scaleoff4 = -2.25 + z;
    scaleoff5 = -2.5125 + z;
    scaleoff6 = -3 + z;
        
    }
    if(rotatex == 10)
    {
    scaleoff0 =  0 + z;
    scaleoff1 = -1 + z;
    scaleoff2 = -1 + z;
    scaleoff3 = -1.5 + z;
    scaleoff4 = -2.25 + z;
    scaleoff5 = -2.5125 + z;
    scaleoff6 = -3 + z;
        
    }
    if(rotatex == 11) 
    {
    scaleoff0 = 0 + z;
    scaleoff1 = 0 + z;
    scaleoff2 = 0 + z;
    scaleoff3 = 0 + z;
    scaleoff4 = 0 + z;
    scaleoff5 = 0 + z;
    scaleoff6 = 0 + z;
        
    }
    if(rotatex == 12) 
    {
    scaleoff0 = 0 + z;
    scaleoff1 = 0 + z;
    scaleoff2 = 0 + z;
    scaleoff3 = 0 + z;
    scaleoff4 = 0 + z;
    scaleoff5 = 0 + z;
    scaleoff6 = 0 + z;
        
    }
   
    //gathrillo::models::SkyBox Sky(rotx, trans, attx,  atty, attz, ang, x, y, z, scale, 0x00, 0x00, 0xAF, id, zbuffer);   

     
     //gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x + id,  y - (1*id), z, scale, r, g, b, id, zbuffer);   

     if(id > 0 && scaleoff1 > -4 && scaleoff0 <= 0) 
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*1)+ attz), y - (2*rotatex), z, scale + (z), r, g, b, id, zbuffer);   
     
     if(id > 1 && scaleoff1 > -4 && scaleoff1 <= 0)
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*2)+ attz) - (scaleoff1*9) + scaleoff1, y - (3*rotatex) - (z*2*scaling), z, scale + (z) + scaleoff1, r, g, b, id, zbuffer);   
      
     if(id > 2 && scaleoff2 > -4 && scaleoff2 <= 0)
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*3)+ attz) - (scaleoff2*8), y - (4*rotatex) - ((z*4)*scaling), z, scale + (z) + scaleoff2, r, g, b, id, zbuffer);   
    
     if(id > 3  && scaleoff3 > -4 && scaleoff3 <= 0)
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*4)+ attz) - (scaleoff3*7) - scaleoff3, y - (5*rotatex) - ((z*6)*scaling), z, scale + (z) + scaleoff3, r, g, b, id, zbuffer);   
      
     if(id > 4  && scaleoff4 > -4 && scaleoff4 <= 0)
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*5)+ attz) - (scaleoff4*8) - (scaleoff4/4), y - (6*rotatex) - ((z*8)*scaling), z, scale + (z) + scaleoff4, r, g, b, id, zbuffer);   
     
     if(id > 5  && scaleoff5 > -4 && scaleoff5 <=  0)
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*6)+ attz) - (scaleoff5*8), y - (7*rotatex) - ((z*10)*scaling), z, scale + (z) + scaleoff5, r, g, b, id, zbuffer);
    
     if(id > 6 && scaleoff6 > -4 && scaleoff6 <= 0)
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*7)+ attz) - (scaleoff6*8), y - (8*rotatex) - ((z*12)*scaling), z, scale + (z) + scaleoff6, r, g, b, id, zbuffer); 
    
     
     
     
     
     
     

      

     
     
     
     
     
     
     
     ////offset version
     /*
      gathrillo::models::SkyBox Sky(rotx, trans, attx,  atty, attz, ang, x, y, z, scale, 0x00, 0x00, 0xAF, id, zbuffer);   

     
     //gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x + id,  y - (1*id), z, scale, r, g, b, id, zbuffer);   

     if(id > 0) {
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*1)+ attz), y - (2*rotatex), z, scale + (z), r, g, b, id, zbuffer);   
     
     if(id > 1){
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*2)+ attz) - (scaleoff1*1), y - (3*rotatex), z, scale + (z) + scaleoff1, r, g, b, id, zbuffer);   
      
     if(id > 2){
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*3)+ attz) - (scaleoff2*2), y - (4*rotatex), z, scale + (z) + scaleoff2, r, g, b, id, zbuffer);   
    
     if(id > 3){
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*4)+ attz) - (scaleoff3*3)- - (scaleoff3*3), y - (5*rotatex), z, scale + (z) + scaleoff3, r, g, b, id, zbuffer);   
      
     if(id > 4){
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*5)+ attz) - (scaleoff4*4) - (scaleoff4*3), y - (6*rotatex), z, scale + (z) + scaleoff4, r, g, b, id, zbuffer);   
     
     if(id > 5){
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*6)+ attz) - (scaleoff5*5)- (scaleoff5*3), y - (7*rotatex), z, scale + (z) + scaleoff5, r, g, b, id, zbuffer);
    
     if(id > 6){
     gathrillo::models::Model cube(rotx, roty, trans, attx, atty, attz, ang, x+((attz*7)+ attz) - (scaleoff6*6)- (scaleoff6*2), y - (8*rotatex), z, scale + (z) + scaleoff6, r, g, b, id, zbuffer); 
    
     }
     }
     }
     }
     }
     }

      

     }
     
     
     */
     
     
     /*
     
     
     if(id > 0) {
      gathrillo::models::Model cube(rotx, roty, trans, attx - 13 + rotatex*1.7, atty, attz, ang, x+((attz*1)+ attz) + 2 -(rotatex*1)/2.5,  y - (2*rotatex), z, scale, r, g, b, id, zbuffer);   
     
     if(id > 1){
      gathrillo::models::Model cube(rotx, roty, trans, attx - 19 + rotatex*1.7, atty, attz, ang, x+((attz*2)+ attz) + 7 -(rotatex*2)/2.5, y - (3*rotatex), z, scale, r, g, b, id, zbuffer);   
      
     if(id > 2){
     gathrillo::models::Model cube(rotx, roty, trans, attx - 21 + rotatex*1.7, atty, attz, ang, x+((attz*3)+ attz) + 12 -(rotatex*3)/2.5,   y - (4*rotatex), z, scale, r, g, b, id, zbuffer);   
    
     if(id > 3){
     gathrillo::models::Model cube(rotx, roty, trans, attx - 23 + rotatex*1.7, atty, attz, ang, x+((attz*4)+ attz) + 17 -(rotatex*4)/2.5,   y - (5*rotatex), z, scale, r, g, b, id, zbuffer);   
      
         
     if(id > 4){
     gathrillo::models::Model cube(rotx, roty, trans, attx - 25 + rotatex*1.7, atty, attz, ang, x+((attz*5)+ attz) + 22 -(rotatex*5)/2.5,   y - (6*rotatex), z, scale, r, g, b, id, zbuffer);   
     
     if(id > 5){
     gathrillo::models::Model cube(rotx, roty, trans, attx - 26 + rotatex*1.7, atty, attz, ang, x+((attz*6)+ attz) + 27 -(rotatex*6)/2.5,  y - (7*rotatex), z, scale, r, g, b, id, zbuffer);
    
     if(id > 6){
     gathrillo::models::Model cube(rotx, roty, trans, attx - 27 + rotatex*1.7, atty, attz, ang, x+((attz*7)+ attz) + 32 -(rotatex*7)/2.5, y - (8*rotatex), z, scale, r, g, b, id, zbuffer); 
     
     */
     
     
     
     
     
     
/*
shrinking tester version



     if(id > 0) {
      gathrillo::models::Model cube(rotx, trans, attx - 29 + id*2.5, atty, attz, ang, x+((attz*1)+ attz) + 2 -(id*1)/2.5,  y - (2*id), z, scale, r, g, b, id, zbuffer);   
     
     if(id > 1){
      gathrillo::models::Model cube(rotx, trans, attx - 31 + id*2.5, atty, attz, ang, x+((attz*2)+ attz) + 6 -(id*2)/2.5, y - (3*id), z, scale, r, g, b, id, zbuffer);   
      
     if(id > 2){
     gathrillo::models::Model cube(rotx, trans, attx - 32 + id*2.5, atty, attz, ang, x+((attz*3)+ attz) + 10 -(id*3)/2.5,   y - (4*id), z, scale, r, g, b, id, zbuffer);   
    
     if(id > 3){
     gathrillo::models::Model cube(rotx, trans, attx - 33 + id*2.5, atty, attz, ang, x+((attz*4)+ attz) + 14 -(id*4)/2.5,   y - (5*id), z, scale, r, g, b, id, zbuffer);   
      
         
     if(id > 4){
     gathrillo::models::Model cube(rotx, trans, attx - 34 + id*2.5, atty, attz, ang, x+((attz*5)+ attz) + 18 -(id*5)/2.5,   y - (6*id), z, scale, r, g, b, id, zbuffer);   
     
     if(id > 5){
     gathrillo::models::Model cube(rotx, trans, attx - 35 + id*2.5, atty, attz, ang, x+((attz*6)+ attz) + 22 -(id*6)/2.5,  y - (7*id), z, scale, r, g, b, id, zbuffer);
    
     if(id > 6){
     gathrillo::models::Model cube(rotx, trans, attx - 36 + id*2.5, atty, attz, ang, x+((attz*7)+ attz) + 26 -(id*7)/2.5, y - (8*id), z, scale, r, g, b, id, zbuffer); 
     
     }
     }
     }
     }
     }
     }
     }
     */
     
          
     
    

     
     
         
     }
 
 


FreezingFire::FreezingFire(/*Widget* parent,*/ common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{

    

 
    
    
    
    
    if(gathrillo::gui::Widget::Angle == 0) {
    
     
    gathrillo::gui::Polygon _1(0,0, 9, 0, x+41, y-8, 3, h, 0xA1, 0xA1, 0xA1);  
        
    gathrillo::gui::Polygon _2(0,0, 9, 0, x+36, y-8, 3, h, 0xA1, 0xA1, 0xA1);  
    
    gathrillo::gui::Polygon _3(0,0, 9, 0, x+46, y-8, 3, h, 0xA1, 0xA1, 0xA1);
 
    gathrillo::gui::Polygon _4(0,0, 9, 3, x+2, y-3, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon _5(0,0, 9, 3, x+7, y-3, 4, h, 0xA1, 0xA1, 0xA1);    
        
    gathrillo::gui::Polygon a(0,0, 9, 3, x, y, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon b(0,0, 9, 3, x+7, y, 5, h, 0xA1, 0xA1, 0xA1);
     
    gathrillo::gui::Polygon c(0,0, 9, 0, x+32, y-4, 4, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon d(0,0, 9, 0, x+40, y-4, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon e(0,0, 9, 0, x+47, y-4, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon f(0,0, 9, 3, x-4, y+4, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon g(0,0, 9, 3, x+3, y+4, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon i(0,0, 9, 3, x+11, y+4, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon j(0,0, 9, 0, x+43, y, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon k(0,0, 9, 0, x+36, y, 4, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon l(0,0, 9, 3, x, y+8, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon m(0,0, 9, 3, x+7, y+8, 5, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon n(0,0, 9, 4, x+50, y+8, 6, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon o(0,0, 9, 1, x+52, y, 4, h, 0xA1, 0xA1, 0xA1);
          
        
    gathrillo::gui::Polygon q(0,0, 9, 0, x+40, y+4, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon r(0,0, 9, 0, x+47, y+4, 4, h, 0xA1, 0xA1, 0xA1);
           
    gathrillo::gui::Polygon s(0,0, 9, 0, x+32, y+4, 4, h, 0xA1, 0xA1, 0xA1);
        
    
    gathrillo::gui::Polygon t(0,0, 9, 3, x-4, y+12, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon u(0,0, 9, 3, x+3, y+12, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon v(0,0, 9, 3, x+11, y+12, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon w(0,0, 9, 0, x+43, y+8, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon z(0,0, 9, 0, x+36, y+8, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon a_2(0,0,9, 1, x+52, y+8, 4, h, 0xA1, 0xA1, 0xA1);
  
     gathrillo::gui::Polygon b_2(0,0, 9, 3, x, y+16, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon c_2(0,0, 9, 3, x+7, y+16, 5, h, 0xA1, 0xA1, 0xA1);
        
        
    gathrillo::gui::Polygon d_2(0,0, 9, 0, x+40, y+12, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon e_2(0,0, 9, 0, x+47, y+12, 4, h, 0xA1, 0xA1, 0xA1);
           
    gathrillo::gui::Polygon ff_2(0,0, 9, 2, x+37, y+12, -0, h, 0xA1, 0xA1, 0xA1);    
        
    gathrillo::gui::Polygon f_2(0,0, 9, 4, x+35, y+20, 6, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon g_2(0,0, 9, 3, x+3, y+20, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon h_2(0,0, 9, 3, x+11, y+20, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon i_2(0,0, 9, 4, x+50, y+16, 6, h, 0xA1, 0xA1, 0xA1); 
        
        
    gathrillo::gui::Polygon j_2(0,0, 9, 0, x+43, y+16, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon k_2(0,0, 9, 2, x+41, y+16, -1, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon l_2(0,0, 9, 3, x+3, y+24, 7, h, 0xA8, 0x00, 0xA8);

        
    
    
        
        
    } 
    
    
       if(gathrillo::gui::Widget::Angle == 90) {
    
     
     gathrillo::gui::Polygon _1(90,90, 9, 0, x+41, y-8, 3, h, 0xA1, 0xA1, 0xA1);  
        
    gathrillo::gui::Polygon _2(90,90, 9, 0, x+36, y-8, 3, h, 0xA1, 0xA1, 0xA1);  
    
    gathrillo::gui::Polygon _3(90,90, 9, 0, x+46, y-8, 3, h, 0xA1, 0xA1, 0xA1);
 
    gathrillo::gui::Polygon _4(90,90, 9, 3, x-7, y-3, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon _5(90,90, 9, 3, x-9, y-3, 4, h, 0xA1, 0xA1, 0xA1);    
        
    gathrillo::gui::Polygon a(90,90, 9, 3, x-9, y, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon b(90,90, 9, 3, x-2, y, 5, h, 0xA1, 0xA1, 0xA1);
     
    gathrillo::gui::Polygon c(90,90, 9, 0, x+32, y-4, 4, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon d(90,90, 9, 0, x+40, y-4, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon e(90,90, 9, 0, x+47, y-4, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon f(90,90, 9, 3, x-13, y+4, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon g(90,90, 9, 3, x-6, y+4, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon i(90,90, 9, 3, x+2, y+4, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon j(90,90, 9, 0, x+43, y, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon k(90,90, 9, 0, x+36, y, 4, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon l(90,90, 9, 3, x, y-1, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon m(90,90, 9, 3, x-2, y+8, 5, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon n(90,90, 9, 4, x+50, y+8, 6, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon o(90,90, 9, 1, x+52, y, 4, h, 0xA1, 0xA1, 0xA1);
          
        
    gathrillo::gui::Polygon q(90,90, 9, 0, x+40, y+4, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon r(90,90, 9, 0, x+47, y+4, 4, h, 0xA1, 0xA1, 0xA1);
           
    gathrillo::gui::Polygon s(90,90, 9, 0, x+32, y+4, 4, h, 0xA1, 0xA1, 0xA1);
        
    
    gathrillo::gui::Polygon t(90,90, 9, 3, x-13, y+12, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon u(90,90, 9, 3, x-6, y+12, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon v(90,90, 9, 3, x+2, y+12, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon w(90,90, 9, 0, x+43, y+8, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon z(90,90, 9, 0, x+36, y+8, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon a_2(90,90,9, 1, x+52, y+8, 4, h, 0xA1, 0xA1, 0xA1);
  
     gathrillo::gui::Polygon b_2(90,90, 9, 3, x-9, y+16, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon c_2(90,90, 9, 3, x-2, y+16, 5, h, 0xA1, 0xA1, 0xA1);
        
        
    gathrillo::gui::Polygon d_2(90,90, 9, 0, x+40, y+12, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon e_2(90,90, 9, 0, x+47, y+12, 4, h, 0xA1, 0xA1, 0xA1);
           
    gathrillo::gui::Polygon ff_2(90,90, 9, 2, x+37, y+12, -0, h, 0xA1, 0xA1, 0xA1);    
        
    gathrillo::gui::Polygon f_2(90,90, 9, 4, x+35, y+20, 6, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon g_2(90,90, 9, 3, x-6, y+20, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon h_2(90,90, 9, 3, x+2, y+20, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon i_2(90,90, 9, 4, x+50, y+16, 6, h, 0xA1, 0xA1, 0xA1); 
        
        
    gathrillo::gui::Polygon j_2(90,90, 9, 0, x+43, y+16, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon k_2(90,90, 9, 2, x+41, y+16, -1, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon l_2(90,90, 9, 3, x-6, y+24, 7, h, 0xA8, 0x00, 0xA8);

        
    //right and center       
    gathrillo::gui::Polygon l_2oof(90,90, 9, 21, x+34, y-5, 3, 8, 0xA1, 0xA1, 0xA1);  
    
    gathrillo::gui::Polygon l_2oof2(90,90, 9, 21, x+35, y+9, 1, 2, 0xA1, 0xA1, 0xA1); 
        
    gathrillo::gui::Polygon l_2oof3(90,90, 9, 21, x+36, y+11, 1, 2, 0xA1, 0xA1, 0xA1); 
    
    gathrillo::gui::Polygon l_2oof4(90,90, 9, 21, x+38, y+12, 1, 2, 0xA1, 0xA1, 0xA1); 
        
    
    gathrillo::gui::Polygon c_1(90,90, 9, 21, x+30, y-11, 18, 1, 0x00, 0x00, 0x00); 
    gathrillo::gui::Polygon c_4(90,90, 9, 21, x+53, y-9, 1, 1, 0x00, 0x00, 0x00); 
     
    gathrillo::gui::Polygon c_3(90,90, 9, 3, x-9, y+8, 5, h, 0xA1, 0xA1, 0xA1);       
           
    }
   
    
    if(gathrillo::gui::Widget::Angle == 180) {
    
  
  
     
        
    gathrillo::gui::Polygon _1(180,180, 9, 0, x+41, y-8, 3, h, 0xA1, 0xA1, 0xA1);  
        
    gathrillo::gui::Polygon _2(180,180, 9, 0, x+36, y-8, 3, h, 0xA1, 0xA1, 0xA1);  
    
    gathrillo::gui::Polygon _3(180,180, 9, 0, x+46, y-8, 3, h, 0xA1, 0xA1, 0xA1);
 
    gathrillo::gui::Polygon _4(180,180, 9, 3, x-2, y-3, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon _5(180,180, 9, 3, x+3, y-3, 4, h, 0xA1, 0xA1, 0xA1);    
        
    gathrillo::gui::Polygon a(180,180, 9, 3, x-4, y, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon b(180,180, 9, 3, x+3, y, 5, h, 0xA1, 0xA1, 0xA1);
     
    gathrillo::gui::Polygon c(180,180, 9, 0, x+32, y-4, 4, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon d(180,180, 9, 0, x+40, y-4, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon e(180,180, 9, 0, x+47, y-4, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon f(180,180, 9, 3, x-7, y+4, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon g(180,180, 9, 3, x-1, y+4, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon i(180,180, 9, 3, x+2, y+4, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon j(180,180, 9, 0, x+43, y, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon k(180,180, 9, 0, x+36, y, 4, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon l(180,180, 9, 3, x-4, y+8, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon m(180,180, 9, 3, x+3, y+8, 5, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon n(180,180, 9, 4, x+50, y+8, 6, h, 0xA1, 0xA1, 0xA1);
    
    gathrillo::gui::Polygon o(180,180, 9, 1, x+52, y, 4, h, 0xA1, 0xA1, 0xA1);
          
        
    gathrillo::gui::Polygon q(180,180, 9, 0, x+40, y+4, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon r(180,180, 9, 0, x+47, y+4, 4, h, 0xA1, 0xA1, 0xA1);
           
    gathrillo::gui::Polygon s(180,180, 9, 0, x+32, y+4, 4, h, 0xA1, 0xA1, 0xA1);
        
    
    gathrillo::gui::Polygon t(180,180, 9, 3, x-8, y+12, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon u(180,180, 9, 3, x-1, y+12, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon v(180,180, 9, 3, x+3, y+12, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon w(180,180, 9, 0, x+43, y+8, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon z(180,180, 9, 0, x+36, y+8, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon a_2(180,180,9, 1, x+52, y+8, 4, h, 0xA1, 0xA1, 0xA1);
  
     gathrillo::gui::Polygon b_2(180,180, 9, 3, x-4, y+16, 5, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon c_2(180,180, 9, 3, x+3, y+16, 5, h, 0xA1, 0xA1, 0xA1);
        
        
    gathrillo::gui::Polygon d_2(180,180, 9, 0, x+40, y+12, 4, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon e_2(180,180, 9, 0, x+47, y+12, 4, h, 0xA1, 0xA1, 0xA1);
           
    gathrillo::gui::Polygon ff_2(180,180, 9, 2, x+37, y+12, -0, h, 0xA1, 0xA1, 0xA1);    
        
    gathrillo::gui::Polygon f_2(180,180, 9, 4, x+35, y+20, 6, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon g_2(180,180, 9, 3, x-1, y+20, 5, h, 0xA1, 0xA1, 0xA1);
   
    gathrillo::gui::Polygon h_2(180,180, 9, 3, x+1, y+20, 5, h, 0xA1, 0xA1, 0xA1);

    gathrillo::gui::Polygon i_2(180,180, 9, 4, x+50, y+16, 6, h, 0xA1, 0xA1, 0xA1); 
        
        
    gathrillo::gui::Polygon j_2(180,180, 9, 0, x+43, y+16, 4, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon k_2(180,180, 9, 2, x+41, y+16, -1, h, 0xA1, 0xA1, 0xA1);
        
    gathrillo::gui::Polygon l_2(180,180, 9, 3, x-3, y+24, 7, h, 0xA8, 0x00, 0xA8);    
        
        
        
  
     
  //right and center       
    gathrillo::gui::Polygon l_2oof(180,180, 9, 21, x+34, y-5, 3, 8, 0xA1, 0xA1, 0xA1);  
    
    gathrillo::gui::Polygon l_2oof2(180,180, 9, 21, x+35, y+9, 1, 2, 0xA1, 0xA1, 0xA1); 
        
    gathrillo::gui::Polygon l_2oof3(180,180, 9, 21, x+36, y+11, 1, 2, 0xA1, 0xA1, 0xA1); 
    
    gathrillo::gui::Polygon l_2oof4(180,180, 9, 21, x+38, y+12, 1, 2, 0xA1, 0xA1, 0xA1); 
        
    
        
      
    //right only    
    gathrillo::gui::Polygon oof(180,180, 9, 21, x+53, y-5, 3, 8, 0x00, 0x00, 0x00);  
    
    gathrillo::gui::Polygon oof2(180,180, 9, 21, x+54, y+9, 1, 2, 0x00, 0x00, 0x00); 
        
    gathrillo::gui::Polygon oof3(180,180, 9, 21, x+52, y+11, 1, 2, 0x00, 0x00, 0x00); 
    
    gathrillo::gui::Polygon oof4(180,180, 9, 21, x+53, y+12, 1, 2, 0x00, 0x00, 0x00); 
        
    gathrillo::gui::Polygon oof5(180,180, 9, 21, x+51, y+14, 2, 1, 0x00, 0x00, 0x00); 
            
        
    gathrillo::gui::Polygon right1(180,180, 9, 2, x+51, y+2, -1, 1, 0xA1, 0xA1, 0xA1); 
        
    gathrillo::gui::Polygon right2(180,180, 9, 5, x+51, y+10, 1, 1, 0xA1, 0xA1, 0xA1); 
        
     gathrillo::gui::Polygon right3(180,180, 9, 21, x+48, y+7, 2, 4, 0xA1, 0xA1, 0xA1); 
        
    gathrillo::gui::Polygon right4(180,180, 9, 21, x+51, y+5, 1, 4, 0xA1, 0xA1, 0xA1); 

    }
    
    
      
if(gathrillo::gui::Widget::Angle == 0 || gathrillo::gui::Widget::Angle == 180) {
    
                

     
    
    
}
          
if(gathrillo::gui::Widget::Angle == 45 || gathrillo::gui::Widget::Angle == 225) {
    
              

     
    
}
  
    
    
if(gathrillo::gui::Widget::Angle == 135) {
    
     
                   

     
    
    
    

}    
    

  

      
      
      
   
    
}

  FreezingFire::~FreezingFire()
 {
     
 }
  


Ground_3d_model::Ground_3d_model(/*Widget* parent,*/ common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang,x,y,w,h,r,g,b,size,tri)
{

    
  
      gathrillo::gui::Cube bruh(gathrillo::gui::Widget::Angle, 8, x + 39, y-8, 200, 50, 0xFE, 0xFE, 0xFE);
 
}

  Ground_3d_model::~Ground_3d_model()
 {
     
 }





SkyBox::SkyBox(/*Widget* parent,*/ common::uint8_t rot, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer)
 : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 {

          
     gathrillo::drivers::VideoGraphicsArray vga6;
     vga6.SetMode(160,120,8);
     gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
     gathrillo::gui::Camera cam2(0,0,0,0,0,0,0); 
    
     gathrillo::gui::Window polygon4(&desktop6, 9, 130, 70 , 60, 60, 0x00, 0x00, 0xA8, 4); 
    desktop6.AddChild(&polygon4);
     
    gathrillo::gui::Window polygon3(&desktop6, 9, 0, 0 , 320, 200, r , g, b, 4); 
    desktop6.AddChild(&polygon3); 
     
  
     
    desktop6.Draw(&vga6);

     

 }
///////////////////////////////////MAPS//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
GrassMap::GrassMap(/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer)
 : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 {

     
       
    int jump_animation = 0;
    int arm_rotation_L = 0;
    int arm_rotation_R = 0;
    int arm_rotation_L_offset = 0;
    int arm_rotation_R_offset = 0;  
     
     
    
    
    TaskManager taskManager; 
  
    GlobalDescriptorTable gdt;
  
    gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);
    gathrillo::drivers::PIT pit(&interrupts);    
  
      
     
    if(zbuffer == 1){
    

        
    if(arm_rotation_L == -1)
    arm_rotation_L_offset = 2;
     
    if(arm_rotation_L == -2)
    arm_rotation_L_offset = 5;
     
    if(arm_rotation_L == -3)
    arm_rotation_L_offset = 8;
     
    if(arm_rotation_R == 1)
    arm_rotation_R_offset = -2;
     
    if(arm_rotation_R == 2)
    arm_rotation_R_offset = -5;
     
    if(arm_rotation_R == 3)
    arm_rotation_R_offset = -8;
   
   
    }
     
      
    gathrillo::models::SkyBox Sky(rotx, trans, attx,  atty, attz, ang, x, y, z, scale, 0x00, 0x00, 0xAF, id, zbuffer);
       
    gathrillo::models::Terrain a_0(5, 5, roty, trans, 25, 78, attz, ang, -10-(z*2)+ x, 190+(z*4) + y, 0+z, 10, 0x00, 0xA8, 0x00, 10, 0);
    gathrillo::models::Terrain a_1(5, 5, roty, trans, 25, 78, attz, ang, 20-(z*2)+ x, 190+(z*4) + y, 0+z, 10, 0x00, 0xA8, 0x00, 10, 0);
    gathrillo::models::Terrain a_2(5, 5, roty, trans, 25, 78, attz, ang, 50-(z*2)+ x, 190+(z*4) + y, 0+z, 10, 0x00, 0xA8, 0x00, 10, 0);
    gathrillo::models::Terrain a_3(5, 5, roty, trans, 25, 78, attz, ang, 80-(z*2)+ x, 190+(z*4) + y, 0+z, 10, 0x00, 0xA8, 0x00, 10, 0);
     
    gathrillo::models::Terrain spine(11, 5, roty, 0, 1, 78, 0, ang, 80, 150 + y, 0, 10, 0xFF, 0xFF, 0xFF, 3, 0);
    gathrillo::models::Terrain head(11, 5, roty, 0, 1, 78, 0, ang, 80, 117 + y, 0, 10, 0xFF, 0xFF, 0xFF, 1, 0);
    gathrillo::models::Terrain armL(11, 5, roty, 0, 1, 78, arm_rotation_L, ang, 70 + arm_rotation_L_offset, 120 + y, 0, 10, 0xFF, 0xFF, 0xFF, 3, 0);
    gathrillo::models::Terrain armR(11, 5, roty, 0, 1, 78, arm_rotation_R, ang, 90 + arm_rotation_R_offset, 120 + y, 0, 10, 0xFF, 0xFF, 0xFF, 3, 0);
    gathrillo::models::Terrain LegL(11, 5, roty, 0, 1, 78, 0, ang, 75, 194 + y, 0, 10, 0xFF, 0xFF, 0xFF, 4, 0);
    gathrillo::models::Terrain LegR(11, 5, roty, 0, 1, 78, 0, ang, 85, 194 + y, 0, 10, 0xFF, 0xFF, 0xFF, 4, 0);

 
     
     
    //gathrillo::models::Terrain b_0(11, 5, -2, trans, 25, 78, 5, ang, 60-(z*2)+ x, 190+(z*4) + y, 0+z, 10, 0x00, 0xA8, 0x00, 10, 0); 


     
     
    //gathrillo::models::SkyBox Sky(rot, trans, attx,  atty, attz, ang, x, y, z, scale, 0x00, 0x00, 0xAF, id, zbuffer);   

    //gathrillo::models::Terrain oof(rot, trans, attx,  atty, attz, ang, x-40, y, z, scale, r, g, b, id-3, zbuffer);   
    //gathrillo::models::Terrain oof1(rot, trans, attx,  atty, attz, ang, (x+65)-40, y, z, scale, r, g, b, id-3, zbuffer);   
    //gathrillo::models::Terrain oof2(rot, trans, attx,  atty, attz, ang, (x-65)-40, y, z, scale, r, g, b, id-3, zbuffer);   



















































 }
SwingModel::SwingModel(/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer)
 : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 {

    int jump_animation = 0;
    int arm_rotation_L = 0;
    int arm_rotation_R = 0;
    int arm_rotation_L_offset = 0;
    int arm_rotation_R_offset = 0;
     
    TaskManager taskManager; 
  
    GlobalDescriptorTable gdt;
  
    gathrillo::hardwarecommunication::InterruptManager interrupts(0x20, &gdt, &taskManager);
    gathrillo::drivers::PIT pit(&interrupts);    
 
     
    if(zbuffer == 1){
    

        
    if(arm_rotation_L == -1)
    arm_rotation_L_offset = 2;
     
    if(arm_rotation_L == -2)
    arm_rotation_L_offset = 5;
     
    if(arm_rotation_L == -3)
    arm_rotation_L_offset = 8;
     
    if(arm_rotation_R == 1)
    arm_rotation_R_offset = -2;
     
    if(arm_rotation_R == 2)
    arm_rotation_R_offset = -5;
     
    if(arm_rotation_R == 3)
    arm_rotation_R_offset = -8;
   
   
    }
   
   
     
     
 
     
    //gathrillo::models::SkyBox Sky(rotx, trans, attx,  atty, attz, ang, x, y, z, scale, 0x00, 0x00, 0xAF, id, zbuffer);
     
    gathrillo::models::Terrain spine(11, 5, roty, trans, 1, 78, 0, ang, 80 + x, 100 + y, 0+z, 10, 0xFF, 0xFF, 0xFF, 3, 0);
    gathrillo::models::Terrain head(11, 5, roty, trans, 1, 78, 0, ang, 80 + x, 67 + y, 0+z, 10, 0xFF, 0xFF, 0xFF, 1, 0);
    gathrillo::models::Terrain armL(11, 5, roty, trans, 1, 78, arm_rotation_L, ang, 70 + x + arm_rotation_L_offset, 70 + y, 0+z, 10, 0xFF, 0xFF, 0xFF, 3, 0);
    gathrillo::models::Terrain armR(11, 5, roty, trans, 1, 78, arm_rotation_R, ang, 90 + x + arm_rotation_R_offset, 70 + y, 0+z, 10, 0xFF, 0xFF, 0xFF, 3, 0);
    gathrillo::models::Terrain LegL(11, 5, roty, trans, 1, 78, 0, ang, 75 + x, 144 + y, 0+z, 10, 0xFF, 0xFF, 0xFF, 4, 0);
    gathrillo::models::Terrain LegR(11, 5, roty, trans, 1, 78, 0, ang, 85 + x, 144 + y, 0+z, 10, 0xFF, 0xFF, 0xFF, 4, 0);



    
     
    //gathrillo::models::Terrain b_0(11, 5, -2, trans, 25, 78, 5, ang, 60-(z*2)+ x, 190+(z*4) + y, 0+z, 10, 0x00, 0xA8, 0x00, 10, 0); 


     
     
    //gathrillo::models::SkyBox Sky(rot, trans, attx,  atty, attz, ang, x, y, z, scale, 0x00, 0x00, 0xAF, id, zbuffer);   

    //gathrillo::models::Terrain oof(rot, trans, attx,  atty, attz, ang, x-40, y, z, scale, r, g, b, id-3, zbuffer);   
    //gathrillo::models::Terrain oof1(rot, trans, attx,  atty, attz, ang, (x+65)-40, y, z, scale, r, g, b, id-3, zbuffer);   
    //gathrillo::models::Terrain oof2(rot, trans, attx,  atty, attz, ang, (x-65)-40, y, z, scale, r, g, b, id-3, zbuffer);   



















































 }
////////////////////////////////////////////////////////////END OF MAPS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
