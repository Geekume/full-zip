#include <drivers/game.h>
#include <gui/window.h>
#include <gui/desktop.h>
#include <drivers/vga.h>
#include <drivers/hopeidontfail.h>



int ava;
int tar;
int poly;
int bloop;
int polyskelx;
int skip;
int skip2;





using namespace gathrillo::common;
using namespace gathrillo::gui;







 Window::Window(Widget* parent, common::uint8_t ang,
            common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h,
            common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t size)
: CompositeWidget(parent, ang, x,y,w,h, r,g,b,size, tri)
{
    screen = true;
    
        
   
}
 Window::~Window()
 {
     
 }
void Window::OnMouseDown(common::int32_t x, common::int32_t y, common::uint8_t button)
{
    screen = button == 1;
    CompositeWidget::OnMouseDown(x,y,button);
}
void Window::OnMouseUp(common::int32_t x, common::int32_t y, common::uint8_t button)
{
    screen = false;
    CompositeWidget::OnMouseUp(x,y,button);
}
void Window::OnMouseMove(common::int32_t oldx, common::int32_t oldy, common::int32_t newx, common::int32_t newy)
{
    if(screen)
    {
        this->x += newx-oldx;
        this->x += newy-oldy;
    }
    CompositeWidget::OnMouseMove(oldx,oldy,newx, newy);
}





ui::ui()
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)


{

gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);

gathrillo::gui::Desktop desktop6(320,200, 0xA8,0x00,0x00);     
/*
gathrillo::gui::Window main(&desktop6, 0, 10, 0 , 20, 10, 0xA8 , 0xA8, 0xA8, 4); 
desktop6.AddChild(&main);    

    
gathrillo::gui::Window itm1(&desktop6, 90, 40, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&itm1);     
    
    
gathrillo::gui::Window itm2(&desktop6, 90, 70, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&itm2);     
    
    
    
gathrillo::gui::Window itm3(&desktop6, 90, 100, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&itm3);     
    
    
    */
gathrillo::gui::Window itm4(&desktop6, 90, 130, 100 , 20, 10, 0xa8 , 0x00, 0x00, 4); 
desktop6.AddChild(&itm4);     
    
    
desktop6.Draw(&vga6);  
    
    
}

ui::~ui(){
    
    
    
    
}




  


 Polygon::Polygon(/*Widget* parent,*/common::uint8_t AnglePos, common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
/*int sizeeigsizet = 0;
size = 1;*/
    
   //size = gathrillo::gui::Widget::z;
  
    
    /*if(tri == 20){
    w = gathrillo::gui::Widget::z - 3;
    y = y + 9 - z;
    x = x + 9 - z;
    }*/
    
    
 
    
    
   pix = pix;
   bloop = 1;
   

    
    
    

         if(gathrillo::gui::Widget::tri == 24) {  
      if(gathrillo::gui::Widget::size == 9) {  
      if(gathrillo::gui::Widget::Angle == 225 && ang == 180 || ang == 270){

          
   if(gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){     
        
       
           
  if(ang == 180) {
        ang = 225; 
        x = x - 0;
        tri = 11;
        w = w / 2;
            
           
             if(gathrillo::gui::Widget::Angle == 135){
                ang = 180;
                tri = 11;
                w = w * 2;
                
            }
            
            
        } 
          
        if(ang == 270 && bloop == 1) {
        ang = 225;  
        tri = 11; 
        x = x + (w);
        w = w / 2;
        bloop = 3;
        }    
         
    
    
  if(gathrillo::gui::Widget::Angle == 270 && ang == 315 && bloop == 3){
     ang = 270;
     tri = 11; 
          
       
      x = x - w*2;  
       
      w = gathrillo::gui::Widget::w;
      bloop = 1;
      
        }       
      }     
   }
}
   
    
  
    if(gathrillo::gui::Widget::Angle == 315 && ang == 270 || ang == 0){

        
   if (gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){   
        
      
          
        if(ang == 0 && bloop == 1) {
        ang = 315;  
        tri = 11; 
        x = x + (w);
        w = w / 2;
        bloop = 3;
            
        
             if(gathrillo::gui::Widget::Angle == 0){
                ang = 0;
                tri = 11;
                w = w * 2;
                //x -= 5;
                  x = x - (w);
                
            }
             if(gathrillo::gui::Widget::Angle == 45){
                ang = 0;
                tri = 11;
                w = w * 2;
                x = x - (w/2);
            }   
            
            

            
            
        }    
         
         if(ang == 315) {
        ang = 315; 
        x = x - 0;
        tri = 11;
        w = w / 2;
    

            
            
        } 
    
    
  if(gathrillo::gui::Widget::Angle == 0 && ang == 315 && bloop == 3){
     ang = 0;
     tri = 11; 
          
       
     // x = x - w*2;  
       
      w = gathrillo::gui::Widget::w;
      bloop = 1;
      
        }       

         
        
        }
    }


    
              
 

    
     
      if(gathrillo::gui::Widget::Angle == 135 && ang == 90 || ang == 180){
       
       
        
          
   if (gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){     
          
        if(ang == 90) {
        ang = 135; 
        x = x - 0;
        tri = 11;
        w = w / 2;
        } 
          
        if(ang == 180 && bloop == 1) {
        ang = 135;  
        tri = 11; 
        x = x + (w);
        w = w / 2;
        bloop = 3;
        }    
         
    
    
  if(gathrillo::gui::Widget::Angle == 180 && ang == 135 && bloop == 3){
     ang = 180;
     tri = 11; 
          
       
      x = x - w*2;  
       
      w = gathrillo::gui::Widget::w;
      bloop = 1;
      
        }   
         
    
          
        

   }
        
}
    
          
          
          if(gathrillo::gui::Widget::Angle == 45 && ang == 0 || ang == 90){
       
       
          
          
   if (gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){     
          
        if(ang == 0) {
        ang = 45;  
            
       x = x - (w/2);
        //.// w = 7;
    
        tri = 11;
        w = w / 2;
      
        } 
          
        if(ang == 90 && bloop == 1) {
        ang = 45;  
        tri = 11; 
          
       
     x = x + (w);  
       
       w = w / 2;
        bloop = 3;
        }    
         
    
    
  if(gathrillo::gui::Widget::Angle == 90 && ang == 45 && bloop == 3){
     ang = 90;
        tri = 11; 
          
       
       x = x - w*2;  
       
       w = gathrillo::gui::Widget::w;
      bloop = 1;
      
        }     
   }
}
    
 
     }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     if(gathrillo::gui::Widget::tri == 3) {   
      if(gathrillo::gui::Widget::Angle == 225 && ang == 180 || ang == 270){

          
   if(gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){     
        
       
           
        if(ang == 180) {
        ang = 225;  
        tri = 4; 
       
             if(gathrillo::gui::Widget::Angle == 135){
                ang = 180;
                tri = 5;
                w = w + 4;
                
            }
       
        x = x + 40;  
       
        w = w + 1;
    
        }
       
       
       
        if(ang == 270) {
        ang = 225;
        x = x + 14;
        tri = 5;
        w = w + 4;
      
         
            
        } 
          
   }
}
   
    
  
    if(gathrillo::gui::Widget::Angle == 315 && ang == 270 || ang == 0){

        
   if (gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){   
        
        
        if(ang == 0) {
        ang = 315;
        tri = 5; 
        x = x + 40;  
        w = w - 4;
    
        
            if(gathrillo::gui::Widget::Angle == 0){
                ang = 0;
                tri = 3;
                w = w + 4;
                x -= 5;
                
            }
             if(gathrillo::gui::Widget::Angle == 45){
                ang = 45;
                tri = 4;
                w = w + 4;
                
            }
        }
        
       
        if(ang == 270) {
        ang = 315;
        x = x + 18;    
        tri = 4;
        w = w + 1;
      
        } 
          
    
 
 if(gathrillo::gui::Widget::Angle == 0 && ang == 45 && bloop == 3){
     ang = 0;
        tri = 3; 
          
       
        x = x - 150;  
       
       w = gathrillo::gui::Widget::w;
      bloop = 1;
      
        }     

         
        
        }
    }


    
              
 

    
     
      if(gathrillo::gui::Widget::Angle == 135 && ang == 90 || ang == 180){
       
       
        
          
   if (gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){     
          
        if(ang == 90) {
        ang = 135;  
            
        x = x + 45;
        //.// w = 7;
    
        tri = 4;
        w = w + 1;
      
        } 
          
        if(ang == 180) {
        ang = 135;  
        tri = 5; 
            
        if(gathrillo::gui::Widget::Angle == 180){
                ang = 180;
                tri = 3;
                w = w + 4;
                x = x - 10;
                
            }    
            
       
        x = x + 49;  
       
        w = w - 4;
        }    
         
    
          
        

   }
        
}
    
          
          
          if(gathrillo::gui::Widget::Angle == 45 && ang == 0 || ang == 90){
       
       
          
          
   if (gathrillo::gui::Widget::ang == gathrillo::gui::Widget::tri == 0){     
          
        if(ang == 0) {
        ang = 45;  
            
        x = x - 25;
        //.// w = 7;
    
        tri = 4;
        w = w + 1;
      
        } 
          
        if(ang == 90 && bloop == 1) {
        ang = 45;  
        tri = 5; 
          
       
        x = x + 54;  
       
        w = w - 4;
        bloop = 3;
        }    
         
    
    
  if(gathrillo::gui::Widget::Angle == 90 && ang == 45 && bloop == 3){
     ang = 90;
        tri = 3; 
          
       
        x = x + - 10;  
       
       w = gathrillo::gui::Widget::w;
      bloop = 1;
      
        }     
   }
}
    
 
     }

    
    
    
    
    
    

     gathrillo::drivers::VideoGraphicsArray vga5;
     vga5.SetMode(0,0,8);
    
     gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 
     
    //size = size - size + 1;
   
    
    
    if(ang == gathrillo::gui::Widget::Angle){

      
    
     if(tri == 3) {    
         
    if (size > 1) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+10, y - 1 , (w*2)-17, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
      
    
    if (size > 2) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+9, y - 2 , (w*2) - 15, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 3) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+8, y - 3 , (w*2) - 13, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 4) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+7, y - 4 , (w*2) - 11, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
          // size = 1;
     if (size > 5) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+6, y - 5 , (w*2) - 9, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 6) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+5, y - 6 , (w*2) -7, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 7) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+4, y - 7 , (w*2) - 5, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 8) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+3, y - 8 , (w*2) - 3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 9) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+2, y - 9 , (w*2) - 1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 10) {
         gathrillo::gui::Window polygon2(&desktop5, ang, x+1, y - 10 , (w*2) + 1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2); 

  //CRAZY BRACKETS
             }
         
            }
           }
          }
         }
        }
       }
      }
     }
    }
  ////////....///  
  
  
  
  
         desktop5.Draw(&vga5);
    
    
        
    
    }

    
    if(tri == 5) {
    
        gathrillo::gui::Window polygon2(&desktop5, ang, x, y , w-5 , h , r, g, b, size); 
     desktop5.AddChild(&polygon2);
        
    if (size > 1) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-1 , w - 4, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
      
    
     if (size > 2) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-2 , w - 3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 3) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-3, w - 2, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 4) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-4 , w-1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
          // size = 1;
     if (size > 5) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-5 , w, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 6) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-6 , w+1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 7) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-7 , w+2, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 8) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-8 , w+3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 9) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-9 , w+4, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 10) {
         gathrillo::gui::Window polygon2(&desktop5, ang, x, y-10 , w+5, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2); 

  //CRAZY BRACKETS
             }
            }
           }
          }
         }
        }
       }
      }
     }
    }
  ////////....///  
         desktop5.Draw(&vga5);
    }
     
    
    if(tri == 4) {
        gathrillo::gui::Window polygon2(&desktop5, ang, x+10, y , w-10, h , r, g, b, size); 
     desktop5.AddChild(&polygon2);
    
    if (size > 1) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+9, y - 1 , w - 9, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
      
    
     if (size > 2) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+8, y - 2 , w - 8, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 3) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+7, y - 3 , w - 7, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 4) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+6, y - 4 , w-6, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
          // size = 1;
     if (size > 5) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+5, y - 5 , w-5, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 6) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+4, y - 6 , w-4, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 7) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+3, y - 7 , w-3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 8) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+2, y - 8 , w-2, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 9) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+1, y - 9 , w-1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 10) {
         gathrillo::gui::Window polygon2(&desktop5, ang, x, y - 10 , w, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2); 

  //CRAZY BRACKETS
             }
            }
           }
          }
         }
        }
       }
      }
     }
    }
  ////////....///  
         desktop5.Draw(&vga5);
    }
    
    
    
    
    
     if(tri == 2) {
    
        gathrillo::gui::Window polygon2(&desktop5, ang, x, y , w+5 , h , r, g, b, size); 
     desktop5.AddChild(&polygon2);
        
    if (size > 1) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-1 , w + 4, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
      
    
     if (size > 2) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-2 , w + 3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 3) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-3, w + 2, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 4) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-4 , w+1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
          // size = 1;
     if (size > 5) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-5 , w, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 6) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-6 , w-1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 7) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-7 , w-2, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 8) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-8 , w-3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 9) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x, y-9 , w-4, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 10) {
         gathrillo::gui::Window polygon2(&desktop5, ang, x, y-10 , w-5, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2); 

  //CRAZY BRACKETS
             }
            }
           }
          }
         }
        }
       }
      }
     }
    }
  ////////....///  
         desktop5.Draw(&vga5);
    }
    
   
        
        
        
         
    if(tri == 10) {
        gathrillo::gui::Window polygon2(&desktop5, ang, x, y , w*4, w*2 , 0xA8, 0x00, 0xA8, 3); 
     desktop5.AddChild(&polygon2);
    
   
    
  ////////....///  
         desktop5.Draw(&vga5);
    } 
        
             
    if(tri == 20) {
        gathrillo::gui::Window polygon2(&desktop5, ang, x, y , w, h , r, g, b, 3); 
     desktop5.AddChild(&polygon2);
    
   
    
  ////////....///  
         desktop5.Draw(&vga5);
    }   
        
       if(tri == 24) {
        gathrillo::gui::Window polygon2(&desktop5, ang, x, y , w*2, w*2 , r, g, b, 3); 
     desktop5.AddChild(&polygon2);
    
   
    
  ////////....///  
         desktop5.Draw(&vga5);
    }     
        
        
        
if(tri == 21) {
        gathrillo::gui::Window polygon2(&desktop5, ang, x, y , w*2, h*2 , r, g, b, 3); 
     desktop5.AddChild(&polygon2);
    
   
    
  ////////....///  
         desktop5.Draw(&vga5);
    }
        
        if(tri == 22) {
    gathrillo::gui::Window polygon2(&desktop5, ang, x +11, y , (w*2 ) - 19 , h , r, g, b, size); 
     desktop5.AddChild(&polygon2);
    
    if (size > 1) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+10, y - 1 , (w*2)-17, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
      
    
     if (size > 2) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+9, y - 2 , (w*2) - 15, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 3) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+8, y - 3 , (w*2) - 13, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 4) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+7, y - 4 , (w*2) - 11, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
          // size = 1;
     if (size > 5) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+6, y - 5 , (w*2) - 9, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 6) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+5, y - 6 , (w*2) -7, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 7) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+4, y - 7 , (w*2) - 5, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 8) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+3, y - 8 , (w*2) - 3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 9) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+2, y - 9 , (w*2) - 1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 10) {
         gathrillo::gui::Window polygon2(&desktop5, ang, x+1, y - 10 , (w*2) + 1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2); 

  //CRAZY BRACKETS
             }
         
            }
           }
          }
         }
        }
       }
      }
     }
    }
  ////////....///  
         desktop5.Draw(&vga5);
    
    
        
    
    }
        
        
        
        
        
        
    
    if(tri == 1) {
        gathrillo::gui::Window polygon2(&desktop5, ang, x, y , w, h , r, g, b, size); 
     desktop5.AddChild(&polygon2);
    
    if (size > 1) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+1, y - 1 , w - 1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
      
    
     if (size > 2) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+2, y - 2 , w - 2, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 3) {
        
     gathrillo::gui::Window polygon2(&desktop5,ang, x+3, y - 3 , w - 3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 4) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+4, y - 4 , w-4, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
          // size = 1;
     if (size > 5) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+5, y - 5 , w-5, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 6) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+6, y - 6 , w-6, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 7) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+7, y - 7 , w-7, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 8) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+8, y - 8 , w-8, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 9) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+9, y - 9 , w-9, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 10) {
         gathrillo::gui::Window polygon2(&desktop5, ang, x+10, y - 10 , w-10, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2); 

  //CRAZY BRACKETS
             }
            }
           }
          }
         }
        }
       }
      }
     }
    }
  ////////....///  
         desktop5.Draw(&vga5);
    }
    
    
     if(tri == 0) {
    gathrillo::gui::Window polygon2(&desktop5, ang, x +1, y , (w*2 ) + 1 , h , r, g, b, size); 
     desktop5.AddChild(&polygon2);
    if (size > 1) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+2, y - 1 , (w*2)-1, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
      
    
     if (size > 2) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+3, y - 2 , (w*2) - 3, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 3) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+4, y - 3 , (w*2) - 5, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
           //size = 1;
     if (size > 4) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+5, y - 4 , (w*2) - 7, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
          // size = 1;
     if (size > 5) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+6, y - 5 , (w*2) - 9, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 6) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+7, y - 6 , (w*2) - 11, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 7) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+8, y - 7 , (w*2) - 13, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 8) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+9, y - 8 , (w*2) - 15, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 9) {
        
     gathrillo::gui::Window polygon2(&desktop5, ang, x+10, y - 9 , (w*2) - 17, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2);
     if (size > 10) {
         gathrillo::gui::Window polygon2(&desktop5, ang, x+1 , y - 10 , (w*2) - 19, 1 , r, g, b, size); 
         desktop5.AddChild(&polygon2); 

  //CRAZY BRACKETS
             }
         
            }
           }
          }
         }
        }
       }
      }
     }
    }
  ////////....///  
         desktop5.Draw(&vga5);
    }

     
     pix += 1;
    
    }
    
    
    
    
 
}

 Polygon::~Polygon()
 {
     
 }
void Polygon::OnMouseDown(common::int32_t x, common::int32_t y, common::uint8_t button)
{
    screen = button == 1;
    CompositeWidget::OnMouseDown(x,y,button);
}
void Polygon::OnMouseUp(common::int32_t x, common::int32_t y, common::uint8_t button)
{
    screen = false;
    CompositeWidget::OnMouseUp(x,y,button);
}
void Polygon::OnMouseMove(common::int32_t oldx, common::int32_t oldy, common::int32_t newx, common::int32_t newy)
{
    if(screen)
    {
        this->x += newx-oldx;
        this->x += newy-oldy;
    }
    CompositeWidget::OnMouseMove(oldx,oldy,newx, newy);
}


Tetrahedron::Tetrahedron(/*Widget* parent,*/common::uint8_t AnglePos,  common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
/*int sizeeigsizet = 0;
size = 1;*/
    
      
    if(AnglePos == gathrillo::gui::Widget::Angle){
    
   
       gathrillo::gui::Polygon poly41(270,0, 9, 3, x-15, y, 9, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon poly52(270,90, 9, 3, x-20, y, 9, h, 0xA8, 0x00, 0xA8);
       gathrillo::gui::Polygon poly53(270,180, 9, 3, x-14, y, 9, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon poly54(270,270, 9, 3, x+25, y, 9, h, 0x00, 0x00, 0xAF);
    
    }
}

  Tetrahedron::~Tetrahedron()
 {
     
 }


Tetrahedron_m::Tetrahedron_m(/*Widget* parent,*/common::uint8_t AnglePos,  common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
/*int sizeeigsizet = 0;
size = 1;*/
    
      
    
   
    
    if(AnglePos == gathrillo::gui::Widget::Angle){

 
        
        
       gathrillo::gui::Polygon A2(180,0, 9, 22, x+24, y, 9, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon B2(180,45, 9, 22, x+24, y, 9, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon C2(180,90, 9, 22, x+24, y, 9, h, 0xA8, 0x00, 0xA8);
       gathrillo::gui::Polygon D2(180,135, 9, 22, x+24, y, 9, h, 0xA8, 0x00, 0xA8);
       gathrillo::gui::Polygon E2(180,180, 9, 22, x+24, y, 9, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon F2(180,225, 9, 22, x+24, y, 9, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon G2(180,270, 9, 22, x+24, y, 9, h, 0x00, 0x00, 0xAF);
       gathrillo::gui::Polygon H2(180,315, 9, 22, x+24, y, 9, h, 0x00, 0x00, 0xAF);

    }
 
}

  Tetrahedron_m::~Tetrahedron_m()
 {
     
 }


Cube::Cube(/*Widget* parent,*/common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
/*int sizeeigsizet = 0;
size = 1;*/
       if(AnglePos == gathrillo::gui::Widget::Angle){
       gathrillo::gui::Polygon a1(90, 90, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon b1(90, 135, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon c1(90, 0, 9, 20, x, y, w, h, 0xA8, 0x00, 0xA8);
       gathrillo::gui::Polygon d1(90, 45, 9, 20, x, y, w, h, 0xA8, 0x00, 0xA8);
       gathrillo::gui::Polygon e1(90, 270, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon f1(90, 315, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon g1(90, 180, 9, 20, x, y, w, h, 0x00, 0x00, 0xA8);
       gathrillo::gui::Polygon h1(90, 225, 9, 20, x, y, w, h, 0x00, 0x00, 0xA8);
    }
}
Cube::~Cube()
 {
     
 }

vertex::vertex(common::uint8_t AnglePos, common::int32_t x, common::int32_t y,common::int32_t z, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
    
    
    

     gathrillo::drivers::VideoGraphicsArray vga5;
     vga5.SetMode(0,0,8);
    
     gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 
    
    gathrillo::gui::Window vertex(&desktop5, ang, x, y , 1, 1 , r, g, b, size); 
         desktop5.AddChild(&vertex);
     
    desktop5.Draw(&vga5);

    
}

vertex::~vertex()
 {
     
 }

Cube_m::Cube_m(/*Widget* parent,*/common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
/*int sizeeigsizet = 0;
size = 1;*/
    
    if(ang == 90 || ang == 270) {
    
    gathrillo::gui::Widget::z1 = 0;
    
    
    
}

    
if(AnglePos == gathrillo::gui::Widget::Angle){
    
    
    
    

       gathrillo::gui::Polygon a1(90, 90, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon b1(90, 135, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon c1(90, 0, 9, 20, x, y, w, h, 0xA8, 0x00, 0xA8);
       gathrillo::gui::Polygon d1(90, 45, 9, 20, x, y, w, h, 0xA8, 0x00, 0xA8);
       gathrillo::gui::Polygon e1(90, 270, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon f1(90, 315, 9, 20, x, y, w, h, 0xFE, 0xFE, 0xFE);
       gathrillo::gui::Polygon g1(90, 180, 9, 20, x, y, w, h, 0x00, 0x00, 0xA8);
       gathrillo::gui::Polygon h1(90, 225, 9, 20, x, y, w, h, 0x00, 0x00, 0xA8);
       }
 
}
  Cube_m::~Cube_m()
 {
     
 }





Dline::Dline(/*Widget* parent,*/common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{
/*int sizeeigsizet = 0;
size = 1;*/
    
    if(ang == 90 || ang == 270) {
    
    gathrillo::gui::Widget::z1 = 0;
    
    
    
}

    
if(AnglePos == gathrillo::gui::Widget::Angle){
    
    
    
  
    
    
    if(size == 1) {
    
     if(h > 0) {

       gathrillo::gui::Polygon a1(90, 90, 9, 20, x, y, 1, 1, r, g, b);
       
     if(h >1) {
       gathrillo::gui::Polygon a2(90, 90, 9, 20, x+1, y+1, 1, 1, r, g, b);

     if(h >2) {
       gathrillo::gui::Polygon a3(90, 90, 9, 20, x+2, y+2, 1, 1, r, g, b);

     if(h >3) {
       gathrillo::gui::Polygon a4(90, 90, 9, 20, x+3, y+3, 1, 1, r, g, b);

     if(h >4) {

       gathrillo::gui::Polygon a5(90, 90, 9, 20, x+4, y+4, 1, 1, r, g, b);
       
     if(h >5) {
       gathrillo::gui::Polygon a6(90, 90, 9, 20, x+5, y+5, 1, 1, r, g, b);

     if(h >6) {
       gathrillo::gui::Polygon a7(90, 90, 9, 20, x+6, y+6, 1, 1, r, g, b);

     if(h >7) {
       gathrillo::gui::Polygon a8(90, 90, 9, 20, x+7, y+7, 1, 1, r, g, b);
         
     if(h >8) {

       gathrillo::gui::Polygon a9(90, 90, 9, 20, x+8, y+8, 1, 1, r, g, b);
       
     if(h >9) {
       gathrillo::gui::Polygon a10(90, 90, 9, 20, x+9, y+9, 1, 1, r, g, b);

     if(h >10) {
       gathrillo::gui::Polygon a11(90, 90, 9, 20, x+10, y+10, 1, 1, r, g, b);

     if(h >11) {
       gathrillo::gui::Polygon a12(90, 90, 9, 20, x+11, y+11, 1, 1, r, g, b);
        
         
     if(h >12) {

       gathrillo::gui::Polygon a13(90, 90, 9, 20, x+12, y+12, 1, 1, r, g, b);
       
     if(h >13) {
       gathrillo::gui::Polygon a14(90, 90, 9, 20, x+13, y+13, 1, 1, r, g, b);

     if(h >14) {
       gathrillo::gui::Polygon a15(90, 90, 9, 20, x+14, y+14, 1, 1, r, g, b);

     if(h >15) {
       gathrillo::gui::Polygon a16(90, 90, 9, 20, x+15, y+15, 1, 1, r, g, b);
         
     if(h >16) {

       gathrillo::gui::Polygon a17(90, 90, 9, 20, x+16, y+16, 1, 1, r, g, b);
       
     if(h >17) {
       gathrillo::gui::Polygon a18(90, 90, 9, 20, x+17, y+17, 1, 1, r, g, b);

     if(h >18) {
       gathrillo::gui::Polygon a19(90, 90, 9, 20, x+18, y+18, 1, 1, r, g, b);

     if(h >19) {
       gathrillo::gui::Polygon a20(90, 90, 9, 20, x+19, y+19, 1, 1, r, g, b);
         
         
     if(h > 20) {

       gathrillo::gui::Polygon a21(90, 90, 9, 20, x+20, y+20, 1, 1, r, g, b);
       
     if(h >21) {
       gathrillo::gui::Polygon a22(90, 90, 9, 20, x+21, y+21, 1, 1, r, g, b);

     if(h >22) {
       gathrillo::gui::Polygon a23(90, 90, 9, 20, x+22, y+22, 1, 1, r, g, b);

     if(h >23) {
       gathrillo::gui::Polygon a24(90, 90, 9, 20, x+23, y+23, 1, 1, r, g, b);

     if(h >24) {

       gathrillo::gui::Polygon a25(90, 90, 9, 20, x+24, y+24, 1, 1, r, g, b);
       
     if(h >25) {
       gathrillo::gui::Polygon a26(90, 90, 9, 20, x+25, y+25, 1, 1, r, g, b);

     if(h >26) {
       gathrillo::gui::Polygon a27(90, 90, 9, 20, x+26, y+26, 1, 1, r, g, b);

     if(h >27) {
       gathrillo::gui::Polygon a28(90, 90, 9, 20, x+27, y+27, 1, 1, r, g, b);
         
     if(h >28) {

       gathrillo::gui::Polygon a29(90, 90, 9, 20, x+28, y+28, 1, 1, r, g, b);
       
     if(h >29) {
       gathrillo::gui::Polygon a30(90, 90, 9, 20, x+29, y+29, 1, 1, r, g, b);

     if(h >30) {
       gathrillo::gui::Polygon a31(90, 90, 9, 20, x+30, y+30, 1, 1, r, g, b);

     if(h >31) {
       gathrillo::gui::Polygon a32(90, 90, 9, 20, x+31, y+31, 1, 1, r, g, b);
        
         
     if(h >32) {

       gathrillo::gui::Polygon a33(90, 90, 9, 20, x+32, y+32, 1, 1, r, g, b);
       
     if(h >33) {
       gathrillo::gui::Polygon a34(90, 90, 9, 20, x+33, y+33, 1, 1, r, g, b);

     if(h >34) {
       gathrillo::gui::Polygon a35(90, 90, 9, 20, x+34, y+34, 1, 1, r, g, b);

     if(h >35) {
       gathrillo::gui::Polygon a36(90, 90, 9, 20, x+35, y+35, 1, 1, r, g, b);
         
     if(h >36) {

       gathrillo::gui::Polygon a37(90, 90, 9, 20, x+36, y+36, 1, 1, r, g, b);
       
     if(h >37) {
       gathrillo::gui::Polygon a38(90, 90, 9, 20, x+37, y+37, 1, 1, r, g, b);

     if(h >38) {
       gathrillo::gui::Polygon a39(90, 90, 9, 20, x+38, y+38, 1, 1, r, g, b);

     if(h >39) {
       gathrillo::gui::Polygon a40(90, 90, 9, 20, x+39, y+39, 1, 1, r, g, b);
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
         
         
         
         
}
     
    
    
    
    
    
 if(size == 2) {
    
     if(h > 0) {

       gathrillo::gui::Polygon a1(90, 90, 9, 20, x, y, 1, 1, r, g, b);
       
     if(h >1) {
       gathrillo::gui::Polygon a2(90, 90, 9, 20, x-1, y-1, 1, 1, r, g, b);

     if(h >2) {
       gathrillo::gui::Polygon a3(90, 90, 9, 20, x-2, y-2, 1, 1, r, g, b);

     if(h >3) {
       gathrillo::gui::Polygon a4(90, 90, 9, 20, x-3, y-3, 1, 1, r, g, b);

     if(h >4) {

       gathrillo::gui::Polygon a5(90, 90, 9, 20, x-4, y-4, 1, 1, r, g, b);
       
     if(h >5) {
       gathrillo::gui::Polygon a6(90, 90, 9, 20, x-5, y-5, 1, 1, r, g, b);

     if(h >6) {
       gathrillo::gui::Polygon a7(90, 90, 9, 20, x-6, y-6, 1, 1, r, g, b);

     if(h >7) {
       gathrillo::gui::Polygon a8(90, 90, 9, 20, x-7, y-7, 1, 1, r, g, b);
         
     if(h >8) {

       gathrillo::gui::Polygon a9(90, 90, 9, 20, x-8, y-8, 1, 1, r, g, b);
       
     if(h >9) {
       gathrillo::gui::Polygon a10(90, 90, 9, 20, x-9, y-9, 1, 1, r, g, b);

     if(h >10) {
       gathrillo::gui::Polygon a11(90, 90, 9, 20, x-10, y-10, 1, 1, r, g, b);

     if(h >11) {
       gathrillo::gui::Polygon a12(90, 90, 9, 20, x-11, y-11, 1, 1, r, g, b);
        
         
     if(h >12) {

       gathrillo::gui::Polygon a13(90, 90, 9, 20, x-12, y-12, 1, 1, r, g, b);
       
     if(h >13) {
       gathrillo::gui::Polygon a14(90, 90, 9, 20, x-13, y-13, 1, 1, r, g, b);

     if(h >14) {
       gathrillo::gui::Polygon a15(90, 90, 9, 20, x-14, y-14, 1, 1, r, g, b);

     if(h >15) {
       gathrillo::gui::Polygon a16(90, 90, 9, 20, x-15, y-15, 1, 1, r, g, b);
         
     if(h >16) {

       gathrillo::gui::Polygon a17(90, 90, 9, 20, x-16, y-16, 1, 1, r, g, b);
       
     if(h >17) {
       gathrillo::gui::Polygon a18(90, 90, 9, 20, x-17, y-17, 1, 1, r, g, b);

     if(h >18) {
       gathrillo::gui::Polygon a19(90, 90, 9, 20, x-18, y-18, 1, 1, r, g, b);

     if(h >19) {
       gathrillo::gui::Polygon a20(90, 90, 9, 20, x-19, y-19, 1, 1, r, g, b);
         
         
     if(h > 20) {

       gathrillo::gui::Polygon a21(90, 90, 9, 20, x-20, y-20, 1, 1, r, g, b);
       
     if(h >21) {
       gathrillo::gui::Polygon a22(90, 90, 9, 20, x-21, y-21, 1, 1, r, g, b);

     if(h >22) {
       gathrillo::gui::Polygon a23(90, 90, 9, 20, x-22, y-22, 1, 1, r, g, b);

     if(h >23) {
       gathrillo::gui::Polygon a24(90, 90, 9, 20, x-23, y-23, 1, 1, r, g, b);

     if(h >24) {

       gathrillo::gui::Polygon a25(90, 90, 9, 20, x-24, y-24, 1, 1, r, g, b);
       
     if(h >25) {
       gathrillo::gui::Polygon a26(90, 90, 9, 20, x-25, y-25, 1, 1, r, g, b);

     if(h >26) {
       gathrillo::gui::Polygon a27(90, 90, 9, 20, x-26, y-26, 1, 1, r, g, b);

     if(h >27) {
       gathrillo::gui::Polygon a28(90, 90, 9, 20, x-27, y-27, 1, 1, r, g, b);
         
     if(h >28) {

       gathrillo::gui::Polygon a29(90, 90, 9, 20, x-28, y-28, 1, 1, r, g, b);
       
     if(h >29) {
       gathrillo::gui::Polygon a30(90, 90, 9, 20, x-29, y-29, 1, 1, r, g, b);

     if(h >30) {
       gathrillo::gui::Polygon a31(90, 90, 9, 20, x-30, y-30, 1, 1, r, g, b);

     if(h >31) {
       gathrillo::gui::Polygon a32(90, 90, 9, 20, x-31, y-31, 1, 1, r, g, b);
        
         
     if(h >32) {

       gathrillo::gui::Polygon a33(90, 90, 9, 20, x-32, y-32, 1, 1, r, g, b);
       
     if(h >33) {
       gathrillo::gui::Polygon a34(90, 90, 9, 20, x-33, y-33, 1, 1, r, g, b);

     if(h >34) {
       gathrillo::gui::Polygon a35(90, 90, 9, 20, x-34, y-34, 1, 1, r, g, b);

     if(h >35) {
       gathrillo::gui::Polygon a36(90, 90, 9, 20, x-35, y-35, 1, 1, r, g, b);
         
     if(h >36) {

       gathrillo::gui::Polygon a37(90, 90, 9, 20, x-36, y-36, 1, 1, r, g, b);
       
     if(h >37) {
       gathrillo::gui::Polygon a38(90, 90, 9, 20, x-37, y-37, 1, 1, r, g, b);

     if(h >38) {
       gathrillo::gui::Polygon a39(90, 90, 9, 20, x-38, y-38, 1, 1, r, g, b);

     if(h >39) {
       gathrillo::gui::Polygon a40(90, 90, 9, 20, x-39, y-39, 1, 1, r, g, b);
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
         
         
         
         
}
         
    
    
    
   if(size == 3) {
    
     if(h > 0) {

       gathrillo::gui::Polygon a1(90, 90, 9, 20, x, y, 1, 1, r, g, b);
       
     if(h >1) {
       gathrillo::gui::Polygon a2(90, 90, 9, 20, x-1, y+1, 1, 1, r, g, b);

     if(h >2) {
       gathrillo::gui::Polygon a3(90, 90, 9, 20, x-2, y+2, 1, 1, r, g, b);

     if(h >3) {
       gathrillo::gui::Polygon a4(90, 90, 9, 20, x-3, y+3, 1, 1, r, g, b);

     if(h >4) {

       gathrillo::gui::Polygon a5(90, 90, 9, 20, x-4, y+4, 1, 1, r, g, b);
       
     if(h >5) {
       gathrillo::gui::Polygon a6(90, 90, 9, 20, x-5, y+5, 1, 1, r, g, b);

     if(h >6) {
       gathrillo::gui::Polygon a7(90, 90, 9, 20, x-6, y+6, 1, 1, r, g, b);

     if(h >7) {
       gathrillo::gui::Polygon a8(90, 90, 9, 20, x-7, y+7, 1, 1, r, g, b);
         
     if(h >8) {

       gathrillo::gui::Polygon a9(90, 90, 9, 20, x-8, y+8, 1, 1, r, g, b);
       
     if(h >9) {
       gathrillo::gui::Polygon a10(90, 90, 9, 20, x-9, y+9, 1, 1, r, g, b);

     if(h >10) {
       gathrillo::gui::Polygon a11(90, 90, 9, 20, x-10, y+10, 1, 1, r, g, b);

     if(h >11) {
       gathrillo::gui::Polygon a12(90, 90, 9, 20, x-11, y+11, 1, 1, r, g, b);
        
         
     if(h >12) {

       gathrillo::gui::Polygon a13(90, 90, 9, 20, x-12, y+12, 1, 1, r, g, b);
       
     if(h >13) {
       gathrillo::gui::Polygon a14(90, 90, 9, 20, x-13, y+13, 1, 1, r, g, b);

     if(h >14) {
       gathrillo::gui::Polygon a15(90, 90, 9, 20, x-14, y+14, 1, 1, r, g, b);

     if(h >15) {
       gathrillo::gui::Polygon a16(90, 90, 9, 20, x-15, y+15, 1, 1, r, g, b);
         
     if(h >16) {

       gathrillo::gui::Polygon a17(90, 90, 9, 20, x-16, y+16, 1, 1, r, g, b);
       
     if(h >17) {
       gathrillo::gui::Polygon a18(90, 90, 9, 20, x-17, y+17, 1, 1, r, g, b);

     if(h >18) {
       gathrillo::gui::Polygon a19(90, 90, 9, 20, x-18, y+18, 1, 1, r, g, b);

     if(h >19) {
       gathrillo::gui::Polygon a20(90, 90, 9, 20, x-19, y+19, 1, 1, r, g, b);
         
         
     if(h > 20) {

       gathrillo::gui::Polygon a21(90, 90, 9, 20, x-20, y+20, 1, 1, r, g, b);
       
     if(h >21) {
       gathrillo::gui::Polygon a22(90, 90, 9, 20, x-21, y+21, 1, 1, r, g, b);

     if(h >22) {
       gathrillo::gui::Polygon a23(90, 90, 9, 20, x-22, y+22, 1, 1, r, g, b);

     if(h >23) {
       gathrillo::gui::Polygon a24(90, 90, 9, 20, x-23, y+23, 1, 1, r, g, b);

     if(h >24) {

       gathrillo::gui::Polygon a25(90, 90, 9, 20, x-24, y+24, 1, 1, r, g, b);
       
     if(h >25) {
       gathrillo::gui::Polygon a26(90, 90, 9, 20, x-25, y+25, 1, 1, r, g, b);

     if(h >26) {
       gathrillo::gui::Polygon a27(90, 90, 9, 20, x-26, y+26, 1, 1, r, g, b);

     if(h >27) {
       gathrillo::gui::Polygon a28(90, 90, 9, 20, x-27, y+27, 1, 1, r, g, b);
         
     if(h >28) {

       gathrillo::gui::Polygon a29(90, 90, 9, 20, x-28, y+28, 1, 1, r, g, b);
       
     if(h >29) {
       gathrillo::gui::Polygon a30(90, 90, 9, 20, x-29, y+29, 1, 1, r, g, b);

     if(h >30) {
       gathrillo::gui::Polygon a31(90, 90, 9, 20, x-30, y+30, 1, 1, r, g, b);

     if(h >31) {
       gathrillo::gui::Polygon a32(90, 90, 9, 20, x-31, y+31, 1, 1, r, g, b);
        
         
     if(h >32) {

       gathrillo::gui::Polygon a33(90, 90, 9, 20, x-32, y+32, 1, 1, r, g, b);
       
     if(h >33) {
       gathrillo::gui::Polygon a34(90, 90, 9, 20, x-33, y+33, 1, 1, r, g, b);

     if(h >34) {
       gathrillo::gui::Polygon a35(90, 90, 9, 20, x-34, y+34, 1, 1, r, g, b);

     if(h >35) {
       gathrillo::gui::Polygon a36(90, 90, 9, 20, x-35, y+35, 1, 1, r, g, b);
         
     if(h >36) {

       gathrillo::gui::Polygon a37(90, 90, 9, 20, x-36, y+36, 1, 1, r, g, b);
       
     if(h >37) {
       gathrillo::gui::Polygon a38(90, 90, 9, 20, x-37, y+37, 1, 1, r, g, b);

     if(h >38) {
       gathrillo::gui::Polygon a39(90, 90, 9, 20, x-38, y+38, 1, 1, r, g, b);

     if(h >39) {
       gathrillo::gui::Polygon a40(90, 90, 9, 20, x-39, y+39, 1, 1, r, g, b);
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
         
         
         
         
}
     
    
    
    
    
    
 if(size == 4) {
    
     if(h > 0) {

       gathrillo::gui::Polygon a1(90, 90, 9, 20, x, y, 1, 1, r, g, b);
       
     if(h >1) {
       gathrillo::gui::Polygon a2(90, 90, 9, 20, x-1, y-1, 1, 1, r, g, b);

     if(h >2) {
       gathrillo::gui::Polygon a3(90, 90, 9, 20, x-2, y-2, 1, 1, r, g, b);

     if(h >3) {
       gathrillo::gui::Polygon a4(90, 90, 9, 20, x-3, y-3, 1, 1, r, g, b);

     if(h >4) {

       gathrillo::gui::Polygon a5(90, 90, 9, 20, x-4, y-4, 1, 1, r, g, b);
       
     if(h >5) {
       gathrillo::gui::Polygon a6(90, 90, 9, 20, x-5, y-5, 1, 1, r, g, b);

     if(h >6) {
       gathrillo::gui::Polygon a7(90, 90, 9, 20, x-6, y-6, 1, 1, r, g, b);

     if(h >7) {
       gathrillo::gui::Polygon a8(90, 90, 9, 20, x-7, y-7, 1, 1, r, g, b);
         
     if(h >8) {

       gathrillo::gui::Polygon a9(90, 90, 9, 20, x-8, y-8, 1, 1, r, g, b);
       
     if(h >9) {
       gathrillo::gui::Polygon a10(90, 90, 9, 20, x-9, y-9, 1, 1, r, g, b);

     if(h >10) {
       gathrillo::gui::Polygon a11(90, 90, 9, 20, x-10, y-10, 1, 1, r, g, b);

     if(h >11) {
       gathrillo::gui::Polygon a12(90, 90, 9, 20, x-11, y-11, 1, 1, r, g, b);
        
         
     if(h >12) {

       gathrillo::gui::Polygon a13(90, 90, 9, 20, x-12, y-12, 1, 1, r, g, b);
       
     if(h >13) {
       gathrillo::gui::Polygon a14(90, 90, 9, 20, x-13, y-13, 1, 1, r, g, b);

     if(h >14) {
       gathrillo::gui::Polygon a15(90, 90, 9, 20, x-14, y-14, 1, 1, r, g, b);

     if(h >15) {
       gathrillo::gui::Polygon a16(90, 90, 9, 20, x-15, y-15, 1, 1, r, g, b);
         
     if(h >16) {

       gathrillo::gui::Polygon a17(90, 90, 9, 20, x-16, y-16, 1, 1, r, g, b);
       
     if(h >17) {
       gathrillo::gui::Polygon a18(90, 90, 9, 20, x-17, y-17, 1, 1, r, g, b);

     if(h >18) {
       gathrillo::gui::Polygon a19(90, 90, 9, 20, x-18, y-18, 1, 1, r, g, b);

     if(h >19) {
       gathrillo::gui::Polygon a20(90, 90, 9, 20, x-19, y-19, 1, 1, r, g, b);
         
         
     if(h > 20) {

       gathrillo::gui::Polygon a21(90, 90, 9, 20, x-20, y-20, 1, 1, r, g, b);
       
     if(h >21) {
       gathrillo::gui::Polygon a22(90, 90, 9, 20, x-21, y-21, 1, 1, r, g, b);

     if(h >22) {
       gathrillo::gui::Polygon a23(90, 90, 9, 20, x-22, y-22, 1, 1, r, g, b);

     if(h >23) {
       gathrillo::gui::Polygon a24(90, 90, 9, 20, x-23, y-23, 1, 1, r, g, b);

     if(h >24) {

       gathrillo::gui::Polygon a25(90, 90, 9, 20, x-24, y-24, 1, 1, r, g, b);
       
     if(h >25) {
       gathrillo::gui::Polygon a26(90, 90, 9, 20, x-25, y-25, 1, 1, r, g, b);

     if(h >26) {
       gathrillo::gui::Polygon a27(90, 90, 9, 20, x-26, y-26, 1, 1, r, g, b);

     if(h >27) {
       gathrillo::gui::Polygon a28(90, 90, 9, 20, x-27, y-27, 1, 1, r, g, b);
         
     if(h >28) {

       gathrillo::gui::Polygon a29(90, 90, 9, 20, x-28, y-28, 1, 1, r, g, b);
       
     if(h >29) {
       gathrillo::gui::Polygon a30(90, 90, 9, 20, x-29, y-29, 1, 1, r, g, b);

     if(h >30) {
       gathrillo::gui::Polygon a31(90, 90, 9, 20, x-30, y-30, 1, 1, r, g, b);

     if(h >31) {
       gathrillo::gui::Polygon a32(90, 90, 9, 20, x-31, y-31, 1, 1, r, g, b);
        
         
     if(h >32) {

       gathrillo::gui::Polygon a33(90, 90, 9, 20, x-32, y-32, 1, 1, r, g, b);
       
     if(h >33) {
       gathrillo::gui::Polygon a34(90, 90, 9, 20, x-33, y-33, 1, 1, r, g, b);

     if(h >34) {
       gathrillo::gui::Polygon a35(90, 90, 9, 20, x-34, y-34, 1, 1, r, g, b);

     if(h >35) {
       gathrillo::gui::Polygon a36(90, 90, 9, 20, x-35, y-35, 1, 1, r, g, b);
         
     if(h >36) {

       gathrillo::gui::Polygon a37(90, 90, 9, 20, x-36, y-36, 1, 1, r, g, b);
       
     if(h >37) {
       gathrillo::gui::Polygon a38(90, 90, 9, 20, x-37, y-37, 1, 1, r, g, b);

     if(h >38) {
       gathrillo::gui::Polygon a39(90, 90, 9, 20, x-38, y-38, 1, 1, r, g, b);

     if(h >39) {
       gathrillo::gui::Polygon a40(90, 90, 9, 20, x-39, y-39, 1, 1, r, g, b);
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
     }
         
      
         
}
         
   if(size == 10){
       
       //polyskelx = x -
       
       
      gathrillo::gui::Polygon oof(90, 90, 9, 3, x-47, y+6, w, 3, r, g, b); 
       
    if(w > 9) {
        w = 9;
        
    }
    
   }                
     
     if(size == 11){
       
       //polyskelx = x -
       
       
      gathrillo::gui::Polygon oof1(90, 90, 9, 20, x-2, y, w, h, r, g, b); 
       
   
        
    }
   if(size == 5) {
        
        gathrillo::gui::Polygon oof(90, 90, 9, 20, x, y, w, h+1, r, g, b);
        
    } 
     if(size == 6) {
        
        gathrillo::gui::Polygon oof(90, 90, 9, 20, x, y, h, w, r, g, b);
        
    }
    if(size == 7) {
        
        gathrillo::gui::Polygon oof(90, 90, 9, 20, x-h, y, h+1, w, r, g, b);
        
    }
    
         
       }
 
}
  Dline::~Dline()
 {
     
 }





Skelekton::Skelekton(common::uint8_t arm_rot, common::uint8_t forearm_rot1,
                common::uint8_t forearm_rot2,
                common::uint8_t leg_rot, common::uint8_t quad_rot1,
                common::uint8_t quad_rot2, common::uint8_t spine1_rot, common::uint8_t spine2_rot, common::uint8_t head_rot, common::uint8_t head_size, common::uint8_t spine_size, common::uint8_t arm_size, common::uint8_t forearm_size1,
                common::uint8_t forearm_size2,
                common::uint8_t spine2_size, common::uint8_t leg_size, common::uint8_t quad_size1, 
                common::uint8_t quad_size2, 
                common::uint8_t foot_size, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)


{
    
    // Polygon reference  ang, size,  tri,  x,  y,  w,  h,  r,  g, b 
    
    
     
    skip2 = size;
    
    int oof1x;
    int oof2x;
    int oof3x;
    int oof4x;
    int oof5x;
    int oof6x;
    int oof7x;
    int oof8x;
    int oof1y;
    int oof2y;
    int oof3y;
    int oof4y;
    int oof5y;
    int oof6y;
    int oof7y;
    int oof8y;
    //color-change
    int cc1;
    int cc2;
    int cc3;
    int cc4;
    int cc5;
    int cc6;
    int cc7;
    int cc8;
   
    int oof;
    int oof2;
    int oof3;
    int oof4;
    int oof5;
    int oof6;
    int oof7;
    int oof8;
    int oof9;
    int oof10;
    int oof11;
    int oof12;
    int oof13;
    int oof14;
    int oof15;
    int oof16;

   int oof1yb;
   int oof2yb;
   int oof3yb;
   int oof4yb;
   int oof5yb;
   int oof6yb;
   int oof7yb;
   int oof8yb;
    
   int fore1;
   int fore2;
   int quad1b;
   int quad2b;
 
   
   
    
    cc1 = 0xAF;
    cc2 = 0xAF;
    cc3 = 0xAF;
    cc4 = 0xAF;
    cc5 = 0xAF;
    cc6 = 0xAF;
    cc7 = 0xA1;
    cc8 = 0xA1;
    
    
    oof = 0;  
    oof2 = 0;
    oof3 = 0;
    oof4 = 0;
    oof5 = 0;
    oof6 = 0;
    oof7 = 0;
    oof8 = 0;
    oof9 = 0;
    oof10 = 0;
    oof11 = 0;
    oof12 = 0;
    oof13 = 0;
    oof14  = 0;
    oof15 = 0;
    oof16 = 0;
         
  oof1yb = 0;
  oof2yb = 0;
  oof3yb = 0;
  oof4yb = 0;
  oof5yb = 0;
  oof6yb = 0;
  oof7yb = 0;
  oof8yb = 0;
    
fore1 = 0;
fore2 = 0;
    
quad1b = 0;
quad2b = 0;
    
    
    
     if(forearm_rot1 == 0) {

    //oof7yb =  (size - 3 )/2 - 1;
         
    //oof8yb =  (size - 3 )/2 - 1;
    }
      
      if(forearm_rot1 == 30) {
        
      oof = (size - 2 )/2; 
      
      forearm_size1 = forearm_size1*(3/4);
       
    oof3yb =  (size - 3 )/2;
    oof5yb =  (size - 3 )/2;
    oof8yb =  (size - 3 )/2 + 2;
    fore1 = size;  
          
          
    }
   
      if(forearm_rot1 == 60) {
        
      oof = (size - 2 )/2; 
      oof3 = (size - 2 )/2; 
          
    forearm_size1 = forearm_size1*(1/2) ;
          
    oof5yb =  (size - 3 ) -2;
    oof8yb =  (size - 3 ) ;
          
    fore1 = size;  
        
    }
      if(forearm_rot1 == 90) {
        
          
      oof = (size - 2 )/2; 
      oof3 = (size - 2 )/2; 
      oof5 = (size - 2 )/2; 
          
          
    fore1 = size;      
          
          
   forearm_size1 /= 2;
          
   
    oof8yb =  (size - 3 ) + size -5;
          
          
          
      
    }
      if(forearm_rot1 == 120) {
        
        
        
    }
      if(forearm_rot1 == 150) {
        
        
        
    }
      if(forearm_rot1 == 180) {
        
        
        
    }
    
     if(quad_rot1 == 0) {

    //oof7yb =  (size - 3 )/2 - 1;
         
    //oof8yb =  (size - 3 )/2 - 1;
    }
      
      if(quad_rot1 == 30) {
        
      oof = (size - 2 )/2; 
      
      quad_size1 = quad_size1;
     
    quad1b = (size/3);  
          
          
    }
   
      if(quad_rot1 == 60) {
        
      
          
    quad_size1 = quad_size1;
          
    
          
    quad1b = size/2;  
        
    }
      if(quad_rot1 == 90) {
        
          
      
          
          
    quad1b = size;      
          
          
   quad_size1 = quad_size1;
          
   
   
          
          
          
      
    }
      if(quad_rot1 == 120) {
        
        
        
    }
      if(quad_rot1 == 150) {
        
        
        
    }
      if(quad_rot1 == 180) {
        
        
        
    }
    
    
       
     if(quad_rot2 == 0) {

    //oof7yb =  (size - 3 )/2 - 1;
         
    //oof8yb =  (size - 3 )/2 - 1;
    }
      
      if(quad_rot2 == 30) {
        
     
      
      quad_size2 = quad_size2;
   
    quad2b = (size/3);  
          
          
    }
   
      if(quad_rot2 == 60) {
        
      
    quad_size2 = quad_size2;
       
          
    quad2b = size/2;  
        
    }
      if(quad_rot2 == 90) {
        
       
          
    quad2b = size;      
          
          
   quad_size2 = quad_size2;
          
   
          
          
          
      
    }
    
    
     if(forearm_rot2 == 0) {

    //oof7yb =  (size - 3 )/2 - 1;
    //oof8yb =  (size - 3 )/2 - 1;
         
    }
      
      if(forearm_rot2 == 30) {
        
      oof2 = (size - 2 )/2;
      
      forearm_size2 = forearm_size2*(3/4);
       
    oof4yb =  (size - 3 )/2;
    oof6yb =  (size - 3 )/2;
    oof7yb =  (size - 3 )/2 + 2;
    fore2 = size;  
          
          
    }
   
      if(forearm_rot2 == 60) {
        
      oof2 = (size - 2 )/2;
      oof4 = (size - 2 )/2;
          
     forearm_size2 = forearm_size2*(1/2) ;
          
    oof6yb =  (size - 3 ) -2;
    oof7yb =  (size - 3 ) ;
          
    fore2 = size;  
        
    }
      if(forearm_rot2 == 90) {
        
          
      oof2 = (size - 2 )/2;
      oof4 = (size - 2 )/2;  
      oof6 = (size - 2 )/2;
          
          
    fore2 = size;      
          
          
    forearm_size2 /= 2;
          
   
    oof7yb =  (size - 3 ) + size -5;
          
          
          
      
    }
    
    
    
    
  
    
    oof1x = x-size-(size/2) + oof;
        
    oof2x = x-size+arm_size+size+arm_size+(size/2) + oof2;
   
    oof3x = x-size-(size/2) + oof3;
        
    oof4x = x-size+arm_size+size+arm_size+(size/2) + oof4;
    
    oof5x = x-size- (size/2) + oof5;
    
    oof6x =  x-size+arm_size+size+arm_size+(size/2) +oof6;
        
    oof7x = x-size+arm_size+size+arm_size+(size/2) + size/4 + oof7;
        
    oof8x =  x-size-(size/2)+ size/4 + oof8;
        
    oof1y = y+(arm_size+size)+(head_size+size)-skip2 - oof1yb;
        
    oof2y = y+(arm_size+size)+(head_size+size)-skip2 - oof2yb;
   
    oof3y = y+(arm_size+size)+(head_size+size)-skip2 +(size - 3 )/2 - oof3yb;
        
    oof4y = y+(arm_size+size)+(head_size+size)-skip2+(size - 3)/2 - oof4yb;
    
    oof5y = y+(arm_size+size)+(head_size+size)-skip2 +(size - 4)- oof5yb;
    
    oof6y = y+(arm_size+size)+(head_size+size)-skip2+(size - 4) - oof6yb;
        
    oof7y = (y+(arm_size+size)+(head_size+size)-skip2+(size - 4) +(size -4)/2) - oof7yb;
        
    oof8y = y+(arm_size+size)+(head_size+size)-skip2 +(size - 4)+(size -4)/2 - oof8yb;
        
    
     
   /* if(size > 6){
    skip = skip + 1;
     
    }
     
       */
      gathrillo::gui::Dline arm1(90, 3, x, y, 1, arm_size+size, 0x00, 0xA8, 0x00); 
     
      gathrillo::gui::Dline arm2(90, 1, x, y, 1, arm_size+size, 0x00, 0xA8, 0x00);
    
      gathrillo::gui::Dline leg1(90, 3, x, y+(spine_size)+size+(spine2_size)+size, 1, leg_size+size, 0x00, 0x00, 0xA8); 
      
      gathrillo::gui::Dline leg2(90, 1, x, y+(spine_size)+size+(spine2_size)+size, 1, leg_size+size, 0x00, 0x00, 0xA8); 
    
      gathrillo::gui::Dline quad1(90, 5, x-leg_size-size, y+(spine_size)+size+(spine2_size)+size+(leg_size)+size, 1, quad_size1+size - quad1b, 0x00, 0x00, 0xAF);
    
      gathrillo::gui::Dline quad2(90, 5, x+leg_size+size, y+(spine_size)+size+(spine2_size)+size+(leg_size)+size, 1, quad_size2+size -quad2b, 0x00, 0x00, 0xAF);
    
    
    
      gathrillo::gui::Dline forearm_1(90, 5, x-arm_size-size, y+arm_size+size, 1, forearm_size1+size - fore1, 0x00, 0xAF, 0x00);
    
      gathrillo::gui::Dline forearm_2(90, 5, x+arm_size+size, y+arm_size+size, 1, forearm_size2+size - fore2, 0x00, 0xAF, 0x00);
    
    
      gathrillo::gui::Dline spine(90, 5, x, y, 1, spine_size+size, 0xFE, 0xFE, 0xFE);
    
      gathrillo::gui::Dline spine_2(90, 5, x, y+spine_size+size, 1, spine2_size+size, 0xFD, 0xFD, 0xFD);
     
    
      gathrillo::gui::Dline head(90, 5, x, y-head_size-size, 1, head_size+size, 0xA8, 0x00, 0x00);
    
    
    
    
    
    
    
    
    
      gathrillo::gui::Dline ooooooooof(90, 10, oof1x, oof1y, (size - 2 )/2 - oof, 3, 0x00, 0x00, cc1);
     
    
      gathrillo::gui::Dline ooooooooof2(90, 10, oof2x, oof2y, (size - 2)/2 - oof2, 3, 0x00, 0x00, cc2);
    
    
      gathrillo::gui::Dline ooooooooof3(90, 10, oof3x, oof3y, (size - 2 )/2 - oof3, 3, 0x00, 0x00, cc3);
     
    
      gathrillo::gui::Dline ooooooooof4(90, 10, oof4x, oof4y, (size - 2)/2 - oof4 , 3, 0x00, 0x00, cc4);
    

    
      gathrillo::gui::Dline ooooooooof5(90, 10, oof5x, oof5y, (size - 2 )/2 - oof5, 3, 0x00, 0x00, cc5);
    
    
      gathrillo::gui::Dline ooooooooof6(90, 10,oof6x, oof6y, (size - 2)/2 - oof6 , 3, 0x00, 0x00, cc6);
    
      gathrillo::gui::Dline ooooooooof7(90, 11, oof7x, oof7y, (size - 2)/2 - oof7, (size - 2)/2, 0xA1, 0xA1, cc7);
    
      gathrillo::gui::Dline ooooooooof8(90, 11,oof8x, oof8y, (size - 2 )/2 - oof8, (size - 2)/2, 0xA1, 0xA1, cc8);
    
    
  
      
    
    
}



Skelekton::~Skelekton() {
    
    
    
}



Animation::Animation(common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b) 
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
    
    
{

    gathrillo::gui::Run(90, 10,  50, 60, 10, 10, 0x00, 0x00, 0x00);
    gathrillo::gui::Punch(90, 10,  50, 60, 10, 10, 0x00, 0x00, 0x00);
    gathrillo::gui::Punch(90, 10,  50, 60, 10, 10, 0x00, 0x00, 0x00);
    
    
}


Animation::~Animation(){
    
    
    
}

int keyframe = 0;

Run::Run(common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b) 
    
  : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
  
    
{

   while(1) {
      keyframe += 1;
   
    
      if(keyframe = 28){
          
          break;
          
      }
   }
      
        
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
    
 
      
    if(keyframe = 1){
  gathrillo::gui::Skelekton (0,0,90,0,0,90,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);
 
        
    

    }
      
       if(keyframe = 5){  
           
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
        
    gathrillo::gui::Skelekton (0,30,60,0,30,60,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

 
       }
      
        
     if(keyframe = 9){   
         
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);     
        
    gathrillo::gui::Skelekton (0,60,30,0,60,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

         
     }
      
        
       if(keyframe = 13){  
       
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
       
    gathrillo::gui::Skelekton (0,90,0,0,90,0,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

          }
           
           
        if(keyframe = 17){ 
        
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);    
            
    gathrillo::gui::Skelekton (0,60,30,0,60,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

    
        }
      
        
         if(keyframe = 21){
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);         
             
    gathrillo::gui::Skelekton (0,30,60,0,30,60,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);
        
             
         }
      
        
         if(keyframe = 25){
             
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);         
         
    gathrillo::gui::Skelekton (0,0,90,0,0,90,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);
   
             
          
         }
      
     
    
 
}


Run::~Run(){
    
    
    
}

Jump::Jump(common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b) 
    
   : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 
    
{

    
    
    
    
    
}

Jump::~Jump(){
    
    
    
}

Punch::Punch(common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b) 
    
    : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

    
{

    
    while(1) {
      keyframe += 1;
   
    
      if(keyframe = 28){
          
          break;
          
      }
   }
      
        
gathrillo::drivers::VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
    
 
      
    if(keyframe = 1){
  gathrillo::gui::Skelekton (0,0,0,0,30,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);
  
        
    

    }
      
      /* if(keyframe = 5){  
           
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
        
    gathrillo::gui::Skelekton (0,30,0,0,30,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

   
       
           
           

       }
      */
        
     if(keyframe = 9){   
         
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);     
        
    gathrillo::gui::Skelekton (0,60,0,0,30,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

   
         
     }
      
        
       if(keyframe = 13){  
       
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
       
    gathrillo::gui::Skelekton (0,90,0,0,30,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

   
      
          }
           
           
       /* if(keyframe = 17){ 
        
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);    
            
    gathrillo::gui::Skelekton (0,60,0,0,30,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);

    

        }
      
        
         if(keyframe = 21){
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);         
             
    gathrillo::gui::Skelekton (0,30,0,0,30,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);
    
         
             
         }
      
        
         if(keyframe = 25){
             
    
           
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0, 160, 120, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);         
         
    gathrillo::gui::Skelekton (0,0,0,0,30,30,0,0,0, 2, 4, 3, 2,2, 2, 3, 2,2, 1, 10, 50, 60, 1, 1, 0xFE, 0xFE, 0xFE);
    

             
          
         } 
    
    */
    
}

Punch::~Punch(){
    
    
    
}

Kick::Kick(common::uint8_t AnglePos, common::uint8_t size,  common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b) 
  
    : CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)

    
    
{

    
    
    
    
    
}

Kick::~Kick(){
    
    
    
}


face::face(/*Widget* parent,*/ common::uint8_t att, common::uint8_t angle, common::uint8_t x, common::int32_t y,  common::uint8_t w, common::int32_t h,common::uint8_t fv1x, common::int32_t fv2x, common::int32_t fv3x, common::uint8_t fv1y, common::int32_t fv2y, common::int32_t fv3y, common::uint8_t fv1z, common::int32_t fv2z, common::int32_t fv3z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
{

    
  
    
int o; 
int p; 
int d;
int hy;
    
int o2; 
int p2; 
int d2;
int hy2;
    
int angintshift;
int xshift;
int xshift1;
int xshift2;
int xshift3;
 int offsetshift1;
 int offsetshift2;
 int offsetshift3;
 int offsetshift4;
 int offsetshift5;
 int offsetshift6;
 int offsetshift7;
 int offsetshift8;
 int offsetshiftx1;
 int offsetshiftx2;
    
    
    
    
 int offsetshift11;
 int offsetshift12;
 int offsetshift13;
 int offsetshift14;
 int offsetshift15;
 int offsetshift16;
 int offsetshift17;
 int offsetshift18;
 int offsetshift19;
 int offsetshift20;    
 
 //int dis;   
double sqrt[1000];
double offset;
    
/*sqrt1 = 1.0; 
sqrt2 = 1.4142; 
sqrt3 = 1.7321; 
sqrt4 = 2.0; 
sqrt5 = 2.2361; 
sqrt6 = 2.4494; 
sqrt7 = 2.6457; 
sqrt8 = 2.8284; 
sqrt9 = 3.0; 
sqrt10 = 3.1622; 
 */   
  
    
sqrt[1] = 1.0; 
sqrt[2] = 1.4142; 
sqrt[3] = 1.7321; 
sqrt[4] = 2.0; 
sqrt[5] = 2.2361; 
sqrt[6] = 2.4494; 
sqrt[7] = 2.6457; 
sqrt[8] = 2.8284; 
sqrt[9] = 3.0; 
sqrt[10] = 3.1622;
sqrt[11] = 3.317;
sqrt[12] = 3.464;
sqrt[13] = 3.606;
sqrt[14] = 3.742;
sqrt[15] = 3.873;
sqrt[16] = 4.000;
sqrt[17] = 4.123;
sqrt[18] = 4.243;
sqrt[19] = 4.359;
sqrt[20] = 4.472;
sqrt[21] = 4.583;
sqrt[22] = 4.690;
sqrt[23] = 4.796;
sqrt[24] = 4.899;
sqrt[25] = 5.000;
sqrt[26] = 5.099;
sqrt[27] = 5.196;
sqrt[28] = 5.292;
sqrt[29] = 5.385;
sqrt[30] = 5.477;
sqrt[31] = 5.568;
sqrt[32] = 5.657;
sqrt[33] = 5.745;
sqrt[34] = 5.831;
sqrt[35] = 5.916;
sqrt[36] = 6.000;
sqrt[37] = 6.083;
sqrt[38] = 6.164;
sqrt[39] = 6.245;
sqrt[40] = 6.325;
sqrt[41] = 6.403;
sqrt[42] = 6.481;
sqrt[43] = 6.557;
sqrt[44] = 6.633;
sqrt[45] = 6.708;
sqrt[46] = 6.782;
sqrt[47] = 6.856;
sqrt[48] = 6.928;
sqrt[49] = 7.000;
sqrt[50] = 7.071;
sqrt[51] = 7.141;
sqrt[52] = 7.211;
sqrt[53] = 7.280;
sqrt[54] = 7.348;
sqrt[55] = 7.416;
sqrt[56] = 7.483;
sqrt[57] = 7.550;
sqrt[58] = 7.616;
sqrt[59] = 7.681;
sqrt[60] = 7.746;
sqrt[61] = 7.810;
sqrt[62] = 7.874;
sqrt[63] = 7.937;
sqrt[64] = 8.000;
sqrt[65] = 8.062;
sqrt[66] = 8.124;
sqrt[67] = 8.185;
sqrt[68] = 8.246;
sqrt[69] = 8.307;
sqrt[70] = 8.367;
sqrt[71] = 8.426;
sqrt[72] = 8.485;
sqrt[73] = 8.544;
sqrt[74] = 8.602;
sqrt[75] = 8.660;
sqrt[76] = 8.718;
sqrt[77] = 8.775;
sqrt[78] = 8.832;
sqrt[79] = 8.888;
sqrt[80] = 8.944;
sqrt[81] = 9.000;
sqrt[82] = 9.055;
sqrt[83] = 9.110;
sqrt[84] = 9.165;
sqrt[85] = 9.220;
sqrt[86] = 9.274;
sqrt[87] = 9.327;
sqrt[88] = 9.381;
sqrt[89] = 9.434;
sqrt[90] = 9.487;
sqrt[91] = 9.539;
sqrt[92] = 9.592;
sqrt[93] = 9.644;
sqrt[94] = 9.695;
sqrt[95] = 9.747;
sqrt[96] = 9.798;
sqrt[97] = 9.849;
sqrt[98] = 9.899;
sqrt[99] = 9.950;
sqrt[100] = 10.000; 
sqrt[101] = 10.049;
sqrt[102] = 10.099;
sqrt[103] = 10.148;
sqrt[104] = 10.198;
sqrt[105] = 10.246;
sqrt[106] = 10.295;
sqrt[107] = 10.344;
sqrt[108] = 10.392;
sqrt[109] = 10.440;
sqrt[110] = 10.488;
sqrt[111] = 10.535;
sqrt[112] = 10.583;
sqrt[113] = 10.630;
sqrt[114] = 10.630;
sqrt[115] = 10.723;
sqrt[116] = 10.770;
sqrt[117] = 10.816;
sqrt[118] = 10.862;
sqrt[119] = 10.908;
sqrt[120] = 10.954;
sqrt[121] = 11.000;
sqrt[122] = 11.045;
sqrt[123] = 11.090;
sqrt[124] = 11.135;
sqrt[125] = 11.180;
sqrt[126] = 11.224;
sqrt[127] = 11.269;
sqrt[128] = 11.313;

    
sqrt[162] = 12.727;  
    
gathrillo::drivers::VideoGraphicsArray vga5;
     vga5.SetMode(0,0,8);
    
     gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00);
    
    
if(angle > 0 && angle < 80)
{
    angintshift = 1;   
}

if(angle > 100 && angle < 170)
{
    angintshift = 2;
}
    
if(angle > 190 && angle < 260)
{
    angintshift = 3;
}
 
if(angle > 280 && angle < 350)
{
    angintshift = 4;
}
    
if(angle == 57){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 2;
}
 if(angle == 0){
    
  angintshift = 0; 
   //angintshift = 5; 

   xshift = 0;
}   
if(angle == 10){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 1;
}
    
if(angle == 20){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 2;
}
    
if(angle == 30){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 3;
}
    
if(angle == 40){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 4;
}
    
if(angle == 50){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 5;
}
    
if(angle == 60){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 6;
}
    
if(angle == 70){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 7;
}
  
if(angle == 80){
    
  angintshift = 1; 
   //angintshift = 5; 

   xshift = 8;
}

if(angle == 80){
    
    
  //angintshift = 0; 
   //angintshift = 5; 

   xshift = 0;
}
    
    
if(angle == 100){
    
  angintshift = 2; 
   //angintshift = 5; 
   
   xshift = 0;
   xshift2 = 0;
   xshift1 = 1;
}
    
if(angle == 110){
    
  angintshift = 2; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 2;

}
    
if(angle == 120){
    
  angintshift = 2; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 3;
}
    
if(angle == 130){
    
  angintshift = 2; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 4;
}
    
if(angle == 140){
    
  angintshift = 2; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 5;
}
    
if(angle == 150){
    
  angintshift = 2; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 6;
}
    
if(angle == 160){
    
  angintshift = 2; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 7;
}
  
if(angle == 170){
    
  angintshift = 2; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 8;
}

 if(angle == 180){
    
  angintshift = 0; 
   //angintshift = 5; 
   xshift = 0;
   xshift2 = 0;
   xshift1 = 9;
}   
    

if(angle == 190){
    
  angintshift = 3; 
   //angintshift = 5; 
   
   xshift1 = 0;
   xshift2 = 3;
}
    
if(angle == 200){
    
  angintshift = 3; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 4;
}
    
if(angle == 210){
    
  angintshift = 3; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 5;
}
    
if(angle == 220){
    
  angintshift = 3; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 6;
}
    
if(angle == 230){
    
  angintshift = 3; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 7;
}
    
if(angle == 240){
    
  angintshift = 3; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 8;
}
    
if(angle == 250){
    
  angintshift = 3; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 9;
}
  
if(angle == 260){
    
  angintshift = 7; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 7;
    
    
}

    
/*if(angle == 270){
    
  angintshift = 3; 
   //angintshift = 5; 
   xshift1 = 0;
   xshift2 = 8;
}*/

 
 
 
 if(angle == 280){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;
   xshift3 = 3;
}
    
if(angle == 290){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;   xshift3 = 4;
}
    
if(angle == 300){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;   xshift3 = 5;
}
    
if(angle == 310){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;   
    xshift3 = 6;
}
    
if(angle == 320){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;   
    xshift3 = 7;
}
    
if(angle == 330){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;  
    xshift3 = 8;
}
    
if(angle == 340){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;   
    xshift3 = 9;
}
  
if(angle == 350){
    
  angintshift = 4; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
   xshift2 = 0;  
   xshift3 = 7;
    
   
}   
   
    
    
    
if(angle == 80){
    
    
  //angintshift = 0; 
   //angintshift = 5; 

   xshift = 0;
}
        
    
    
    
if(angle == 170){
    
    
  //angintshift = 0; 
   //angintshift = 5; 
   xshift = 0;
   xshift1 = 0;
    
    
    
}


    
/*if(angle == 260){
    
    
  //angintshift = 0; 
   //angintshift = 5; 

   xshift = 0;
    
}*/

    
if(angle == 350){
    
    
    
  //angintshift = 0; 
   //angintshift = 5; 

   xshift = 0;
}

    

    

if(id > 1){
    
xshift = 0;
xshift1 = 0;
xshift2 = 0;  
xshift3 = 0;   
    
//dis = 9;
    
} 
    
  
    
   
    
    
    
    
    
    
    
    


//if(id > 0) {
    
    


if(id == 1){
    
if(angle == 0 || angintshift == 1 || angintshift == 4){    
if (fv2y > fv3y && fv2x == fv3x) { 
    
    gathrillo::gui::Window l(&desktop5, ang, x+p - offsetshift1, y , 1, p , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p;
    p = (fv2y - fv3y) * scale;
    offsetshift1 = xshift;
    
    if (p == fv3y + 7) { 
    
    p = p - 1;  
}
    
    
    
    
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
 
 gathrillo::gui::Dline f(90, 3, x+d-1, y-d+1, d-(xshift*2+10), d-(xshift*2+10), r, g, b);
    

    d = sqrt[(o*o) + (p*p)] - xshift - 1;
    offsetshiftx1 = d;
    
    
   
    if (d == fv1y - 3) { 
    
    d = d + 1;
}
    if(p > 5){
        d = d - 1;
    }
    
} 
if (fv1x < fv2x && fv1y < fv2y) { 
    gathrillo::gui::Window l(&desktop5, ang, x, y, o - offsetshift2, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o;
    o = (fv2x - fv1x) * scale;
    offsetshift2 = xshift;

    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7){
        
        o -= 1;
        
    }
}
if (fv2y == fv3y && fv2x < fv3x) { 
    
    gathrillo::gui::Window l(&desktop5, ang, x, y , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
    p2 = (fv3x - fv2x) * scale;

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
} 
 
if (fv1x == fv2x && fv1y < fv2y) { 
    gathrillo::gui::Window l(&desktop5, ang, x, y-o2, o2-offsetshift3, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;
    o2 = (fv2y - fv1y) * scale;
    offsetshift3 = xshift;
    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
} 
    
}
    
    
  
    
    
       
    
    

    
if(angle == 90 || angintshift == 1 || angintshift == 2 || angintshift == 5){    
if (fv2y > fv3y && fv2x == fv3x) { 
    
    
    
    if(angintshift == 2) {
        
        
        xshift = 0;
        offsetshift4 = 0;
        
    }
    
    
    
  
    
    if(angintshift == 1){
        
    xshift = -p;
    offsetshift4 = p;
        
    }
    
    
    
    
    
    gathrillo::gui::Window l(&desktop5, ang, x+p+xshift/*-(p2-offsetshift2*/-xshift1, y - offsetshift4, 1, p+1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    
    
    
    
    
    y += p;
    p = (fv2y - fv3y) * scale;
     
    
    
    if (p == fv3y + 7) { 
    
    p = p - 1;  
        
    
}
    
    
    
    
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
  int coof;
  coof = 0;
    
    if(angle == 90){
      
        coof = d;
        
    }
    
 gathrillo::gui::Dline f(90, 3, x+(d-1-offsetshift5+d)-coof+1, y-(d+1-offsetshift5)-(coof+ (coof/2) + coof/4 )+xshift1, d-(offsetshift5)+coof+2+xshift1, d-(offsetshift5)+coof+xshift1,r, g, b);
    

   
    
    
    d = sqrt[(o*o) + (p*p)];
    offsetshift5 = d; 

    if (d == fv1y - 3) { 
    
    d = d + 1;
}
    if(p > 5){
        d = d - 1;
    }
    
    
    
    
    
} 

    
//bug    
if (fv1x < fv2x && fv1y < fv2y) { 
   
    int use;
    
    
    if(angintshift == 1 ){
    use = o-offsetshift1;    
     
        
    }
    
    if(angintshift == 2){
    use = 0;  
    //offsetshift6 = 0;    

    }
    
    offsetshift6 = o;   
    gathrillo::gui::Window l(&desktop5, ang, x-offsetshift6+(o-xshift), y, o-(use)-xshift1, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o;
    o = (fv2x - fv1x) * scale;
    

    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7){
        
        o -= 1;
        
    }
}


if (fv2y == fv3y && fv2x < fv3x) { 
  
     if(angintshift == 1){
    //use = o-offsetshift1;    
    offsetshift7 = o;    
        
    }
    
    if(angintshift == 2){
    //use = 0;  
    offsetshift7 = 0;    

    }
    
    
    
    gathrillo::gui::Window l(&desktop5, ang, x/*-offsetshift7*/, y - offsetshift7 , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
    p2 = (fv3x - fv2x) * scale;
    offsetshift7 = p2; 

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
} 
 
if (fv1x == fv2x && fv1y < fv2y) { 
    gathrillo::gui::Window l(&desktop5, ang, x-offsetshift8+(o2-xshift), y-o2-offsetshift8 + offsetshift8, o2-(o-offsetshift2)-xshift1, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;
    o2 = (fv2y - fv1y) * scale;

    offsetshift8 = o2; 

    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
} 
   
}

    
    
    
    
    
    
    
if(angle == 180 || angintshift == 2 || angintshift == 3){    

    int use;
  
    if (fv2y < fv3y && fv2x == fv3x) { 
    
        
     if(angintshift == 3) {
        
        
        xshift1 = 0;
        offsetshift11 = 0;
      // use = 0;
         
     use = p;   

    }
    
    
    
  
    
    if(angintshift == 2){
        
    offsetshift11 = p; 
      use = p - xshift1;   
    }
        
        
        
    gathrillo::gui::Window l(&desktop5, ang, x+use- xshift2, y+1 , 1, p , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p;
    p = (fv3y - fv2y) * scale;
  
    
    if (p == fv3y + 7) { 
    
    p = p - 1;      
        
        
}
        
      
        
        
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
  int coof;
  coof = 0;
    
  int coof2;
  coof2 = 0;
    
   
    if(angle > 90 && angle < 170){
      
        coof2 = d;
        
    }
    
    
    
    if(angle == 180){
      
        coof = d - 3;
        
    }
    
     d = sqrt[(o*o) + (p*p)];
    offsetshift12 = d;
   
 
 gathrillo::gui::Dline f(90, 2, x+(d-1-offsetshift12+d)-coof-d, y-1, d-coof2-3, d-coof2-3, r, g, b);
    

   
    if (d == fv3y - 3) { 
    
    d = d + 1;
}
    if(p > 4){
        d = d - 1;
    }
     if(p > 7){
        d = d - 1;
    }
    
} 
if (fv1x < fv2x && fv1y < fv2y) {
    
    int use; 
    
    if(angintshift == 2 ){
    use = offsetshift13+2;    
     
        
    }
    
    if(angintshift == 3){
    use = 0;  
    //offsetshift6 = 0;    

    }
    
    
    gathrillo::gui::Window l(&desktop5, ang, x- xshift1 , y, o-use + xshift1 - xshift2+o/4 + 1 , 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5);
    x += o;
    o = (fv2x - fv1x) * scale;
    offsetshift13 = o;

    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7){
        
        o -= 1;
        
    }
}
if (fv2y < fv3y && fv2x == fv3x) { 
    
    
      
    int use;
    int use1;
     
    if(angintshift == 2){
    use = (p*2)-(offsetshift13);    
     
    offsetshift13 = p2;

    use1 = 0;   
    }
    
    if(angintshift == 3){
    offsetshift13 = p2;

    use = offsetshift13/2;  
    //offsetshift6 = 0;    
    use1 = p2/2;
    }
    
    gathrillo::gui::Window l(&desktop5, ang, x+use-use1, y-p2+1 , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
    p2 = (fv3x - fv1x) * scale;

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
 
    
} 

if (fv1x < fv2x && fv1y < fv2y && fv3z == fv2x) { 
    
    int use;
    int use1;
    int use2;
     
    if(angintshift == 2){
    offsetshift15 = o2*2;

    use = o2- xshift1;    
    use2 = 0; 
    
    }
    
    if(angintshift == 3){
        //offsetshift15 = 0;
    offsetshift15 = o2;
    use = offsetshift15/2;  
    //offsetshift6 = 0;    
    use1 = o2/2;
    use2 = use1*2+use1/2;
    }
    
    
    
    o2 = (fv2x - fv1x) * scale;
    
    gathrillo::gui::Window l(&desktop5, ang, x-use - use1, y+o2, o2-(offsetshift15) + xshift1 - xshift2 +use2,  1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;
   
    
    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
    
    
if (o2 < 4) { 
    
o2 += 1; 
}
    

}       
    
    
    
    
     
  
    }

 
     
    
    
    
if(angle == 270 || angintshift == 3 || angintshift == 4){    

  
    if (fv2y < fv3y && fv2x == fv3x) { 
    
        
    p = (fv3y - fv2y) * scale;
    offsetshift16 = p*2;
    
    
    
    gathrillo::gui::Window l(&desktop5, ang, x+p, y+1-offsetshift16 , 1, p , r, g, b, size); 
    desktop5.AddChild(&l);
        
    
     
     
    desktop5.Draw(&vga5); 
    
    y += p;
    
    
    if (p == fv3y + 7) { 
    
    p = p - 1;      
        
        
}
        
      
        
        
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
  int use;
    
if (angle == 250) {
        
        use = 0;
        
    
    
        
    }    
    
  if(angle > 180 && angle < 250){
      
       use = d;   
  
    }
    
    
    
 gathrillo::gui::Dline f(90, 2, x, y+d-1, d-xshift2, d-use, r, g, b);
    

    d = sqrt[(o*o) + (p*p)];
   
    if (d == fv3y - 3) { 
    
    d = d + 1;
}
    if(p > 4){
        d = d - 1;
    }
     if(p > 7){
        d = d - 1;
    }
    
} 
if (fv1x < fv2x && fv1y < fv2y) { 
   
    

    offsetshift18 = o;
    
    
    gathrillo::gui::Window l(&desktop5, ang, x-(offsetshift18)/2-2, y , o-o/2 + 2, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o;
    
    o = (fv2x - fv1x) * scale;

    

   
    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7 ){
        
        o -= 1;
        
    }
}
if (fv2y < fv3y && fv2x == fv3x) { 
    p2 = (fv3x - fv1x) * scale;
    offsetshift19 = p2*2;
    
    gathrillo::gui::Window l(&desktop5, ang, x+offsetshift19/2-xshift2, y-p2+1-offsetshift19 , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
   

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
 
    
} 

if (fv1x < fv2x && fv1y < fv2y && fv3z == fv2x) { 
   
    offsetshift20 = o2*2;

    
    o2 = (fv2x - fv1x) * scale;

    gathrillo::gui::Window l(&desktop5, ang, x-o2-offsetshift20, y+o2, o2, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;

    
    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
    
    
if (o2 < 4) { 
    
o2 += 1; 
}
    

}       
    
    
    
    
     
  
    }    
    
//}
    
  
}
 
    
    
    
    
    
    


if(id > 1){
    
if(angle == 0 || angintshift == 1 || angintshift == 4){    
if (fv2y > fv3y && fv2x == fv3x) { 
    
    gathrillo::gui::Window l(&desktop5, ang, x+p - offsetshift1, y , 1, p , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p;
    p = (fv2y - fv3y) * scale;
    offsetshift1 = xshift;
    
    if (p == fv3y + 7) { 
    
    p = p - 1;  
}
    
    
    
    
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
 
 gathrillo::gui::Dline f(90, 3, x+d-1, y-d+1, d-(xshift*2+10), d-(xshift*2+10), r, g, b);
    

    d = sqrt[(o*o) + (p*p)] - xshift - 1;
    offsetshiftx1 = d;
    
    
   
    if (d == fv1y - 3) { 
    
    d = d + 1;
}
    if(p > 5){
        d = d - 1;
    }
    
} 
if (fv1x < fv2x && fv1y < fv2y) { 
    gathrillo::gui::Window l(&desktop5, ang, x, y, o - offsetshift2, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o;
    o = (fv2x - fv1x) * scale;
    offsetshift2 = xshift;

    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7){
        
        o -= 1;
        
    }
}
if (fv2y == fv3y && fv2x < fv3x) { 
    
    gathrillo::gui::Window l(&desktop5, ang, x, y , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
    p2 = (fv3x - fv2x) * scale;

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
} 
 
if (fv1x == fv2x && fv1y < fv2y) { 
    gathrillo::gui::Window l(&desktop5, ang, x, y-o2, o2-offsetshift3, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;
    o2 = (fv2y - fv1y) * scale;
    offsetshift3 = xshift;
    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
} 
    
}
    
    
  
    
    
       
    
    

    
if(angle == 90 || angintshift == 1 || angintshift == 2 || angintshift == 5){    
if (fv2y > fv3y && fv2x == fv3x) { 
    
    
    
    if(angintshift == 2) {
        
        
        xshift = 0;
        offsetshift4 = 0;
        
    }
    
    
    
  
    
    if(angintshift == 1){
        
    xshift = -p;
    offsetshift4 = p;
        
    }
    
    
    
    
    
    gathrillo::gui::Window l(&desktop5, ang, x+p+xshift/*-(p2-offsetshift2*/-xshift1, y - offsetshift4, 1, p+1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    
    
    
    
    
    y += p;
    p = (fv2y - fv3y) * scale;
     
    
    
    if (p == fv3y + 7) { 
    
    p = p - 1;  
        
    
}
    
    
    
    
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
  int coof;
  coof = 0;
    
    if(angle == 90){
      
        coof = d;
        
    }
    
 gathrillo::gui::Dline f(90, 3, x+(d-1-offsetshift5+d)-coof+1, y-(d+1-offsetshift5)-(coof+ (coof/2) + coof/4 )+xshift1, d-(offsetshift5)+coof+2+xshift1, d-(offsetshift5)+coof+xshift1,r, g, b);
    

   
    
    
    d = sqrt[(o*o) + (p*p)];
    offsetshift5 = d; 

    if (d == fv1y - 3) { 
    
    d = d + 1;
}
    if(p > 5){
        d = d - 1;
    }
    
    
    
    
    
} 

    
//bug    
if (fv1x < fv2x && fv1y < fv2y) { 
   
    int use;
    
    
    if(angintshift == 1 ){
    use = o-offsetshift1;    
     
        
    }
    
    if(angintshift == 2){
    use = 0;  
    //offsetshift6 = 0;    

    }
    
    offsetshift6 = o;   
    gathrillo::gui::Window l(&desktop5, ang, x-offsetshift6+(o-xshift), y, o-(use)-xshift1, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o;
    o = (fv2x - fv1x) * scale;
    

    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7){
        
        o -= 1;
        
    }
}


if (fv2y == fv3y && fv2x < fv3x) { 
  
     if(angintshift == 1){
    //use = o-offsetshift1;    
    offsetshift7 = o;    
        
    }
    
    if(angintshift == 2){
    //use = 0;  
    offsetshift7 = 0;    

    }
    
    
    
    gathrillo::gui::Window l(&desktop5, ang, x/*-offsetshift7*/, y - offsetshift7 , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
    p2 = (fv3x - fv2x) * scale;
    offsetshift7 = p2; 

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
} 
 
if (fv1x == fv2x && fv1y < fv2y) { 
    gathrillo::gui::Window l(&desktop5, ang, x-offsetshift8+(o2-xshift), y-o2-offsetshift8 + offsetshift8, o2-(o-offsetshift2)-xshift1, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;
    o2 = (fv2y - fv1y) * scale;

    offsetshift8 = o2; 

    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
} 
   
}

    
    
    
    
    
    
    
if(angle == 180 || angintshift == 2 || angintshift == 3){    

    int use;
  
    if (fv2y < fv3y && fv2x == fv3x) { 
    
        
     if(angintshift == 3) {
        
        
        xshift1 = 0;
        offsetshift11 = 0;
      // use = 0;
         
     use = p;   

    }
    
    
    
  
    
    if(angintshift == 2){
        
    offsetshift11 = p; 
      use = p - xshift1;   
    }
        
        
        
    gathrillo::gui::Window l(&desktop5, ang, x+use- xshift2, y+1 , 1, p , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p;
    p = (fv3y - fv2y) * scale;
  
    
    if (p == fv3y + 7) { 
    
    p = p - 1;      
        
        
}
        
      
        
        
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
  int coof;
  coof = 0;
    
  int coof2;
  coof2 = 0;
    
   
    if(angle > 90 && angle < 170){
      
        coof2 = d;
        
    }
    
    
    
    if(angle == 180){
      
        coof = d - 3;
        
    }
    
     d = sqrt[(o*o) + (p*p)];
    offsetshift12 = d;
   
 
 gathrillo::gui::Dline f(90, 2, x+(d-1-offsetshift12+d)-coof-d, y-1, d-coof2-3, d-coof2-3, r, g, b);
    

   
    if (d == fv3y - 3) { 
    
    d = d + 1;
}
    if(p > 4){
        d = d - 1;
    }
     if(p > 7){
        d = d - 1;
    }
    
} 
if (fv1x < fv2x && fv1y < fv2y) {
    
    int use; 
    
    if(angintshift == 2 ){
    use = offsetshift13+2;    
     
        
    }
    
    if(angintshift == 3){
    use = 0;  
    //offsetshift6 = 0;    

    }
    
    
    gathrillo::gui::Window l(&desktop5, ang, x- xshift1 , y, o-use + xshift1 - xshift2+o/4 + 1 , 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5);
    x += o;
    o = (fv2x - fv1x) * scale;
    offsetshift13 = o;

    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7){
        
        o -= 1;
        
    }
}
if (fv2y < fv3y && fv2x == fv3x) { 
    
    
      
    int use;
    int use1;
     
    if(angintshift == 2){
    use = (p*2)-(offsetshift13);    
     
    offsetshift13 = p2;

    use1 = 0;   
    }
    
    if(angintshift == 3){
    offsetshift13 = p2;

    use = offsetshift13/2;  
    //offsetshift6 = 0;    
    use1 = p2/2;
    }
    
    gathrillo::gui::Window l(&desktop5, ang, x+use-use1, y-p2+1 , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
    p2 = (fv3x - fv1x) * scale;

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
 
    
} 

if (fv1x < fv2x && fv1y < fv2y && fv3z == fv2x) { 
    
    int use;
    int use1;
    int use2;
     
    if(angintshift == 2){
    offsetshift15 = o2*2;

    use = o2- xshift1;    
    use2 = 0; 
    
    }
    
    if(angintshift == 3){
        //offsetshift15 = 0;
    offsetshift15 = o2;
    use = offsetshift15/2;  
    //offsetshift6 = 0;    
    use1 = o2/2;
    use2 = use1*2+use1/2;
    }
    
    
    
    o2 = (fv2x - fv1x) * scale;
    
    gathrillo::gui::Window l(&desktop5, ang, x-use - use1, y+o2, o2-(offsetshift15) + xshift1 - xshift2 +use2,  1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;
   
    
    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
    
    
if (o2 < 4) { 
    
o2 += 1; 
}
    

}       
    
    
    
    
     
  
    }

 
     
    
    
    
if(angle == 270 || angintshift == 3 || angintshift == 4){    

  
    if (fv2y < fv3y && fv2x == fv3x) { 
    
        
    p = (fv3y - fv2y) * scale;
    offsetshift16 = p*2;
    
    
    
    gathrillo::gui::Window l(&desktop5, ang, x+p, y+1-offsetshift16 , 1, p , r, g, b, size); 
    desktop5.AddChild(&l);
        
    
     
     
    desktop5.Draw(&vga5); 
    
    y += p;
    
    
    if (p == fv3y + 7) { 
    
    p = p - 1;      
        
        
}
        
      
        
        
} 
if (fv3x > fv1x && fv3y == fv1y) { 
 
  int use;
    
if (angle == 250) {
        
        use = 0;
        
    
    
        
    }    
    
  if(angle > 180 && angle < 250){
      
       use = d;   
  
    }
    
    
    
 gathrillo::gui::Dline f(90, 2, x, y+d-1, d-xshift2, d-use, r, g, b);
    

    d = sqrt[(o*o) + (p*p)];
   
    if (d == fv3y - 3) { 
    
    d = d + 1;
}
    if(p > 4){
        d = d - 1;
    }
     if(p > 7){
        d = d - 1;
    }
    
} 
if (fv1x < fv2x && fv1y < fv2y) { 
   
    

    offsetshift18 = o;
    
    
    gathrillo::gui::Window l(&desktop5, ang, x-(offsetshift18)/2-2, y , o-o/2 + 2, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o;
    
    o = (fv2x - fv1x) * scale;

    

   
    
    if (o == fv2x + 3) { 
    
    o = o - 1;
}
    
    if(o == 7 ){
        
        o -= 1;
        
    }
}
if (fv2y < fv3y && fv2x == fv3x) { 
    p2 = (fv3x - fv1x) * scale;
    offsetshift19 = p2*2;
    
    gathrillo::gui::Window l(&desktop5, ang, x+offsetshift19/2-xshift2, y-p2+1-offsetshift19 , 1, p2 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    
    y += p2;
   

    
    if (p2 == fv3y + 7) { 
    
    p2 = p2 - 1;  
}
 
    
} 

if (fv1x < fv2x && fv1y < fv2y && fv3z == fv2x) { 
   
    offsetshift20 = o2*2;

    
    o2 = (fv2x - fv1x) * scale;

    gathrillo::gui::Window l(&desktop5, ang, x-o2-offsetshift20, y+o2, o2, 1 , r, g, b, size); 
    desktop5.AddChild(&l);
     
    desktop5.Draw(&vga5); 
    x += o2;

    
    
    if (o2 == fv2x + 3) { 
    
    o2 = o2 - 1;
}
    
    
if (o2 < 4) { 
    
o2 += 1; 
}
    

}       
    
    
    
    
     
  
    }    
    
//}
    
  
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
    
    
    


  face::~face()
 {
     
 }
  


