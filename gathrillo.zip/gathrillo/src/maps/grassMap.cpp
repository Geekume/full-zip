#include <maps/grassMap.h>
#include <models/models.h>
#include <drivers/pit.h>
#include <hardwarecommunication/interrupts.h>
#include <gdt.h>


using namespace gathrillo;
using namespace gathrillo::common;
using namespace gathrillo::grassMap;



GrassMap::GrassMap (/*Widget* parent,*/ common::uint8_t rotatex, common::uint8_t rotx, common::uint8_t roty, common::uint8_t trans, common::uint8_t attx, common::uint8_t atty, common::uint8_t attz, common::uint8_t ang, common::int32_t x, common::int32_t y, common::int32_t z, common::int32_t scale, common::uint8_t r, common::uint8_t g, common::uint8_t b, common::uint8_t id, common::uint8_t zbuffer)
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
 {
      gathrillo::models::Terrain cube(3, 5, 0, 5, 25, 78, 3, 0, 100, 100,  0, 10, 0x00, 0xA8, 0x00, 10, 0); 
    
     
 }