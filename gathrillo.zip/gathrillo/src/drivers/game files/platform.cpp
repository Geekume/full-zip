#include <drivers/game.h>
#include <hardwarecommunication/pci.h>
#include <gui/desktop.h>
#include <gui/window.h>

using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;
GameEventHandler::GameEventHandler()
{
    
}
  
void GameEventHandler::OnGameKeyDown(char)
{
    
}
void GameEventHandler::OnGameKeyUp(char)
{
    
}







  GameDriver::GameDriver(InterruptManager* manager, GameEventHandler *handler)
  : InterruptHandler(0x21, manager),
    dataport(0x60),
    commandport(0x64)
  {
     this->handler = handler;
  }
  
  GameDriver::~GameDriver()
  {
  }
  
  void printf(char*);
  void printfHex(uint8_t);
  
  
  void GameDriver::Activate() 
  {
      while(commandport.Read() & 0x1)
          dataport.Read();
      commandport.Write(0xAE);
      commandport.Write(0x20);
      uint32_t status = (dataport.Read() | 1) & ~0x10;
      commandport.Write(0x60);
      dataport.Write(status);
      dataport.Write(0xf4);
  }
  
    


  uint32_t  GameDriver::HandleInterrupt(uint32_t esp)
  {
    
      uint8_t key = dataport.Read();
      if(handler == 0) 
          return esp;
      
      static bool shift = false;
      static bool pci = false;
      static bool black = false;
      static bool ok = true;
      static int i = 0;
      
      // 3D ENVIROMENTAL
      int x;
      int y;
      int z;
      int e;
      int rot;
      int angle;
      int plane1x;
      int plane2x;
      int plane3x;
      int plane4x;
      int plane5x;
      int plane6x;
      int plane7x;
      int plane8x;
      int plane9x;
      
      int plane1y;
      int plane2y;
      int plane3y;
      int plane4y;
      int plane5y;
      int plane6y;
      int plane7y;
      int plane8y;
      int plane9y;
      int size;
      int c;
      int d;
      int side;
      int j;
      
      
    //POLYFILL 
      int v1x;
      int v2x;
      int v3x;
      int v4x;
      
      int v1y;
      int v2y;
      int v3y;
      int v4y;
      
      
      int f;
      int n;
      int v;
     
    // POLYGON
      int vertex;
      int pointx;
      int pointy;
      int count;
      int count2;
      int point1x;
      int point1y;
      int point2x; 
      int point2y;
      //misc
      int test;
      int fire;
      int health;
      int enemypos;
      int change;
      
         if(key < 0x80)
      { 
      switch(key)
      {
    
    
            
          case 0x01: if(pci) 
    break;
              
    
    
    
   
// case 0x2A: case 0x3A: shift = true; break;
 //case 0xAA: case 0xB6: shift = false; break;       
    
        
   default:
    {
    case 0x45: break;
     printf("KEYBOARD 0x");
     printfHex(key);
     break;
      }
  


    
   

           
 count = 0; 
 count2 = 0;
  

              
if(i == 0) {              

case 0x1c:
 x = 0; 
 y = 70;
 z = 0;
 angle = 0;
 size = z + 50;
 side = 0xAF;
 c = 0x00;
 d = 0x00;
 e = 0x00;
 fire = 0;
health = 1;
enemypos = 30;
      v1x = 0;
      v2x = 0;
      v3x = 0;
      v4x = 0;
    
      v1y = 0;
      v2y = 0;
      v3y = 0;
      v4y = 0;
          
      f = 10;
    
   
    //if (v1y == 5) {
        n = 5;
    //}  
      v = 0;
    j = 0;
   change = 0;
    
   
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320, 200, 0x00,0x00,0xA8); 
 
     gathrillo::gui::Window health3(&desktop5, 90, 80,-15, 10, 10, 0x00, 0xA8, 0x00, 4);
     desktop5.AddChild(&health3);
    
    
    gathrillo::gui::Window health2(&desktop5, 90, 70,-15, 10, 10, 0xAF, 0xA8, 0xA8, 4);
     desktop5.AddChild(&health2);
    
    gathrillo::gui::Window health(&desktop5, 90, 60,-15, 10, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&health);
    
    
       gathrillo::gui::Window hud(&desktop5, 90, 0,-20, 320, 20, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&hud);
   
    
     

gathrillo::gui::Window pixel1(&desktop5, 90, x,42, 1, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
  gathrillo::gui::Window pixel2(&pixel1, 90, 151,43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
     gathrillo::gui::Window pixel3(&pixel1, 90, 151,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
     gathrillo::gui::Window pixel4(&pixel1, 90, 151,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
     gathrillo::gui::Window pixel5(&pixel1, 90, 150,40, 1, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel5);
    
     gathrillo::gui::Window pixel6(&pixel1, 90, 151,49, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel6);
    
     gathrillo::gui::Window pixel7(&pixel1, 90, 152,50, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel7);
    
     gathrillo::gui::Window pixel8(&pixel1, 90, 153,51, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel8);
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 158, 43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 157,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 156,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 160,40, 1, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     gathrillo::gui::Window pixel14(&pixel1, 90, 160,49, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel14);
    
     gathrillo::gui::Window pixel15(&pixel1, 90, 159,50, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel15);
    
     gathrillo::gui::Window pixel16(&pixel1, 90, 158,51, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel16);
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 153,54, 6, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 154,53, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 154,52, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 154,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 151,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 158,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 153,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 150,40, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 157,64, 2, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 153,64, 2, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    
     gathrillo::gui::Window pixel27(&pixel1, 90, 152,49, 8, 2, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 152,50, 8, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
   gathrillo::gui::Window pixel29(&pixel1, 90, 152,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel29);
    
 gathrillo::gui::Window pixel30(&pixel1, 90, 159,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel30);
 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 155,50, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 153,51, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 153,39, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
desktop5.Draw(&vga5); 
    
    

break;
    
}
  
              
              
              
      
              
              
              
              
              
              
              
              
              
 if(i == 0) {              

case 0x08:

      
 
 
     
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1, 1, 0x00,0x00,0x00);            


    
   
   
   

  
     // Main Screen
gathrillo::gui::Window pixel1(&desktop5, 90, 150,40, 10, 1, 0x00, 0xA8, 0x00, 4);
     desktop5.AddChild(&pixel1);
        
    gathrillo::gui::Window pixel2(&desktop5, 90, 150,40, 1, 10, 0x00, 0xA8, 0x00, 4);
     desktop5.AddChild(&pixel2);
        
        gathrillo::gui::Window pixel3(&desktop5, 90, 160,40, 1, 11, 0x00, 0xA8, 0x00, 4);
     desktop5.AddChild(&pixel3);
    
     
        gathrillo::gui::Window pixel4(&desktop5, 90, 200,200, 1, 1, 0x00, 0xA8, 0x00, 4);
     desktop5.AddChild(&pixel4);
        
        gathrillo::gui::Window pixel5(&desktop5, 90, 150,50, 10, 1, 0x00, 0xA8, 0x00, 4);
     desktop5.AddChild(&pixel5);
        

  
   
  
  
  
desktop5.Draw(&vga5); 

  

break;

}
                   
      
              
              
              
              
if(i == 0) {              

case 0x48:

x = x - 1;
z = z + 2;


size = z + 50;
    




   
   

   
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320, 200, 0x00,0x00,0xA8);    
      gathrillo::gui::Window enemy(&desktop5, 90, enemypos , y + 60, 10, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&enemy); 

gathrillo::gui::Window pixel1(&desktop5, 90, x,y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
  gathrillo::gui::Window pixel2(&pixel1, 90, 151,43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
     gathrillo::gui::Window pixel3(&pixel1, 90, 151,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
     gathrillo::gui::Window pixel4(&pixel1, 90, 151,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
     gathrillo::gui::Window pixel5(&pixel1, 90, 150,40, 1, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel5);
    
     gathrillo::gui::Window pixel6(&pixel1, 90, 151,49, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel6);
    
     gathrillo::gui::Window pixel7(&pixel1, 90, 152,50, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel7);
    
     gathrillo::gui::Window pixel8(&pixel1, 90, 153,51, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel8);
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 158, 43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 157,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 156,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 160,40, 1, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     gathrillo::gui::Window pixel14(&pixel1, 90, 160,49, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel14);
    
     gathrillo::gui::Window pixel15(&pixel1, 90, 159,50, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel15);
    
     gathrillo::gui::Window pixel16(&pixel1, 90, 158,51, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel16);
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 153,54, 6, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 154,53, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 154,52, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 154,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 151,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 158,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 153,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 150,40, 10, 9, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel24);
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 157,64, 2, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 153,64, 2, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    
     gathrillo::gui::Window pixel27(&pixel1, 90, 152,49, 8, 2, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 152,50, 8, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
   gathrillo::gui::Window pixel29(&pixel1, 90, 152,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel29);
    
 gathrillo::gui::Window pixel30(&pixel1, 90, 159,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel30);
 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 155,50, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 153,51, 6, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 153,39, 6, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel33);
    
    gathrillo::gui::Window ground(&desktop5, 90, 0,140, 320, 60, 0xA2, 0xA2, 0xA2, 4);
     desktop5.AddChild(&ground); 
    
      //terrain
    
    gathrillo::gui::Window platform1(&desktop5, 90, 45 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform1);
    
    
    
    gathrillo::gui::Window platform3(&desktop5, 90, 260 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform3);
    
    
    //sun
     gathrillo::gui::Window sun(&desktop5, 90, 280 , 0, 40, 40, 0x00, 0xA8, 0xA8, 4);
     desktop5.AddChild(&sun);
    
    gathrillo::gui::Window sunset1(&desktop5, 90, 0 , 0, 320, 20, 0xA8, 0x00, 0xA8, 4);
     desktop5.AddChild(&sunset1);
    
    gathrillo::gui::Window sunset2(&desktop5, 90, 260 , 120, 20, 5, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&sunset2);
desktop5.Draw(&vga5); 
    
    
break;

} 
            

if(i == 0) {              

case 0x50:
x = x + 1;
z = z - 2;

size = z + 50; 
     
   

      
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320, 200, 0x00,0x00,0xA8);            
gathrillo::gui::Window enemy(&desktop5, 90, enemypos , y + 60, 10, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&enemy);
    
gathrillo::gui::Window pixel1(&desktop5, 90, x,y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
  gathrillo::gui::Window pixel2(&pixel1, 90, 151,43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
     gathrillo::gui::Window pixel3(&pixel1, 90, 151,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
     gathrillo::gui::Window pixel4(&pixel1, 90, 151,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
     gathrillo::gui::Window pixel5(&pixel1, 90, 150,40, 1, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel5);
    
     gathrillo::gui::Window pixel6(&pixel1, 90, 151,49, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel6);
    
     gathrillo::gui::Window pixel7(&pixel1, 90, 152,50, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel7);
    
     gathrillo::gui::Window pixel8(&pixel1, 90, 153,51, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel8);
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 158, 43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 157,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 156,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 160,40, 1, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     gathrillo::gui::Window pixel14(&pixel1, 90, 160,49, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel14);
    
     gathrillo::gui::Window pixel15(&pixel1, 90, 159,50, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel15);
    
     gathrillo::gui::Window pixel16(&pixel1, 90, 158,51, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel16);
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 153,54, 6, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 154,53, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 154,52, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 154,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 151,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 158,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 153,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 150,40, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 157,64, 2, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 153,64, 2, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    
     gathrillo::gui::Window pixel27(&pixel1, 90, 152,49, 8, 2, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 152,50, 8, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
   gathrillo::gui::Window pixel29(&pixel1, 90, 152,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel29);
    
 gathrillo::gui::Window pixel30(&pixel1, 90, 159,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel30);
 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 155,50, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 153,51, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 153,39, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
    gathrillo::gui::Window ground(&desktop5, 90, 0,140, 320, 60, 0xA2, 0xA2, 0xA2, 4);
     desktop5.AddChild(&ground); 
      //terrain
    
    gathrillo::gui::Window platform1(&desktop5, 90, 45 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform1);
    
    
    
    gathrillo::gui::Window platform3(&desktop5, 90, 260 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform3);
    
    
    //sun
     gathrillo::gui::Window sun(&desktop5, 90, 280 , 0, 40, 40, 0x00, 0xA8, 0xA8, 4);
     desktop5.AddChild(&sun);
    
    gathrillo::gui::Window sunset1(&desktop5, 90, 0 , 0, 320, 20, 0xA8, 0x00, 0xA8, 4);
     desktop5.AddChild(&sunset1);
    
    gathrillo::gui::Window sunset2(&desktop5, 90, 260 , 120, 20, 5, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&sunset2);
desktop5.Draw(&vga5); 
    
break;

}     
              
 
              



    

if(i == 0) {              

case 0x39:
 j = j + 1;    
if( j == 1){
    
    y = y - 15;
    j = j + 1;
    x = x + 15;
 
    if(j > 2) {
       j = 0; 
    }
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320, 200, 0x00,0x00,0xA8);            
    
    
   gathrillo::gui::Window enemy(&desktop5, 90, enemypos , y + 75, 10, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&enemy);

    
    
    

gathrillo::gui::Window pixel1(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
  gathrillo::gui::Window pixel1b(&pixel1, 90, 150, 38, 5, 12, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel1b);
    
    gathrillo::gui::Window pixel1c(&pixel1, 90, 155,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel1c);
    
  gathrillo::gui::Window pixel2(&pixel1, 90, 151,43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
     gathrillo::gui::Window pixel3(&pixel1, 90, 151,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
     gathrillo::gui::Window pixel4(&pixel1, 90, 151,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
    
   
    
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 157, 43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 156,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 155,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
    
    
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 154,40, 1, 14, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 154,54, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 154,53, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 154,52, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 154,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 151,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 158,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 153,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 150,40, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    

    //legs
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 147,64, 10, 3, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 146,64, 8, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    //
     gathrillo::gui::Window pixel27(&pixel1, 90, 152,49, 8, 2, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 152,50, 8, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
 
    

 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 155,50, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 153,51, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 153,39, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
     gathrillo::gui::Window ground(&desktop5, 90, 0,140, 320, 60, 0xA2, 0xA2, 0xA2, 4);
     desktop5.AddChild(&ground);  
    
      //terrain
    
    gathrillo::gui::Window platform1(&desktop5, 90, 45 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform1);
    
    
    
    gathrillo::gui::Window platform3(&desktop5, 90, 260 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform3);
    
    
    //sun
     gathrillo::gui::Window sun(&desktop5, 90, 280 , 0, 40, 40, 0x00, 0xA8, 0xA8, 4);
     desktop5.AddChild(&sun);
    
    gathrillo::gui::Window sunset1(&desktop5, 90, 0 , 0, 320, 20, 0xA8, 0x00, 0xA8, 4);
     desktop5.AddChild(&sunset1);
    
    gathrillo::gui::Window sunset2(&desktop5, 90, 260 , 120, 20, 5, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&sunset2);
   
  desktop5.Draw(&vga5);  
 
}
    
    if( j == 2){
    
    y = y + 15 ;
        x = x + 15;
        j = 0;
 
  VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320, 200, 0x00,0x00,0xA8);            
    
    
   
    
    
    
    gathrillo::gui::Window enemy(&desktop5, 90, enemypos , y + 60, 10, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&enemy); 
    

gathrillo::gui::Window pixel1(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
  gathrillo::gui::Window pixel1b(&pixel1, 90, 150, 38, 5, 12, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel1b);
    
    gathrillo::gui::Window pixel1c(&pixel1, 90, 155,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel1c);
    
  gathrillo::gui::Window pixel2(&pixel1, 90, 151,43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
     gathrillo::gui::Window pixel3(&pixel1, 90, 151,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
     gathrillo::gui::Window pixel4(&pixel1, 90, 151,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
    
   
    
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 157, 43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 156,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 155,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
    
    
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 154,40, 1, 14, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 154,54, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 154,53, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 154,52, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 154,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 151,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 158,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 153,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 150,40, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    

    //legs
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 155,64, 3, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 154,64, 1, 8, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    //
     gathrillo::gui::Window pixel27(&pixel1, 90, 152,49, 8, 2, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 152,50, 8, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
 
    

 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 155,50, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 153,51, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 153,39, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
     gathrillo::gui::Window ground(&desktop5, 90, 0,140, 320, 60, 0xA2, 0xA2, 0xA2, 4);
     desktop5.AddChild(&ground); 
      
      //terrain
    
    gathrillo::gui::Window platform1(&desktop5, 90, 45 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform1);
    
    
    
    gathrillo::gui::Window platform3(&desktop5, 90, 260 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform3);
    
    
    //sun
     gathrillo::gui::Window sun(&desktop5, 90, 280 , 0, 40, 40, 0x00, 0xA8, 0xA8, 4);
     desktop5.AddChild(&sun);
    
    gathrillo::gui::Window sunset1(&desktop5, 90, 0 , 0, 320, 20, 0xA8, 0x00, 0xA8, 4);
     desktop5.AddChild(&sunset1);
    
    gathrillo::gui::Window sunset2(&desktop5, 90, 260 , 120, 20, 5, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&sunset2);
   
  desktop5.Draw(&vga5);  

}
break;            
}
//case 0x4D:
  //ok = false;
//  break;
            
              
    //}
             
             
                   
if(i == 0) {              

case 0x4B:
x = x - 4;


        
   if( enemypos > 0 && enemypos < 199 && change == 0) {
    
    enemypos = enemypos + 5;
       
       

    
}

 
   if( enemypos > 0 && enemypos < 199 && change == 1) {
    
    enemypos = enemypos - 5;
       
     
}

if(enemypos >= 199) {
    
     change = 1;
}
  
  if(enemypos <= 0) {
    
     change = 0;
} 
   

   
 

   
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320, 200, 0x00,0x00,0xA8);            
    
    
    
    
    
    
    
   gathrillo::gui::Window enemy(&desktop5, 90, enemypos , y + 60, 10, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&enemy);

    
    

gathrillo::gui::Window pixel1(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
  gathrillo::gui::Window pixel1b(&pixel1, 90, 155, 38, 5, 12, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel1b);
    
    gathrillo::gui::Window pixel1c(&pixel1, 90, 155,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel1c);
    
  gathrillo::gui::Window pixel2(&pixel1, 90, 151,43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
     gathrillo::gui::Window pixel3(&pixel1, 90, 151,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
     gathrillo::gui::Window pixel4(&pixel1, 90, 151,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
    
    
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 155,40, 1, 15, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     gathrillo::gui::Window pixel14(&pixel1, 90, 160,49, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel14);
    
     gathrillo::gui::Window pixel15(&pixel1, 90, 159,50, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel15);
    
     gathrillo::gui::Window pixel16(&pixel1, 90, 158,51, 1, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel16);
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 154,54, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 154,53, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 154,52, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 154,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 151,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 158,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 153,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 150,40, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    

    //legs
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 155,64, 3, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 154,64, 1, 8, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    //
     gathrillo::gui::Window pixel27(&pixel1, 90, 152,49, 8, 2, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 152,50, 8, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
 
    

 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 155,50, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 153,51, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 153,39, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
   gathrillo::gui::Window ground(&desktop5, 90, 0,140, 320, 60, 0xA2, 0xA2, 0xA2, 4);
     desktop5.AddChild(&ground); 
   
      //terrain
    
    gathrillo::gui::Window platform1(&desktop5, 90, 45 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform1);
    
    
    
    gathrillo::gui::Window platform3(&desktop5, 90, 260 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform3);
    
    
    //sun
     gathrillo::gui::Window sun(&desktop5, 90, 280 , 0, 40, 40, 0x00, 0xA8, 0xA8, 4);
     desktop5.AddChild(&sun);
    
    gathrillo::gui::Window sunset1(&desktop5, 90, 0 , 0, 320, 20, 0xA8, 0x00, 0xA8, 4);
     desktop5.AddChild(&sunset1);
    
    gathrillo::gui::Window sunset2(&desktop5, 90, 260 , 120, 20, 5, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&sunset2);
   
  desktop5.Draw(&vga5);  

break;

}  
   
   
              
                   
if(i == 0) {              

case 0x4D:
x = x + 4;




     
   if( enemypos > 0 && enemypos < 199 && change == 0) {
    
    enemypos = enemypos + 5;
       
       

    
}

 
   if( enemypos > 0 && enemypos < 199 && change == 1) {
    
    enemypos = enemypos - 5;
       
     
}

if(enemypos >= 199) {
    
     change = 1;
}
  
  if(enemypos <= 0) {
    
     change = 0;
} 
   

   
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(720, 480, 0x00,0x00,0xA8);            
    
     

   
    
  gathrillo::gui::Window enemy(&desktop5, 90, enemypos , y + 60, 10, 10, 0xA8, 0x00, 0x00, 4);
     desktop5.AddChild(&enemy);
  
    

gathrillo::gui::Window pixel1(&desktop5, 90, x , y, 0, 1, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&pixel1);
    
  gathrillo::gui::Window pixel1b(&pixel1, 90, 150, 38, 5, 12, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel1b);
    
    gathrillo::gui::Window pixel1c(&pixel1, 90, 155,55, 1, 10, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel1c);
    
  gathrillo::gui::Window pixel2(&pixel1, 90, 151,43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel2);
    
     gathrillo::gui::Window pixel3(&pixel1, 90, 151,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel3);
    
     gathrillo::gui::Window pixel4(&pixel1, 90, 151,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel4);
    
    
   
    
    
    
    
  
    
    gathrillo::gui::Window pixel10(&pixel1, 90, 157, 43, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel10);

     gathrillo::gui::Window pixel11(&pixel1, 90, 156,44, 3, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel11);
    
     gathrillo::gui::Window pixel12(&pixel1, 90, 155,45, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel12);
    
    
    
    
     gathrillo::gui::Window pixel13(&pixel1, 90, 154,40, 1, 14, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel13);
    
    
    
     
    
    gathrillo::gui::Window pixel17(&pixel1, 90, 154,54, 4, 10, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel17);
    
    gathrillo::gui::Window pixel18(&pixel1, 90, 154,53, 4, 1, 0xFE, 0xFE, 0xFE, 4);
     pixel1.AddChild(&pixel18);
    
     gathrillo::gui::Window pixel19(&pixel1, 90, 154,52, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel19);
    
    
    
    
    gathrillo::gui::Window pixel20(&pixel1, 90, 154,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel20);
    
    gathrillo::gui::Window pixel21(&pixel1, 90, 151,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel21);
    
    
    gathrillo::gui::Window pixel22(&pixel1, 90, 158,39, 2, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel22);
    
    gathrillo::gui::Window pixel23(&pixel1, 90, 153,38, 4, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel23);
    
     gathrillo::gui::Window pixel24(&pixel1, 90, 150,40, 10, 9, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel24);
    
    

    //legs
    
    gathrillo::gui::Window pixel25(&pixel1, 90, 155,64, 3, 10, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel25);
    
    gathrillo::gui::Window pixel26(&pixel1, 90, 154,64, 1, 8, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel26);
    //
     gathrillo::gui::Window pixel27(&pixel1, 90, 152,49, 8, 2, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel27);

     gathrillo::gui::Window pixel28(&pixel1, 90, 152,50, 8, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel28);
    
 
    

 
     
    gathrillo::gui::Window pixel31(&pixel1, 90, 155,50, 5, 1, 0x00, 0x00, 0x00, 4);
     pixel1.AddChild(&pixel31);
    
    gathrillo::gui::Window pixel32(&pixel1, 90, 153,51, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel32);
    
     gathrillo::gui::Window pixel33(&pixel1, 90, 153,39, 6, 1, 0xA1, 0xA1, 0xA1, 4);
     pixel1.AddChild(&pixel33);
    
      
     gathrillo::gui::Window ground(&desktop5, 90, 0,140, 320, 60, 0xA2, 0xA2, 0xA2, 4);
     desktop5.AddChild(&ground); 
   
    
    
    
    
    //terrain
    
    gathrillo::gui::Window platform1(&desktop5, 90, 45 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform1);
    
    
    
    gathrillo::gui::Window platform3(&desktop5, 90, 260 , 120, 20, 5, 0xFE, 0xFE, 0xFE, 4);
     desktop5.AddChild(&platform3);
    
    
    
    
    //sun
     gathrillo::gui::Window sun(&desktop5, 90, 280 , 0, 40, 40, 0x00, 0xA8, 0xA8, 4);
     desktop5.AddChild(&sun);
    
    gathrillo::gui::Window sunset1(&desktop5, 90, 0 , 0, 320, 20, 0xA8, 0x00, 0xA8, 4);
     desktop5.AddChild(&sunset1);
    
    gathrillo::gui::Window sunset2(&desktop5, 90, 260 , 120, 20, 5, 0x00, 0x00, 0x00, 4);
     desktop5.AddChild(&sunset2);
    
   
  desktop5.Draw(&vga5);  

   
    

break;

}   


 
    
           

     
              
              
              
              
    
      }
             
}
      return esp;
}
 


