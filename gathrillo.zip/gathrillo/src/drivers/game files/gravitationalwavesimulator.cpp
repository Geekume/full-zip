#include <drivers/game.h>
#include <drivers/vga.h>
#include <hardwarecommunication/pci.h>
#include <gui/desktop.h>
#include <gui/window.h>

using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;
GameEventHandler::GameEventHandler()
{
    
}
  
void GameEventHandler::OnGameKeyDown(char)
{
    
}
void GameEventHandler::OnGameKeyUp(char)
{
    
}







  GameDriver::GameDriver(InterruptManager* manager, GameEventHandler *handler)
  : InterruptHandler(0x21, manager),
    dataport(0x60),
    commandport(0x64)
  {
     this->handler = handler;
  }
  
  GameDriver::~GameDriver()
  {
  }
  
  void printf(char*);
  void printfHex(uint8_t);
  
  
  void GameDriver::Activate() 
  {
      while(commandport.Read() & 0x1)
          dataport.Read();
      commandport.Write(0xAE);
      commandport.Write(0x20);
      uint32_t status = (dataport.Read() | 1) & ~0x10;
      commandport.Write(0x60);
      dataport.Write(status);
      dataport.Write(0xf4);
  }
  
    


  uint32_t  GameDriver::HandleInterrupt(uint32_t esp)
  {
    
      uint8_t key = dataport.Read();
      if(handler == 0) 
          return esp;
      
 VideoGraphicsArray vga;
    
  //  drvManager.ActivateAll();
    
    vga.SetMode(320,200,8);
      
      int lin1;
      int lin2;
      int lin3;
      int lin4;
      int i;
      int shift;
      int x;
      int reverse1;
      int reverse2;
      int reverse3;
      int reverse4;
      int face1AY;
      int face1AX;
      int face1BY;
      int face1BX;
      double x1;
      int y;
      int j;
      int c;
      int d;
      int e;
      int ok;
      int f;
      int energy;
      int boi;
      int level;
      int wavex;
      int wavey;
      int wave_count;
      
         if(key < 0x80)
      { 
      switch(key)
      {
    
 
// case 0x2A: case 0x3A: shift = true; break;
 //case 0xAA: case 0xB6: shift = false; break;       
    
        
   default:
    {
    case 0x45: break;
     printf("KEYBOARD 0x");
     printfHex(key);
     break;
      }
  


 
   
if(i==0) {
case 0x1C:          
 VideoGraphicsArray vga5;
vga5.SetMode(320,180,8);
gathrillo::gui::Desktop desktop5(320, 200, 0x00,0x00,0x00);            
 
      
      gathrillo::gui::Window wave(&desktop5, -20, 0, 320, 200, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave);
    desktop5.Draw(&vga5); 
    
lin1 = 50;
lin2 = 65;
lin3 = 65;
lin4 = 80;
reverse1 = 1;
reverse2 = 1;
reverse3 = 1;
reverse4 = 1;
x = .001;
y = 2;
j = 1;
c = 0xFF;
d = 0x00;
e = 0xA8;
ok = 2; 
f = 0;
energy = 2;
level = 0;
wavex = 15;
wavey = 164;
wave_count = 2;

  break;
    
}
 
if(i==0) {              
  
case 0x02:

if(level < 70) {

f = 26;    
}
break;
                       
}             
if(i == 0) {              
  
case 0x03:
    
if (level > 69){
boi = 51;    
f = 0;
}
break;
                       
}

if(i == 0) {              
  
case 0x04:
  
if(level > 128) {   
    f = f + 77;    
    
    
}
break;
                       
}
              
if(i == 0) {              
  
case 0x05:
  
if(level > 169) {   
    boi += 77;    
    
    
}
break;
                       
}              

/*              
if(i == 0) {              
  
case 0x08:
  
level = 72;
    
break;
                       
}
              
if(i == 0) {              
  
case 0x09:
  
level = 132;
    
break;
                       
}
              
if(i == 0) {              
  
case 0x10:
  
level = 192;
    
break;
                       
}
*/
              
              
              
                   
if(i == 0) {              
  
    
case 0x4D:
   
    
while(f > 25 && f < 75){    
    
   
VideoGraphicsArray vga5;
vga5.SetMode(320,180,8);
gathrillo::gui::Desktop desktop5(320,160, 0x00,0x00,0x00);            
 
      
      gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
    
if(lin3 < 25) {
     
d = 0xFF;
c = 0x00;

   j = 2;
    
     }
    
if(lin3 > 70) {
     
 c = 0xFF;
 d = 0x00;
 
  j = 1;
    
     }
    if(j == 1) {
      
      
    
        
        if(wavey < 156 && wave_count == 2) {

  wave_count = 1;
}
else if (wavey > 171  && wave_count == 1) {

 wave_count = 2;
}

else if (wave_count == 2 ){
  wavey -= 4;
  wavex += 2;
}
else if (wave_count == 1){
wavey += 4;
wavex += 2;
}
   
     
        lin3 = lin3 - 4; 
            
         energy = energy + 2;  
         gathrillo::gui::Window moon(&desktop5, lin3+100, 84, 1, 1, c, c, c);
     desktop5.AddChild(&moon);
      
        
         gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
        gathrillo::gui::Window Energy_icon_con_black(&desktop5, 0, -20 , 320, 10, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
     
    }
     if(energy > 60) {
    level = level + 5;
    energy = 2;
      
           gathrillo::gui::Window Energy_icon_con_black(&desktop5, 5, -20 , 62, 5, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
         
      
           
      
     //  desktop5.Draw(&vga5); 
    
        
   }

   if(j == 2) {
       
       if(wavey < 156 && wave_count == 2) {

  wave_count = 1;
}
else if (wavey > 171  && wave_count == 1) {

 wave_count = 2;
}

else if (wave_count == 2 ){
  wavey -= 4;
  wavex += 2;
}
else if (wave_count == 1){
wavey += 4;
wavex += 2;
}
       
       
      lin3 += 4; 
       
     energy += 2;
        
      
       
       gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
       
       if(energy > 60) {
        level += 5;
    energy = 2;
      
           gathrillo::gui::Window Energy_icon_con_black(&desktop5, 5, -20 , 62, 5, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
          
     
          //desktop5.Draw(&vga5);   
    }
  
       
  if(level < 69) {
     
 
      

      
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);         
      
        if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
      
          gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
       if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
    // gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
    // desktop5.AddChild(&wave_icon_con); 
 
    desktop5.Draw(&vga5);
      
     
     
 }      
           
 if(level > 69 && level < 84) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
  //   gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
    // desktop5.AddChild(&wave_icon_con); 
         
    
    
    desktop5.Draw(&vga5);
     
 } 
    
if(level > 129 && level < 144) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     //gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     //desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
     
 } 
if(level > 189 && level < 204) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

    
    wavex /= 2;

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     //gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     //desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
     
 }  
       
         gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
       
    
       
         gathrillo::gui::Window moon(&desktop5, lin3+100, 84, 1, 1, d, d, d);
     desktop5.AddChild(&moon);
   }   
  
    
desktop5.Draw(&vga5);

    
    f = f + 1;

}


    
while(boi > 50 && boi < 100){    
    
   
VideoGraphicsArray vga5;
vga5.SetMode(320,180,8);
gathrillo::gui::Desktop desktop5(320,160, 0x00,0x00,0x00);            
 
      
      gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave);            
        
if(lin3 < 25) {
     
d = 0xFF;
c = 0x00;

   j = 2;
    
     }
    
if(lin3 > 70) {
     
 c = 0xFF;
 d = 0x00;
 
  j = 1;
    
     }
    if(j == 1) {
      
 if(wavey < 156 && wave_count == 2) {

  wave_count = 1;
}
else if (wavey > 171  && wave_count == 1) {

 wave_count = 2;
}

else if (wave_count == 2 ){
  wavey -= 2;
  wavex += 1;
}
else if (wave_count == 1){
wavey += 2;
wavex += 1;
}
    
        lin3 = lin3 - 4; 
            
         energy = energy + 2;  
         gathrillo::gui::Window moon(&desktop5, lin3+100, 84, 1, 1, c, c, c);
     desktop5.AddChild(&moon);
        
     gathrillo::gui::Window planet(&desktop5, 65+80, 80, 10, 10, 0x00, e , 0x00);
     desktop5.AddChild(&planet);
        
             
         gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
        gathrillo::gui::Window Energy_icon_con_black(&desktop5, 0, -20 , 320, 10, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
    }
     if(energy > 60) {
    level += 10;   
    energy = 2;
      
           gathrillo::gui::Window Energy_icon_con_black(&desktop5, 5, -20 , 62, 5, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
           
      
       desktop5.Draw(&vga5); 
    
        
   }

   if(j == 2) {
       
    if(wavey < 156 && wave_count == 2) {

  wave_count = 1;
}
else if (wavey > 171  && wave_count == 1) {

 wave_count = 2;
}

else if (wave_count == 2 ){
  wavey -= 2;
  wavex += 1;
}
else if (wave_count == 1){
wavey += 2;
wavex += 1;
}     
  
       
if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
      
          gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
       if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      }        
       
       
      lin3 = lin3 + 4; 
       
    energy = energy + 2; 
       
    if(energy > 60) {
    level = level + 10;
    energy = 2;
      
           gathrillo::gui::Window Energy_icon_con_black(&desktop5, 5, -20 , 62, 5, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
          
        
            
desktop5.Draw(&vga5);
       
        
    }
        
    if(level < 69) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
     level = level; 
 }          
       
       
                  
 if(level > 69 && level < 84) {
  
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            
   if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
      
          gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
       if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
     
     
     
    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     //gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     //desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
      level = level;
     
 } 
    
if(level > 129 && level < 144) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
     level = level;
     
 } 
if(level > 189 && level < 204) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
     level = level;
     
 } 
   
         gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
       
     gathrillo::gui::Window planet(&desktop5, 65+80, 80, 10, 10, 0x00, e, 0x00);
     desktop5.AddChild(&planet);
       
         gathrillo::gui::Window moon(&desktop5, lin3+100, 84, 1, 1, d, d, d);
     desktop5.AddChild(&moon);
   }   
   
    
    
desktop5.Draw(&vga5);

    
    boi = boi + 1;

}
    
    
    
    
//blackhole    
while(f > 76 && f < 125){    
 
VideoGraphicsArray vga5;
vga5.SetMode(320,180,8);
gathrillo::gui::Desktop desktop5(320,160, 0x00,0x00,0x00);            
 
      
      gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave);            
        
if(lin3 < 25) {
     
d = 0xFF;
c = 0x00;

   j = 2;
    
     }
    
if(lin3 > 70) {
     
 c = 0xFF;
 d = 0x00;
 
  j = 1;
    
     }
    if(j == 1) {
      
 if(wavey < 156 && wave_count == 2) {

  wave_count = 1;
}
else if (wavey > 171  && wave_count == 1) {

 wave_count = 2;
}

else if (wave_count == 2 ){
  wavey -= 4;
  wavex += 1;
}
else if (wave_count == 1){
wavey += 4;
wavex += 1;
}
    
        lin3 = lin3 - 4; 
            
         energy = energy + 2;  
         gathrillo::gui::Window moon(&desktop5, lin3+100, 84, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon);
        
     gathrillo::gui::Window planet(&desktop5, 65+80, 80, 10, 10, 0xFD, 0xFD , 0xFD);
     desktop5.AddChild(&planet);
        
           
         gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
        gathrillo::gui::Window Energy_icon_con_black(&desktop5, 0, -20 , 320, 10, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
    }
     if(energy > 60) {
    level += 10;   
    energy = 2;
      
           gathrillo::gui::Window Energy_icon_con_black(&desktop5, 5, -20 , 62, 5, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
           
      
       desktop5.Draw(&vga5); 
    
        
   }

   if(j == 2) {
       
    if(wavey < 156 && wave_count == 2) {

  wave_count = 1;
}
else if (wavey > 171  && wave_count == 1) {

 wave_count = 2;
}

else if (wave_count == 2 ){
  wavey -= 4;
  wavex += 1;
}
else if (wave_count == 1){
wavey += 4;
wavex += 1;
}     
       
       
       
       if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
      
          gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
       if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
       
      lin3 = lin3 + 4; 
       
    energy = energy + 2; 
       energy = energy + 2;  
       
         gathrillo::gui::Window moon2(&desktop5, lin3+100, 84, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon2);
        
     gathrillo::gui::Window planet2(&desktop5, 65+80, 80, 10, 10, 0xFD, 0xFD , 0xFD);
     desktop5.AddChild(&planet2);
       
       
           if(level > 169){
            
             gathrillo::gui::Window ok(&desktop5, 0, 0, 320, 200, 0x00, 0xA8 , 0x00);
     desktop5.AddChild(&ok);
        }
    if(energy > 60) {
    level = level + 10;
    energy = 2;
      
           gathrillo::gui::Window Energy_icon_con_black(&desktop5, 5, -20 , 62, 5, 0x00, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con_black);
          
        
            
desktop5.Draw(&vga5);
       
        
    } 
       
    if(level < 69) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&blackhole_icon_con);
    
    
    // gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     //desktop5.AddChild(&moon);
    
    //gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
     //desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
     level = level; 
 }          
       

              
                  
 if(level > 69 && level < 84) {
  
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            
   if(wavex > 10) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
      
          gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
       if(wavex > 10) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
     
    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&blackhole_icon_con);
    
    
    // gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     //desktop5.AddChild(&moon);
    
    //gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0x00, 0xA8 , 0x00);
    // desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
     //gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     //desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
      level = level;
     
 } 
    
if(level > 129 && level < 144) {
     
  
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            

 
    
     if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
      
          gathrillo::gui::Window wave(&desktop5, wavex, wavey, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&wave); 
       if(wavex > 56) {
          
         gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 30, 0x00, 0x00, 0x00);
         desktop5.AddChild(&wave_icon_con); 

          wavex = 15;
            
        
    desktop5.Draw(&vga5);    
      } 
      
    
    
    gathrillo::gui::Window dot1(&desktop5, 281, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot1);
    
    gathrillo::gui::Window dot2(&desktop5, 279, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot2);
    
    gathrillo::gui::Window dot3(&desktop5, 277, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&dot3);
    
     gathrillo::gui::Window blackhole(&desktop5, 225, 158, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&blackhole);
      
     gathrillo::gui::Window blackhole_icon_con(&desktop5, 220, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&blackhole_icon_con);
    
    
     gathrillo::gui::Window moon(&desktop5, 129, 162, 1, 1, 0xFF, 0xFF, 0xFF);
     desktop5.AddChild(&moon);
    
    gathrillo::gui::Window planet(&desktop5, 175, 158, 10, 10, 0xFD, 0xFD , 0xFD);
     desktop5.AddChild(&planet);
    
     gathrillo::gui::Window moon_icon_con(&desktop5, 170, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&moon_icon_con);
    
    
    
     gathrillo::gui::Window planet_icon_con(&desktop5, 270, 150, 20, 25, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&planet_icon_con);
    
     gathrillo::gui::Window asteroid_icon_con(&desktop5, 120, 150, 20, 25, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&asteroid_icon_con);
    
     gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
    
    // gathrillo::gui::Window wave_icon_con(&desktop5, 10, 150, 83, 25, 0xA8, 0x00, 0xA8);
     //desktop5.AddChild(&wave_icon_con); 
    
    desktop5.Draw(&vga5);
     level = level;
    
    
   
     
 } 
if(level > 200 && level < 250) {
     
  while(1) {
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0xA8,0x00);            

    gathrillo::gui::Window dot1(&desktop5, -20, 0, 320, 200, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&dot1);
    
    
    desktop5.Draw(&vga5);
     level = level;
  }
 } 
   
         gathrillo::gui::Window Energy_icon_con(&desktop5, 5, -20 , energy, 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&Energy_icon_con);
       
    
   }   
   
    
    
desktop5.Draw(&vga5);

    
    boi = boi + 1;

}
 

}
     }
                           
}
      return esp;
}
 


