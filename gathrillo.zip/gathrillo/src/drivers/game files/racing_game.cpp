#include <drivers/game.h>
#include <hardwarecommunication/pci.h>
#include <gui/desktop.h>
#include <gui/window.h>

using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;
GameEventHandler::GameEventHandler()
{
    
}
  
void GameEventHandler::OnGameKeyDown(char)
{
    
}
void GameEventHandler::OnGameKeyUp(char)
{
    
}







  GameDriver::GameDriver(InterruptManager* manager, GameEventHandler *handler)
  : InterruptHandler(0x21, manager),
    dataport(0x60),
    commandport(0x64)
  {
     this->handler = handler;
  }
  
  GameDriver::~GameDriver()
  {
  }
  
  void printf(char*);
  void printfHex(uint8_t);
  
  
  void GameDriver::Activate() 
  {
      if(commandport.Read() & 0x1)
          dataport.Read();
      commandport.Write(0xAE);
      commandport.Write(0x20);
      uint32_t status = (dataport.Read() | 1) & ~0x10;
      commandport.Write(0x60);
      dataport.Write(status);
      dataport.Write(0xf4);
  }
  
    


  uint32_t  GameDriver::HandleInterrupt(uint32_t esp)
  {
    
      uint8_t key = dataport.Read();
      if(handler == 0) 
          return esp;
      
      static bool shift = false;
      static bool pci = false;
      static bool black = false;
   
      static int i = 0;
      
      // 3D ENVIROMENTAL
      int x;
      int y;
      int z;
      int e;
      int rot;
      int angle;
      int plane1x;
      int plane2x;
      int plane3x;
      int plane4x;
      int plane5x;
      int plane6x;
      int plane7x;
      int plane8x;
      int plane9x;
      
      int plane1y;
      int plane2y;
      int plane3y;
      int plane4y;
      int plane5y;
      int plane6y;
      int plane7y;
      int plane8y;
      int plane9y;
      int size;
      int c;
      int d;
      int side;
      int j;
      
    //POLYFILL 
      int v1x;
      int v2x;
      int v3x;
      int v4x;
      
      int v1y;
      int v2y;
      int v3y;
      int v4y;
      
      
      int f;
      int n;
      int v;
     
    // POLYGON
      int vertex;
      int pointx;
      int pointy;
      int count;
      int count2;
      int point1x;
      int point1y;
      int point2x; 
      int point2y;
      //misc
      int test;
      int fire;
      int health;
      int world;
      int road;
      int roadY;
      int roadsize;
      int shadelight;
      int shademedium;
      int shadedark;
      int shadebright;
      int drive;
      int ok;
         if(key < 0x80)
      { 
      switch(key)
      {
    
    
            
          case 0x01: if(pci) 
    break;
              
    
    
    
   
// case 0x2A: case 0x3A: shift = true; break;
 //case 0xAA: case 0xB6: shift = false; break;       
    
        
   default:
    {
    case 0x45: break;
     printf("KEYBOARD 0x");
     printfHex(key);
     break;
      }
  


    
   
//when world is 1-10 it is the first section if world is 11 itr is on the second section and it goes on ect.
           
 count = 0; 
 count2 = 0;
  if(i == 0) {              

case 0x108:

      
 
     
     
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1, 1, 0x00,0x00,0x00);            

  count = count + 1;
    
   
   
    if(count >= 20  ) {

    count = 20;
     // Main Screen
     gathrillo::gui::Window connect(&desktop5, pointx - count / 2 + 1, point1y, count - 2, 1, 0x00, 0xA8, 0x00);
    desktop5.AddChild(&connect); 
  
        
        
    
}
  
      
   if(count <= -20) {

    count = 20;
     // Main Screen
     gathrillo::gui::Window connect(&desktop5, pointx - count / 2 + 1, point1y, count - 2, 1, 0x00, 0xA8, 0x00);
    desktop5.AddChild(&connect); 
  
        
        
    
}  
      
  if(count < 20) {  

 // Main Screen
     gathrillo::gui::Window vertex(&desktop5,  pointx = 124, pointy = 67, 1, 1, 0x00, 0xA8, 0x00);
    desktop5.AddChild(&vertex);
     
   
      gathrillo::gui::Window point1(&desktop5, point1x = pointx + count - 10, point1y = pointy - count + 10, 1, 1, 0x00, 0xA8, 0x00);
    desktop5.AddChild(&point1);
    
        
     gathrillo::gui::Window point2(&desktop5,  point2x = pointx - count + 10, point2y = pointy - count+ 10, 1, 1, 0x00, 0xA8, 0x00);
    desktop5.AddChild(&point2);
 
      
   
  
  
  }
desktop5.Draw(&vga5); 

  

break;

}
            
            
       

              
              
if(i == 0) {              

case 0x1c:
 x = 130; 
 y = 70;
 z = 0;
 angle = 0;
 size = z + 50;
 side = 0xAF;
 c = 0x00;
 d = 0x00;
 e = 0x00;
 fire = 0;
health = 1;
      v1x = 0;
      v2x = 0;
      v3x = 0;
      v4x = 0;
    
      v1y = 0;
      v2y = 0;
      v3y = 0;
      v4y = 0;
          
      f = 10;
    
   
    //if (v1y == 5) {
        n = 5;
    //}  
      v = 0;
      j = 0;
     world = 1;
     road = 90;
     roadsize = 150;
     roadY = 160;
    
   shadelight = 0xFD;
   shademedium = 0xFE;
   shadedark = 0x38;
   shadebright = 0xFF;
   drive = 0;
   ok = 0;
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320, 200, 0xA8,0x00,0xA8);            


     
desktop5.Draw(&vga5); 
    
    

break;
    
}
  
              
              
              
      
              
              
              
              
              
              
              
              
              
 if(i == 0) {              

case 0x08:

      
 
 
     
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1, 1, 0x00,0x00,0x00);            


    
   
   
   

  
     // Main Screen
gathrillo::gui::Window pixel1(&desktop5, 150,40, 10, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&pixel1);
        
    gathrillo::gui::Window pixel2(&desktop5, 150,40, 1, 10, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&pixel2);
        
        gathrillo::gui::Window pixel3(&desktop5, 160,40, 1, 11, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&pixel3);
    
     
        gathrillo::gui::Window pixel4(&desktop5, 200,200, 1, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&pixel4);
        
        gathrillo::gui::Window pixel5(&desktop5, 150,50, 10, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&pixel5);
        

  
   
  
  
  
desktop5.Draw(&vga5); 

  

break;

}
                   
 if(i == 0) {              

case 0x109:
 

     
     
     
     
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1, 1, 0x00,0x00,0x00);            
  f = f + 1;
  v = v - 0;
  

  
 // Main Screen
     gathrillo::gui::Window va(&desktop5,  v1x = 10, v1y = 10, 1, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&va);
     
     
     
     
     gathrillo::gui::Window vb(&desktop5,  v2x = 20,  v2y = 5, 1, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&vb);
     
   
     
     gathrillo::gui::Window vc(&desktop5,  v3x = 10, v3y = 20, 1, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&vc);
     
     gathrillo::gui::Window vd(&desktop5,  v4x = 20, v4y = 20, 1, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&vd);
     
      
    
     if(v1x != v2x) {
         
         if(v2y == 5) {
             
            v2x = v2x + v;
   
             
         }
     }
       
     if(f >= v2x + 2 && n != v4y + 1) {
        n = n + 1;
        f = v1x;
     }
 
     
    if(f < v2x + 2 && n != v4y + 1) {
       
     
     gathrillo::gui::Window line1(&desktop5,  f - 1, n, 1, 1, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&line1);
        
         
     }
   
     
  
     
  
     
desktop5.Draw(&vga5); 
break;

}              
 
 if(i == 0) {              

case 0x04:


angle = angle - 45;

if(angle == -90) {
         
side = 0xA8;
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
     // Main Screen
 gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);    
         
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
    desktop5.Draw(&vga5);
     }
   
  

   
   
  if(angle == -180){
angle = 0;
side = 0xAF;

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
     // Main Screen
 gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

      
    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);  
      
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
    desktop5.Draw(&vga5);
     }     
        
     
     
     
if(angle == -135)  {
  
   
   

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00);            
  

   
     
  gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);  
     
     //new face
     
     
     gathrillo::gui::Window face(&desktop5, plane1x + (size/2), plane1y, size/2, plane1y/2 + 15, 0x00, 0xAF, 0x00);
     desktop5.AddChild(&face);   
     
     
      
     gathrillo::gui::Window face2(&desktop5, plane2x + (size/2)-4, plane2y, size/2 - 5, plane2y/2 + 5, 0xAF, 0x00, 0x00);
     desktop5.AddChild(&face2); 
     
     
        
     gathrillo::gui::Window face3(&desktop5, plane3x + (size/2)-3, plane3y, size/2 - 5, plane3y/2 + 5 , 0x00, 0x00, 0xAF);
     desktop5.AddChild(&face3);  
        
        
    
     
 // Main Screen
    if(z < 60) {
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
 
}

    desktop5.Draw(&vga5);
       }
     
     
     
if(angle == -45)  {
  
   
   

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00);            
  

   
     gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);  
  
     
     //new face
     
     
     gathrillo::gui::Window face(&desktop5, plane1x + (size/2), plane1y, size/2, plane1y/2 + 15, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&face);   
     
     
      
     gathrillo::gui::Window face2(&desktop5, plane2x + (size/2)-4, plane2y, size/2 - 5, plane2y/2 + 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&face2); 
     
     
        
     gathrillo::gui::Window face3(&desktop5, plane3x + (size/2)-3, plane3y, size/2 - 5, plane3y/2 + 5 , 0x00, 0x00, 0xA8);
     desktop5.AddChild(&face3);  
        
        
    
     
 // Main Screen
    if(z < 60) {
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
 
}
    

      
desktop5.Draw(&vga5);
   
       }

break;

}                
              
              
 if(i == 0) {              

case 0x05:


angle = angle + 45;

     if(angle == 180) {
         angle = 0;
         side = 0xAF;

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
     // Main Screen
 gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);    
         
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
    desktop5.Draw(&vga5);
     }
   
  

   
   
  if(angle == 90){
side = 0xA8;
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
     // Main Screen
 gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

      
    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);  
      
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
    desktop5.Draw(&vga5);
     }     
        
     
     
     
if(angle == 135)  {
  
   
   

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00);            
  

   
     
  gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);  
     
     //new face
     
     
     gathrillo::gui::Window face(&desktop5, plane1x + (size/2), plane1y, size/2, plane1y/2 + 15, 0x00, 0xAF, 0x00);
     desktop5.AddChild(&face);   
     
     
      
     gathrillo::gui::Window face2(&desktop5, plane2x + (size/2)-4, plane2y, size/2 - 5, plane2y/2 + 5, 0xAF, 0x00, 0x00);
     desktop5.AddChild(&face2); 
     
     
        
     gathrillo::gui::Window face3(&desktop5, plane3x + (size/2)-3, plane3y, size/2 - 5, plane3y/2 + 5 , 0x00, 0x00, 0xAF);
     desktop5.AddChild(&face3);  
        
        
    
     
 // Main Screen
    if(z < 60) {
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
 
}

    desktop5.Draw(&vga5);
       }
     
     
     
if(angle == 45)  {
  
   
   

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00);            
  

   
     gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);  
  
     
     //new face
     
     
     gathrillo::gui::Window face(&desktop5, plane1x + (size/2), plane1y, size/2, plane1y/2 + 15, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&face);   
     
     
      
     gathrillo::gui::Window face2(&desktop5, plane2x + (size/2)-4, plane2y, size/2 - 5, plane2y/2 + 5, 0xA8, 0x00, 0x00);
     desktop5.AddChild(&face2); 
     
     
        
     gathrillo::gui::Window face3(&desktop5, plane3x + (size/2)-3, plane3y, size/2 - 5, plane3y/2 + 5 , 0x00, 0x00, 0xA8);
     desktop5.AddChild(&face3);  
        
        
    
     
 // Main Screen
    if(z < 60) {
     gathrillo::gui::Window win5(&desktop5,  plane1x = x,  plane1y = y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, plane2x = x + 80, plane2y = y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, plane3x = x - 80 ,  plane3y = y , size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
 
}
    

      
desktop5.Draw(&vga5);
   
       }

break;

}                            
              

 
              
if(i == 0){
    
    case 0x06:
    
    
    
        
        fire = fire + 1;
        
        
    if(fire > 10) {
       
       size = 60;
       
   } 
    
    if(fire >20) {
       
       size = 120;
       
   } 
    
    if(fire > 30) {
       
       size = 150;
       
   } 
    
   
    
   break; 
}              
              
if(i == 0) {
    
case 0x02:


y = y - 4;


    

   

   
   

   
   

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00);   
    
     gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);
    
 // Main Screen
    if(z < 60) {
     gathrillo::gui::Window win5(&desktop5, x, y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, x + 80, y, size - 20, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, x - 80, y, size - 20, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
    
}
    

    
desktop5.Draw(&vga5);
 
break;   
}            
              
if(i == 0) {
    
case 0x03:


y = y + 4;


VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00);            

    gathrillo::gui::Window plane1(&desktop5, 147, 80, 10, 10, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 150, 80, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);
    
    
 // Main Screen
    if(z < 60) {
     gathrillo::gui::Window win5(&desktop5, x, y, size, size, c, side, 0x00);
     desktop5.AddChild(&win5);
    
     gathrillo::gui::Window win6(&desktop5, x + 80, y, size - 10, size - 10, side, d, 0x00);
     desktop5.AddChild(&win6);
    
     gathrillo::gui::Window win7(&desktop5, x - 80, y, size - 10, size - 10, 0x00, e, side);
     desktop5.AddChild(&win7);
    
}

    
    
    
desktop5.Draw(&vga5);
 
break;   
}            
              


    



            
   
//case 0x4D:
  //ok = false;
//  break;
            
              
    //}
             
 if(i == 0) {              

case 0x48:


z = z + 2;

size = z + 50;

    
ok = ok + 1;

   

   
   

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);            
  
    
  gathrillo::gui::Window plane1(&desktop5, 147, 120, 30, 20, 0x00, 0xA8, 0x00);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 157, 100, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);
   
     
     if(z > 50 && z < 150 && ok < 80) {
   VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);  
        road = road + 1;
         roadY = roadY + 1;
        roadsize = roadsize - 2;

           
         
          
         
         if(roadY + drive < 120 && roadY + drive > 118) {
             
             shadelight = 0xFE;
             
             
         }
          if(roadY + drive < 118) {
             
             shadelight = 0x00;
             
             
         }
          
         
    gathrillo::gui::Window plane2(&desktop5, road, roadY, roadsize + size - size, 1, shadelight, shadelight, shadelight);
     desktop5.AddChild(&plane2); 
          desktop5.Draw(&vga5);  
        
    
       ok = ok + 1;
         
     }
     
         
         
         if(ok == 80) {
      VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(1,1, 0x00,0x00,0x00);  
        road = road + 1;
         roadY = roadY - 1;
        roadsize = roadsize - 2;
           
         
          
         
         if(roadY + drive < 120 && roadY + drive > 118) {
             
             shadelight = 0xFE;
             
             
         }
          if(roadY + drive < 118) {
             
             shadelight = 0x00;
             
             
         }
         
         ok = ok + 1;
         
         }
         
         
          if(ok > 80) {
              
    
      VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00);  
        road = road + 1;
         roadY = roadY + 1;
        roadsize = roadsize - 2;
        x = x + 10;
           
         
          
         
         if(roadY + drive < 120 && roadY + drive > 118) {
             
             shadelight = 0xFE;
             
             
         }
          if(roadY + drive < 118) {
             
             shadelight = 0x00;
             
             
         
          }
         
    gathrillo::gui::Window plane2(&desktop5, road, roadY, roadsize + size - size, 1, shadelight, shadelight, shadelight);
     desktop5.AddChild(&plane2); 
          desktop5.Draw(&vga5);  
        
    
       ok = ok + 1;
       }
  
     
     if(z < 45) {
   
    
         
gathrillo::gui::Window ok(&desktop5, 0, 0, 3200, 2000, 0xA8, 0x00, 0xA8);
     desktop5.AddChild(&ok);  
      
   
       
       }
     
     
 if(z < 40) {
   if(world == 1){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }
    
         if(world == 2){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
    
         }
            
        
   
        
    if(world == 3 ) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
 
    }
        if(world == 4){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }    
      
       if(world == 5) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
 
    }
       if(world == 6){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
  if(world == 7) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
    }
       
        if(world == 8){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }  
       
       if(world == 9) {
      world = 1;
         gathrillo::gui::Window a(&desktop5, x - 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);   
 
    }
     
     
     }
        
        
      

    
    
    
desktop5.Draw(&vga5); 
  
    
break;

} 
            

if(i == 0) {              

case 0x50:


z = z - 2;


size = z + 50;
    
ok = ok + 1;
   

   
   

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
  
    
  gathrillo::gui::Window plane1(&desktop5, 147, 120, 30, 20, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 157, 100, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);
    
   if(z < 60) {
   if(world == 1){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }
    
         if(world == 2){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
        
   
        
    if(world == 3 ) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
 
    }
        if(world == 4){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }    
      
       if(world == 5) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
 
    }
       if(world == 6){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
  if(world == 7) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
    }
       
        if(world == 8){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }  
       
       if(world == 9) {
      world = 1;
         gathrillo::gui::Window a(&desktop5, x - 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);   
 
    }
       
     
     }
       
        
        
      


    
    
    
desktop5.Draw(&vga5); 
  
    
break;

} 
                          
                   

   
   
              
                   
 
case 0x4B:
 j = j + 1;    
if( j == 1){
    
 world = world - 1;

    j = j + 1;
   angle = angle + 5;
 
    
   
    if(j > 2) {
       j = 0; 
    }
        
        
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 

    
    
     if(z < 60) {
   if(world == 1){
     gathrillo::gui::Window a(&desktop5, x - 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }
    
         if(world == 2){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
        
   
        
    if(world == 3 ) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
 
    }
          if(world == 4){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }    
      
       if(world == 5) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
 
    }
         
    if(world == 6){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
         
  if(world == 7) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
    }
          if(world == 8){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }  
         
       if(world == 9) {
      world = 1;
         gathrillo::gui::Window a(&desktop5, x - 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);   
 
    }
     }
        
    
    
    
gathrillo::gui::Window plane1(&desktop5, 147, 120, 30, 20, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 140, 100, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);
 
         
     
    
   
  desktop5.Draw(&vga5);  
 

    
    
    if( j == 2){
    
        j = 0;
 
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
           
   if(z < 60) {
   if(world == 1){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }
    
         if(world == 2){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
        
   
        
    if(world == 3 ) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
 
    }
        if(world == 4){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }    
      
       if(world == 5) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
 
    }
       if(world == 6){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
  if(world == 7) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
    }
       
        if(world == 8){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }  
       
       if(world == 9) {
      world = 1;
         gathrillo::gui::Window a(&desktop5, x - 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);   
 
    }
     }
           
       
gathrillo::gui::Window plane1(&desktop5, 147, 120, 30, 20, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 157, 100, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);
 
   desktop5.Draw(&vga5); 
break;            
} 
    
    
    
}
 
case 0x4D:
 j = j + 1;    
if( j == 1){
    
 world = world + 1;
    j = j + 1;
   angle = angle + 5;
 
    
   
    if(j > 2) {
       j = 0; 
    }
        
        
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 

    
    
    if(z < 60) {
   if(world == 1){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }
    
         if(world == 2){
     gathrillo::gui::Window a(&desktop5, x - 120, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 100, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
        
   
        
    if(world == 3 ) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
 
    }
        
        if(world == 4){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }    
      
       if(world == 5) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
 
    }
        if(world == 6){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
  if(world == 7) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
    }
        
         if(world == 8){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }  
        
       if(world == 9) {
      world = 1;
         gathrillo::gui::Window a(&desktop5, x - 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);   
 
    }
     }
        
    
    
    
gathrillo::gui::Window plane1(&desktop5, 147, 120, 30, 20, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&plane1);    

    gathrillo::gui::Window plane2(&desktop5, 170, 100, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&plane2);
 
         
     
    
   
  desktop5.Draw(&vga5);  
 

    
    
    if( j == 2){
    
        j = 0;
 
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
           
     if(z < 60) {
        
    gathrillo::gui::Window savior1(&desktop5, 147, 120, 30, 20, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&savior1);   

    gathrillo::gui::Window savior2(&desktop5, 157, 100, 10, 10, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&savior2);
    
   if(world == 1){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }
         
          if(world == 2){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x + 10, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
        
    if(world == 3) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
 
    }
         
          if(world == 4){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }    
      
       if(world == 5) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
 
    }
         if(world == 6){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xAf);
     desktop5.AddChild(&b);  
      
   
       
       }    
  if(world == 7) {
        gathrillo::gui::Window a(&desktop5, x - 130, y, size + 270, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
    }
            if(world == 8){
     gathrillo::gui::Window a(&desktop5, x - 130, y, size + 100, size, 0x00, 0x00, 0xAF);
     desktop5.AddChild(&a);
         
         
gathrillo::gui::Window b(&desktop5, x, y, size + 150, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);  
      
   
       
       }  
         
       if(world == 9) {
      world = 1;
         gathrillo::gui::Window a(&desktop5, x - 120, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&a);
         
         
           
gathrillo::gui::Window b(&desktop5, x + 130, y, size + 30, size, 0x00, 0x00, 0xA8);
     desktop5.AddChild(&b);   
 
    }
     }
           
   
   desktop5.Draw(&vga5); 
break;            
} 
}         
              
              
              
              
              
    
      }
             
}
      return esp;
}
 


