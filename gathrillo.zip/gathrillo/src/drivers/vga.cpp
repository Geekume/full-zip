#include <drivers/vga.h>



using namespace gathrillo::common;
using namespace gathrillo::drivers;


 VideoGraphicsArray::VideoGraphicsArray() :
     
             miscPort(0x3c2),
             crtcIndexPort(0x3d4),
             crtcDataPort(0x3d5),
             sequencerIndexPort(0x3c4),
             sequencerDataPort(0x3c5),
             graphicsControllerIndexPort(0x3ce),
             graphicsControllerDataPort(0x3cf),
             attributeControllerIndexPort(0x3c0),
             attributeControllerReadPort(0x3c1),
             attributeControllerWritePort(0x3c0),
             attributeControllerResetPort(0x3da)
    

 
 {
    
 }

 VideoGraphicsArray::~VideoGraphicsArray()
 {
    
 }
 void VideoGraphicsArray::WriteRegisters(uint16_t* registers)
 {
        miscPort.Write(*(registers++));
     
     for(uint8_t i = 0; i < 5; i++)
     {
         
         sequencerIndexPort.Write(i);
         sequencerDataPort.Write(*(registers++));
         
     }
     
     //crtc
     
     crtcIndexPort.Write(0x03);
     crtcDataPort.Write(crtcDataPort.Read() | 0x80);
     crtcIndexPort.Write(0x11);
     crtcDataPort.Write(crtcDataPort.Read() & ~0x80);
     
     registers[0x03] = registers[0x03] | 0x80;
     registers[0x03] = registers[0x03] & ~ 0x80;
      for(uint8_t i = 0; i < 25; i++)
     {
         crtcIndexPort.Write(i);
         crtcDataPort.Write(*(registers++));
         
     }
     
     
     //graphics controller
        for(uint8_t i = 0; i < 9; i++)
     {
         
         graphicsControllerIndexPort.Write(i);
         graphicsControllerDataPort.Write(*(registers++));
            
            
   
         
     }
       
     //graphics controller
        for(uint8_t i = 0; i < 21; i++)
     {
         
         attributeControllerResetPort.Read();
         attributeControllerIndexPort.Write(i);
         attributeControllerWritePort.Write(*(registers++));
         
     }
       
         attributeControllerResetPort.Read();
         attributeControllerIndexPort.Write(0x20);
 }


       


bool VideoGraphicsArray::SupportsMode(uint32_t width, uint32_t height, uint32_t colordepth)
 {
    //if 1080p
    //return width == 1920 && height == 1080 && colordepth == 64;
    return width == 320 && height == 200 && colordepth == 8;
 }

void printf(char* str);
bool VideoGraphicsArray::SetMode(uint32_t width, uint32_t height, uint32_t colordepth)
 {
    if(!SupportsMode(width, height, colordepth))
        return false;
    
    
   short unsigned int g_320x200x256[] =
{
        
        
        
/* MISC */
	0x63,
/* SEQ */
	0x03, 0x01, 0x0F, 0x00, 0x0E,
/* CRTC */
	0x5F, 0x4F, 0x50, 0x82, 0x54, 0x80, 0xBF, 0x1F,
	0x00, 0x41, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x9C, 0x0E, 0x8F, 0x28,	0x40, 0x96, 0xB9, 0xA3,
	0xFF,
/* GC */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x05, 0x0F,
	0xFF,
/* AC */
	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
	0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
	0x41, 0x00, 0x0F, 0x00,	0x00
    };
    

    
    
    
    
    WriteRegisters(g_320x200x256);
    return true;
} 
    
//unsigned char g_720x480x16[] =
//{
///* MISC */
//	0xE7,
///* SEQ */
//	0x03, 0x01, 0x08, 0x00, 0x06,
///* CRTC */
//	0x6B, 0x59, 0x5A, 0x82, 0x60, 0x8D, 0x0B, 0x3E,
//	0x00, 0x40, 0x06, 0x07, 0x00, 0x00, 0x00, 0x00,
//	0xEA, 0x0C, 0xDF, 0x2D, 0x08, 0xE8, 0x05, 0xE3,
//	0xFF,
///* GC */
//	0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x05, 0x0F,
//	0xFF,
///* AC */
//	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
//	0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
//	0x01, 0x00, 0x0F, 0x00, 0x00,
//};
//
//WriteRegisters(g_720x480x16);
//    return true;
//} 


 uint8_t* VideoGraphicsArray::GetFrameBufferSegment()
 {
     graphicsControllerIndexPort.Write(0x86);
     uint8_t segmentNumber = ((graphicsControllerDataPort.Read() >> 2) & 0x03);
     switch(segmentNumber)
     {
         case 0: return (uint8_t*)0x00000;
         case 1: return (uint8_t*)0xA0000;
         case 2: return (uint8_t*)0xB0000;
         case 3: return (uint8_t*)0xB8000;
     }
 }
            
 void VideoGraphicsArray::PutPixel(int32_t x, int32_t y, uint16_t colorIndex)
 {
     if(x < 0 || 320 <= x 
     || y < 0 || 200 <= y)
         return;
     uint8_t* pixelAddress = GetFrameBufferSegment() + 320*y + x;
     *pixelAddress = colorIndex;
 }




 uint16_t VideoGraphicsArray::GetColorIndex(uint16_t r, uint16_t g, uint16_t b)
 {

     
//greens:  
if(r == 0x00 && g == 0xA8 && b == 0x00) return 0x02; //green
if(r == 0x00 && g == 0xAF && b == 0x00) return 0x32; //light green   
//blues:    
if(r == 0x00 && g == 0x00 && b == 0xA8) return 0x01; //blue
if(r == 0x00 && g == 0x00 && b == 0xAF) return 0x011; // blue sky   
//reds:
if(r == 0xA8 && g == 0x00 && b == 0x00) return 0x04; //red 
if(r == 0xAF && g == 0x00 && b == 0x00) return 0x24; //dark red 
//pinks:  
//purples:
if(r == 0xA8 && g == 0x00 && b == 0xA8) return 0x028; //royal purple   
//oranges:
if(r == 0xAF && g == 0xA8 && b == 0xA8) return 0x014; //orange    
//yellows:
if(r == 0x00 && g == 0xA8 && b == 0xA8) return 0x036; // sun yellow 
//grays:
if(r == 0x00 && g == 0x00 && b == 0x00) return 0x00; //black
if(r == 0xFE && g == 0xFE && b == 0xFE) return 0x38; //gray
if(r == 0xFD && g == 0xFD && b == 0xFD) return 0x07; //Light gray
if(r == 0xFF && g == 0xFF && b == 0xFF) return 0x3F; //white    
 //skin  
if(r == 0xA1 && g == 0xA1 && b == 0xA1) return 0x3d; //white 
//browns
if(r == 0xA2 && g == 0xA2 && b == 0xA2) return 0x20; //brown
//cyan
if(r == 0x01 && g == 0xFF && b == 0x01) return 0x03; 
//megenta
if(r == 0xFF && g == 0xA8 && b == 0xFF) return 0x05; //white 
//Deep yellow
if(r == 0xA1 && g == 0x01 && b == 0x01) return 0x06;
//Dark Blue 
if(r == 0x00 && g == 0x00 && b == 0x01) return 0x08; 
//medium blue
if(r == 0x00 && g == 0x00 && b == 0x02) return 0x09; 
//grass green
if(r == 0x00 && g == 0x01 && b == 0x00) return 0x10;
//Medium green
if(r == 0x00 && g == 0x02 && b == 0x00) return 0x12; 
//light cyan
if(r == 0x02 && g == 0xFF && b == 0x02) return 0x13; 
//terquise
if(r == 0x02 && g == 0xFF && b == 0x03) return 0x0A; 
//light blue
if(r == 0xA1 && g == 0x00 && b == 0x05) return 0x0B;
//hot pink
if(r == 0xFF && g == 0x01 && b == 0x01) return 0x0C;
//med pink
if(r == 0xFF && g == 0x02 && b == 0x02) return 0x0D;
//beige
if(r == 0x05 && g == 0x05 && b == 0x05) return 0x0E; 
//chalk
if(r == 0xFC && g == 0xFC && b == 0xFC) return 0x0F; 
//light pink 
if(r == 0xFF && g == 0x03 && b == 0x03) return 0x15;
//light yellow
if(r == 0x00 && g == 0x03 && b == 0x03) return 0x16;
//light beige
if(r == 0x02 && g == 0xFF && b == 0x04) return 0x17; 
//dark cyan
if(r == 0x01 && g == 0xFE && b == 0x01) return 0x18;
//dark blue sky  
if(r == 0x00 && g == 0x00 && b == 0xA1) return 0x19; 
//lime green
if(r == 0xA1 && g == 0x03 && b == 0xA1) return 0x1A; 
     
return 0x00;
     
 }



void VideoGraphicsArray::PutPixel(int32_t x, int32_t y, uint16_t r, uint16_t g, uint16_t b)
 {
    PutPixel(x,y, GetColorIndex(r,g,b));
 }

void VideoGraphicsArray::FillRectangle(uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint16_t r, uint16_t g, uint16_t b,  uint16_t size, uint16_t tri)
 {
     for(int32_t Y = y; Y < y+h; Y++)
        for(int32_t X = x; X < x+w; X++)
            PutPixel(X, Y, r, g, b);
    
 }
